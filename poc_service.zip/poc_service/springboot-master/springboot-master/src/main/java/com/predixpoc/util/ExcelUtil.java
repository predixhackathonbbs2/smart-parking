package com.predixpoc.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;

import com.sopra.vo.DemandsDetailsVO;

public class ExcelUtil {
	
	private static String previousItemNum = null;
	
	
	public static void writeDataToExcel(
			List<DemandsDetailsVO> keyVal, HttpServletResponse response) throws FileNotFoundException {
    	
    	  System.out.println("\n=== writeDataToExcel ===");
    	  //  Set<Map.Entry<String, List<ArtifcatsDetailsVO>>> entrySet1 = keyVal.entrySet();
			// Iterator<Entry<String, List<ArtifcatsDetailsVO>>> entrySetIterator = entrySet1.iterator();
			 HSSFWorkbook workbook = new HSSFWorkbook();
			//while (entrySetIterator.hasNext()) {
			    System.out.println("------------------------------------------------");
			    System.out.println("Iterating HashMap in Java using EntrySet and Java iterator");
			    //Entry entry = entrySetIterator.next();
			    String sheetList = "searchResult";
		        HSSFSheet sheet= workbook.createSheet(sheetList);
		              createHeaderRow(sheet);
		          int rowCount = 0;
		                   for (DemandsDetailsVO demandVos : keyVal) {
			              Row row = sheet.createRow(++rowCount);
			              
			             // Cell cellA = row.createCell(++rowCount);
			              writeBook(demandVos, row,getPreviousItemNum() );
			          }
		       
			
			// }
		          /*String fileName = "searchResult.xls";
		          File file = new File("D:\\GEGDC\\SM358224\\springboot-master\\src\\main\\resources\\searchResult.xls");
				  response.setContentLength((int) file.length());
				  response.addHeader("Content-Disposition", "attachment; filename=searchResult.xls");
		          response.setContentType("application/vnd.ms-excel");*/
		         // FileOutputStream outputStream = new FileOutputStream(new File("searchResult.xls"));
			/* try  {
				 
				 FileInputStream fileInputStream = new FileInputStream(file);
				 ServletOutputStream outputStream1 = response.getOutputStream();
				   // Write to the output stream
				   //worksheet.getWorkbook().write(outputStream);
				   // Flush the stream
				 	//response.set
				 	int bytes;
		            while ((bytes = fileInputStream.read()) != -1) {
		            	outputStream1.write(bytes);
		            	sheet.getWorkbook().write(outputStream1);
		            }
				   
				   //sheet.getWorkbook().write(outputStream1);
		            fileInputStream.close();
				   outputStream1.flush();
				   //IOUtils.
	             // workbook.write(outputStream1);
	          }*/
		          try {
		              	  response.setContentType("application/vnd.ms-excel");
		                  response.setHeader("Content-Disposition", "attachment; filename=searchResult.xls");
		                  ServletOutputStream ouputStream = response.getOutputStream();
		                  workbook.write(ouputStream);
		                  ouputStream.flush();
		                  ouputStream.close();
		                  System.out.println("ExcelUtil.writeDataToExcel() completed writing");
		             		              
		          }
		              
		       
	         
	          catch (Exception e)
	          {
	              e.printStackTrace();
	          }
          //XSSFWorkbook workbook = new XSSFWorkbook();
         
    	
    	
		// TODO Auto-generated method stub
		
	}
	private static void createHeaderRow(HSSFSheet sheet) {
        System.out.println("\n=== createHeaderRow ===");
    	CellStyle cellStyle = sheet.getWorkbook().createCellStyle();
		Font font = sheet.getWorkbook().createFont();
	//	font.setBoldweight(Font.BOLDWEIGHT_BOLD);
		font.setFontHeight((short) 11);
		font.setFontName("Calibri");
		font.setColor(HSSFColor.BLACK.index);
		font.setFontHeightInPoints((short) 11);
		cellStyle.setFont(font);
				
		Row row = sheet.createRow(0);
		Cell cellTitle = row.createCell(0);

		cellTitle.setCellStyle(cellStyle);
		cellTitle.setCellValue("Item");
		
		Cell cellAuthor = row.createCell(1);
		cellAuthor.setCellStyle(cellStyle);
		cellAuthor.setCellValue("Description");
		
		Cell cellPrice = row.createCell(2);
		cellPrice.setCellStyle(cellStyle);
		cellPrice.setCellValue("Supplier");
		
		Cell cellUUid = row.createCell(3);
		cellUUid.setCellStyle(cellStyle);
		cellUUid.setCellValue("Inventory");
		
		Cell celliiN = row.createCell(4);
		celliiN.setCellStyle(cellStyle);
		celliiN.setCellValue("Quantity Type");
		
		Cell pastDue = row.createCell(5);
		pastDue.setCellStyle(cellStyle);
		pastDue.setCellValue("Past Due");
						
		Cell celliipartCycleRemaining = row.createCell(6);
		celliipartCycleRemaining.setCellStyle(cellStyle);
		celliipartCycleRemaining.setCellValue("02/29-03/06");
		
		Cell celliid = row.createCell(7);
		celliid.setCellStyle(cellStyle);
		celliid.setCellValue("03/07-03/13");
		
		Cell cellqpe = row.createCell(8);
		cellqpe.setCellStyle(cellStyle);
		cellqpe.setCellValue("03/14-03/20");
		
		Cell cellcategory = row.createCell(9);
		cellcategory.setCellStyle(cellStyle);
		cellcategory.setCellValue("03/21-03/27");
		
		Cell cellcatalogPrice = row.createCell(10);
		cellcatalogPrice.setCellStyle(cellStyle);
		cellcatalogPrice.setCellValue("03/28-04/03");
		
		Cell cellpartLlpCycle = row.createCell(11);
		cellpartLlpCycle.setCellStyle(cellStyle);
		cellpartLlpCycle.setCellValue("04/04-04/10");
		
		Cell cellminorModule = row.createCell(12);
		cellminorModule.setCellStyle(cellStyle);
		cellminorModule.setCellValue("04/11-04/17");
		
		Cell cellpartCycleSinceNew = row.createCell(13);
		cellpartCycleSinceNew.setCellStyle(cellStyle);
		cellpartCycleSinceNew.setCellValue("04/18-04/24");
		
		Cell cellpartNumber = row.createCell(14);
		cellpartNumber.setCellStyle(cellStyle);
		cellpartNumber.setCellValue("04/25-05/01");
		
		Cell cell15 = row.createCell(15);
		cell15.setCellStyle(cellStyle);
		cell15.setCellValue("05/02-05/08");
		
		
		Cell cell16 = row.createCell(16);
		cell16.setCellStyle(cellStyle);
		cell16.setCellValue("05/09-05/15");
		
		Cell cell17 = row.createCell(17);
		cell17.setCellStyle(cellStyle);
		cell17.setCellValue("05/16-05/22");
		
		Cell cell18 = row.createCell(18);
		cell18.setCellStyle(cellStyle);
		cell18.setCellValue("05/23-05/29");
		
		Cell cell19 = row.createCell(19);
		cell19.setCellStyle(cellStyle);
		cell19.setCellValue("05/30-07/03");
		
		Cell cell20 = row.createCell(20);
		cell20.setCellStyle(cellStyle);
		cell20.setCellValue("07/04-07/31");
		
		/*Cell cell21 = row.createCell(21);
		cell21.setCellStyle(cellStyle);
		cell21.setCellValue("07/04-07/31");*/
		
		Cell cell22 = row.createCell(21);
		cell22.setCellStyle(cellStyle);
		cell22.setCellValue("08/01-08/28");
		
		Cell cell23 = row.createCell(22);
		cell23.setCellStyle(cellStyle);
		cell23.setCellValue("08/29-10/02");
		
		Cell cell24 = row.createCell(23);
		cell24.setCellStyle(cellStyle);
		cell24.setCellValue("10/03-10/30");
		
		Cell cell25 = row.createCell(24);
		cell25.setCellStyle(cellStyle);
		cell25.setCellValue("10/31-11/27");
		
		Cell cell26 = row.createCell(25);
		cell26.setCellStyle(cellStyle);
		cell26.setCellValue("11/28-01/01");
		
		Cell cell27 = row.createCell(26);
		cell27.setCellStyle(cellStyle);
		cell27.setCellValue("01/02-01/29");
		
		Cell cell28 = row.createCell(27);
		cell28.setCellStyle(cellStyle);
		cell28.setCellValue("01/30-02/26");
		
		
		
	}

	private static void writeBook(DemandsDetailsVO demandVo, Row row,String previousItemNum) {
    	
		Cell cell = row.createCell(0);
		int i = 0;
		int rowNum = row.getRowNum();
		
		if(getPreviousItemNum() == null || !getPreviousItemNum().equalsIgnoreCase(demandVo.getItemNumber())){
			//i=1;
			cell.setCellValue(demandVo.getItemNumber());
					
			cell = row.createCell(1);
	       	cell.setCellValue(demandVo.getItemDescription());
	       
	        cell = row.createCell(2);
	        cell.setCellValue(demandVo.getSupplierName());
	        
	        cell = row.createCell(3);
	        cell.setCellValue(demandVo.getInventoryOrganization());
	        
	        cell = row.createCell(4);
	        if(null!= demandVo.getPastDue()){
	        cell.setCellValue(demandVo.getPastDue().toString());
	        }else{
	        	 cell.setCellValue("");
	        }

	        setPreviousItemNum(demandVo.getItemNumber()); 
	        
		}else if(previousItemNum.equalsIgnoreCase(demandVo.getItemNumber())) {
				cell.setCellValue("");
				cell = row.createCell(1);
		       	cell.setCellValue("");
		       
		        cell = row.createCell(2);
		        cell.setCellValue("");
		        
		        cell = row.createCell(3);
		        cell.setCellValue("");
		        
		        cell = row.createCell(4);
		        if(null!= demandVo.getPastDue()){
		        cell.setCellValue(demandVo.getPastDue().toString());
		        }else{
		        	 cell.setCellValue("");
		        }
		
		        setPreviousItemNum(demandVo.getItemNumber()); 
		}
		
     
     /*   cell = row.createCell(2);
        if(null!=demandVo.getItemDescription()){
        	cell.setCellValue(demandVo.getItemDescription());
        }else{
        	
        	//cell.setCellValue("null");
        	cell.setCellValue(demandVo.getItemDescription());
        }
        
       // cell.setCellValue(partVO.getPartName());
     
        cell = row.createCell(3);
        cell.setCellValue(demandVo.getSupplierName());
        
        cell = row.createCell(4);
        cell.setCellValue(demandVo.getInventoryOrganization());*/
        StringBuffer buffer = new StringBuffer();
        
        
        cell = row.createCell(5);
        if(null!= demandVo.getPastDue()){
        	cell.setCellValue(demandVo.getPastDue().toString());
        }else{
        	cell.setCellValue("");
        }
        
        
        cell = row.createCell(6);
        if(null!= demandVo.getFeb29Mar06()){
        	 cell.setCellValue(demandVo.getFeb29Mar06().toString());
        }else{
        	 cell.setCellValue("");
        }
       
        
        cell = row.createCell(7);
        if(null!= demandVo.getMar07Mar13()){
        	 cell.setCellValue(demandVo.getMar07Mar13().toString());
        }else{
        	 cell.setCellValue("");
        }
       
        
        cell = row.createCell(8);
        if(null!= demandVo.getMar14Mar20()){
        	cell.setCellValue(demandVo.getMar14Mar20().toString());
        }else{
        	cell.setCellValue("");
        }
        
        
        cell = row.createCell(9);
        if(null!= demandVo.getMar21Mar27()){
        	cell.setCellValue(demandVo.getMar21Mar27().toString());
        }else{
        	cell.setCellValue("");
        }
        
        
        cell = row.createCell(10);
        if(null!= demandVo.getMar28Apr03()){
        	cell.setCellValue(demandVo.getMar28Apr03().toString());
        }else{
        	cell.setCellValue("");
        }
        
        
        cell = row.createCell(11);
        if(null!= demandVo.getApr04Apr10()){
        	cell.setCellValue(demandVo.getApr04Apr10().toString());
        }else{
        	cell.setCellValue("");
        }
        
        
        cell = row.createCell(12);
        if(null!= demandVo.getApr11Apr17()){
        	cell.setCellValue(demandVo.getApr11Apr17().toString());
        }else{
        	cell.setCellValue("");
        }
               
        
        cell = row.createCell(13);
        if(null!= demandVo.getApr18Apr24()){
        	cell.setCellValue(demandVo.getApr18Apr24().toString());
        }else{
        	cell.setCellValue("");
        }
        
        
        cell = row.createCell(14);
        if(null!= demandVo.getApr25May01()){
        	cell.setCellValue(demandVo.getApr25May01().toString());
        }else{
        	cell.setCellValue("");
        }
        
        
        
        cell = row.createCell(15);
        if(null!= demandVo.getMay02May08()){
        	 cell.setCellValue(demandVo.getMay02May08().toString());
        }else{
        	 cell.setCellValue("");
        }
       
        
        cell = row.createCell(16);
        if(null!= demandVo.getMay09May15()){
        	cell.setCellValue(demandVo.getMay09May15().toString());
        }else{
        	cell.setCellValue("");
        }
        
        
        cell = row.createCell(17);
        if(null!= demandVo.getMay16May22()){
        	cell.setCellValue(demandVo.getMay16May22().toString());
        }else{
        	cell.setCellValue("");
        }
        
        
        cell = row.createCell(18);
        if(null!=demandVo.getMay23May29()){
        	cell.setCellValue(demandVo.getMay23May29().toString());
        }else{
        	 cell.setCellValue("");
        }
       
        
        cell = row.createCell(19);
        if(null!= demandVo.getMay30Jul03()){
        	cell.setCellValue(demandVo.getMay30Jul03().toString());
        }else{
        	cell.setCellValue("");
        }
        
        
        cell = row.createCell(20);
        if(null!= demandVo.getJul04Jul31()){
        	cell.setCellValue(demandVo.getJul04Jul31().toString());
        }else{
        	cell.setCellValue("");
        }
        
        
        cell = row.createCell(21);
        if(null!= demandVo.getAug01Aug28()){
        	cell.setCellValue(demandVo.getAug01Aug28().toString());
        }else{
        	cell.setCellValue("");
        }
        
        
        cell = row.createCell(22);
        if(null!= demandVo.getAug29Oct02()){
        	cell.setCellValue(demandVo.getAug29Oct02().toString());
        }else{
        	cell.setCellValue("");
        }
                
        cell = row.createCell(23);
        if(null!= demandVo.getOct03Oct30()){
        	cell.setCellValue(demandVo.getOct03Oct30().toString());
        }else{
        	cell.setCellValue("");
        }
               
        cell = row.createCell(24);
        if(null!= demandVo.getOct31Nov27()){
        	cell.setCellValue(demandVo.getOct31Nov27().toString());
        }else{
        	 cell.setCellValue("");
        }
       
        
        cell = row.createCell(25);
        if(null!= demandVo.getNov28Jan01()){
        	cell.setCellValue(demandVo.getNov28Jan01().toString());
        }else{
        	cell.setCellValue("");
        }
        
      
        cell = row.createCell(26);
        if(null!= demandVo.getJan02Jan29()){
        	  cell.setCellValue(demandVo.getJan02Jan29().toString());
        }else{
        	  cell.setCellValue("");
        }
            
        cell = row.createCell(27);
        if(null!= demandVo.getJan30Feb26()){
        	cell.setCellValue(demandVo.getJan30Feb26().toString());
        }else{
        	cell.setCellValue("");
        }
      
      
      
	}
	public static String getPreviousItemNum() {
		return previousItemNum;
	}
	public static void setPreviousItemNum(String previousItemNum) {
		ExcelUtil.previousItemNum = previousItemNum;
	}
	
}
