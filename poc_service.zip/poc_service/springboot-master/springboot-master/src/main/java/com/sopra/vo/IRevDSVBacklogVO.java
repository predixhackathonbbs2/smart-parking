package com.sopra.vo;

import java.math.BigDecimal;
import java.util.Date;

public class IRevDSVBacklogVO {
	private long id;

	private String mod;
	
	private String accountreps;

	private String comments;

	private String construction;

	private String contractcustname;

	private String crd;

	private String creditstatus;


	private String estrevfq;
	private BigDecimal fset;

	private BigDecimal gon;

	private String govtvaso;

	private String h;

	private BigDecimal nevtt;

	private String orderchart;

	private String pmiscomment;

	private String pss;

	private String region;

	private String revrecqtr;

	private String revrecterms;

	
	private Date rosd;

	private String salesh;

	private String schedules;

	
	private Date sosd;

	
	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getAccountreps() {
		return accountreps;
	}


	public void setAccountreps(String accountreps) {
		this.accountreps = accountreps;
	}


	public String getComments() {
		return comments;
	}


	public void setComments(String comments) {
		this.comments = comments;
	}


	public String getConstruction() {
		return construction;
	}


	public void setConstruction(String construction) {
		this.construction = construction;
	}


	public String getContractcustname() {
		return contractcustname;
	}


	public void setContractcustname(String contractcustname) {
		this.contractcustname = contractcustname;
	}


	public String getCrd() {
		return crd;
	}


	public void setCrd(String crd) {
		this.crd = crd;
	}


	public String getCreditstatus() {
		return creditstatus;
	}


	public void setCreditstatus(String creditstatus) {
		this.creditstatus = creditstatus;
	}


	public String getEstrevfq() {
		return estrevfq;
	}


	public void setEstrevfq(String estrevfq) {
		this.estrevfq = estrevfq;
	}


	public BigDecimal getFset() {
		return fset;
	}


	public void setFset(BigDecimal fset) {
		this.fset = fset;
	}


	public BigDecimal getGon() {
		return gon;
	}


	public void setGon(BigDecimal gon) {
		this.gon = gon;
	}


	public String getGovtvaso() {
		return govtvaso;
	}


	public void setGovtvaso(String govtvaso) {
		this.govtvaso = govtvaso;
	}


	public String getH() {
		return h;
	}


	public void setH(String h) {
		this.h = h;
	}


	public BigDecimal getNevtt() {
		return nevtt;
	}


	public void setNevtt(BigDecimal nevtt) {
		this.nevtt = nevtt;
	}


	public String getOrderchart() {
		return orderchart;
	}


	public void setOrderchart(String orderchart) {
		this.orderchart = orderchart;
	}


	public String getPmiscomment() {
		return pmiscomment;
	}


	public void setPmiscomment(String pmiscomment) {
		this.pmiscomment = pmiscomment;
	}


	public String getPss() {
		return pss;
	}


	public void setPss(String pss) {
		this.pss = pss;
	}


	public String getRegion() {
		return region;
	}


	public void setRegion(String region) {
		this.region = region;
	}


	public String getRevrecqtr() {
		return revrecqtr;
	}


	public void setRevrecqtr(String revrecqtr) {
		this.revrecqtr = revrecqtr;
	}


	public String getRevrecterms() {
		return revrecterms;
	}


	public void setRevrecterms(String revrecterms) {
		this.revrecterms = revrecterms;
	}


	public Date getRosd() {
		return rosd;
	}


	public void setRosd(Date rosd) {
		this.rosd = rosd;
	}


	public String getSalesh() {
		return salesh;
	}


	public void setSalesh(String salesh) {
		this.salesh = salesh;
	}


	public String getSchedules() {
		return schedules;
	}


	public void setSchedules(String schedules) {
		this.schedules = schedules;
	}


	public Date getSosd() {
		return sosd;
	}


	public void setSosd(Date sosd) {
		this.sosd = sosd;
	}


	public String getZone() {
		return zone;
	}


	public void setZone(String zone) {
		this.zone = zone;
	}


	public String getMod() {
		return mod;
	}


	public void setMod(String mod) {
		this.mod = mod;
	}


	private String zone;

}
