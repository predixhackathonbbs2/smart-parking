package com.sopra.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sopra.entities.M2mResult;
import com.sopra.entities.M2mDevice;

@Repository
public interface IM2MResultRepository extends JpaRepository<M2mResult, Integer>
{
	
	
	@Override
	public List<M2mResult> findAll();
	
	List<M2mResult> findByM2mDevice(M2mDevice m2mdevice);
	
}
