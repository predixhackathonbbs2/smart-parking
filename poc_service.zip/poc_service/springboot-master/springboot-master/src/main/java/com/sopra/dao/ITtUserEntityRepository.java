package com.sopra.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.stereotype.Repository;

import com.sopra.entities.LLPDetails;
import com.sopra.entities.TtUser;

@Repository
public interface ITtUserEntityRepository extends JpaRepository<TtUser, Integer>
{
	
	
	String CHECK_AVIALABLE_USER = "from TtUser ttUser where ttUser.userName=?1";


	List<TtUser> findByUserName(String username);
	
	
	@Query(CHECK_AVIALABLE_USER)
	TtUser findUser(String username);
	
	
}
