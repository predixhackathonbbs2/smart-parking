package com.sopra.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the M2M_NOTIFICATION database table.
 * 
 */
@Entity
@Table(name="M2M_NOTIFICATION")
@NamedQuery(name="M2mNotification.findAll", query="SELECT m FROM M2mNotification m")
public class M2mNotification implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="M2M_NOTIFICATION_ID_GENERATOR", sequenceName="TT_SEQ_NOT")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="M2M_NOTIFICATION_ID_GENERATOR")
	private long id;

	private String acknowledged;

	private Timestamp created;

	@Column(name="NOTIFICATION_TYPE")
	private String notificationType;

	private String severity;

	private String status;

	//bi-directional many-to-one association to M2mDevice
	@ManyToOne
	@JoinColumn(name="DEVICEID")
	private M2mDevice m2mDevice;

	//bi-directional many-to-one association to M2mMessage
	@ManyToOne
	@JoinColumn(name="MESSAGE")
	private M2mMessage m2mMessage;

	public M2mNotification() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getAcknowledged() {
		return this.acknowledged;
	}

	public void setAcknowledged(String acknowledged) {
		this.acknowledged = acknowledged;
	}

	public Timestamp getCreated() {
		return this.created;
	}

	public void setCreated(Timestamp created) {
		this.created = created;
	}

	public String getNotificationType() {
		return this.notificationType;
	}

	public void setNotificationType(String notificationType) {
		this.notificationType = notificationType;
	}

	public String getSeverity() {
		return this.severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public M2mDevice getM2mDevice() {
		return this.m2mDevice;
	}

	public void setM2mDevice(M2mDevice m2mDevice) {
		this.m2mDevice = m2mDevice;
	}

	public M2mMessage getM2mMessage() {
		return this.m2mMessage;
	}

	public void setM2mMessage(M2mMessage m2mMessage) {
		this.m2mMessage = m2mMessage;
	}

}