package com.jpa.enums;

public enum ModelNames {

	PRITHVI,
	
	VAYU
}
