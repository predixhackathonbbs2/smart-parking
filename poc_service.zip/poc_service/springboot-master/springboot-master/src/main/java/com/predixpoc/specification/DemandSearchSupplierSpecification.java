package com.predixpoc.specification;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.sopra.entities.GetsDemand;

public class DemandSearchSupplierSpecification implements Specification<GetsDemand> {
	
	private GetsDemand filter;
	
	//private ScpDemandId filter1;
	
	public DemandSearchSupplierSpecification(GetsDemand filter){
		super();
		this.filter = filter;
		//this.filter1 = filter1;
	}
	
	
	@Override
	public Predicate toPredicate(Root<GetsDemand> root, CriteriaQuery<?> query,
			CriteriaBuilder cb) {
			Predicate p = cb.disjunction();
			
			List<Predicate> predicates = new ArrayList<>();
			if (null != filter.getItemNumber() && "" != filter.getItemNumber()) {
				predicates.add(cb.equal(root.get("itemNumber"),
						filter.getItemNumber()));
			}
			if ((null != filter.getBuyerName() && "" != filter.getBuyerName())) {
				predicates.add(cb.and(cb.equal(root.get("buyerName"),
						filter.getBuyerName())));
			}
			if (null != filter.getSupplierName() && "" != filter.getSupplierName()) {
				predicates.add(cb.and(cb.equal(root.get("supplierName"),
						filter.getSupplierName())));
			}
			if (filter.getSupplierCode() != null && "" != filter.getSupplierCode()) {
				predicates.add(cb.and(cb.equal(root.get("supplierCode"),
						filter.getSupplierCode())));
			}
			if (filter.getBuissnessUnit() != null
					&& "" != filter.getBuissnessUnit()) {
				predicates.add(cb.and(cb.equal(root.get("buissnessUnit"),
						filter.getBuissnessUnit())));
			}
			if (filter.getUserName() != null
					&& "" != filter.getUserName()) {
				predicates.add(cb.and(cb.equal(root.get("userName"),
						filter.getUserName())));
			}
			
				
		
			/*List<Predicate> predicates = new ArrayList<>();
		 	CriteriaQuery<ScpDemandId> criteriaLogin = cb.createQuery(ScpDemandId.class);
			Root<ScpDemandId> rootLoginVO = criteriaLogin.from(ScpDemandId.class);
			Root<GetsDemand> rootStatusVO = criteriaLogin.from(GetsDemand.class);
			
			Predicate predicateJoin = cb.equal(rootLoginVO
					.get("id"),
					rootStatusVO.get("scpDemandId").ge);
			predicates.add(predicateJoin);
			*/

		
		 //cb.isTrue(owner.get(attributeName)));
		
		/*if (null!= filter.getFirstName() && ""!= filter.getFirstName()) {
			predicates.add(cb.equal(root.get("firstName"),
					filter.getFirstName()));
		}  if ((null!= filter.getLastName() && ""!=  filter.getLastName())) {
			predicates.add(cb.and(cb.equal(root.get("lastName"),
					filter.getLastName())));
		}  if( null!=  filter.getAge()) {
			predicates.add(cb.and(cb.equal(root.get("age"), filter.getAge())));
		}  if (filter.getDepartment() != null && ""!= filter.getDepartment()) {
			predicates.add(cb.and(cb.equal(root.get("department"),
					filter.getDepartment())));
		}*/
		
		/*predicates.add(cb.and(arg0));

		 if (filter.getFirstName() != null && filter.getLastName() != null && filter.getAge()!=null && filter.getDepartment()!=null ) {
	            p.getExpressions().add(
	                    cb.and(cb.equal(root.get("firstName"), filter.getFirstName()),
	                            cb.equal(root.get("age"), filter.getAge())));
	        }
*/
		return andTogether(predicates, cb);
	}
	
	private Predicate andTogether(List<Predicate> predicates, CriteriaBuilder cb) {
	    return cb.and(predicates.toArray(new Predicate[0]));
	  }
	

	

}
