package com.predix.machine.test;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement
public class Ns2properties {
	
	/*private Nutrunner nutrunner;

	public Nutrunner getNutrunner() {
		return nutrunner;
	}

	@XmlElement
	public void setNutrunner(Nutrunner nutrunner) {
		this.nutrunner = nutrunner;
	}	*/
	
	private Status status;
	

	public Status getStatus() {
		return status;
	}
	@XmlElement
	public void setStatus(Status status) {
		this.status = status;
	}

}
