package com.sopra.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class MachineResultVO implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private long resultid;

	private BigDecimal angle;

	private String anglestatus;

	private BigDecimal cellid;

	private BigDecimal channelid;

	private String controllername;

	private String idcode;

	private BigDecimal jobbigint;

	private BigDecimal maxangle;

	private BigDecimal maxtorque;

	private BigDecimal minangle;

	private BigDecimal mintorque;

	private BigDecimal okcounter;

	private BigDecimal okcounterlimit;

	private BigDecimal targetangle;

	private BigDecimal targettorque;

	private BigDecimal tighteingid;

	private BigDecimal tighteningprogrambigint;

	private String tighteningstatus;

	private Timestamp timelastprogramchange;

	private Timestamp timestamp;

	private BigDecimal torque;

	private String torquestatus;
	
	private String totalQuality;

	public long getResultid() {
		return resultid;
	}

	public void setResultid(long resultid) {
		this.resultid = resultid;
	}

	public BigDecimal getAngle() {
		return angle;
	}

	public void setAngle(BigDecimal angle) {
		this.angle = angle;
	}

	public String getAnglestatus() {
		return anglestatus;
	}

	public void setAnglestatus(String anglestatus) {
		this.anglestatus = anglestatus;
	}

	public BigDecimal getCellid() {
		return cellid;
	}

	public void setCellid(BigDecimal cellid) {
		this.cellid = cellid;
	}

	public BigDecimal getChannelid() {
		return channelid;
	}

	public void setChannelid(BigDecimal channelid) {
		this.channelid = channelid;
	}

	public String getControllername() {
		return controllername;
	}

	public void setControllername(String controllername) {
		this.controllername = controllername;
	}

	public String getIdcode() {
		return idcode;
	}

	public void setIdcode(String idcode) {
		this.idcode = idcode;
	}

	public BigDecimal getJobbigint() {
		return jobbigint;
	}

	public void setJobbigint(BigDecimal jobbigint) {
		this.jobbigint = jobbigint;
	}

	public BigDecimal getMaxangle() {
		return maxangle;
	}

	public void setMaxangle(BigDecimal maxangle) {
		this.maxangle = maxangle;
	}

	public BigDecimal getMaxtorque() {
		return maxtorque;
	}

	public void setMaxtorque(BigDecimal maxtorque) {
		this.maxtorque = maxtorque;
	}

	public BigDecimal getMinangle() {
		return minangle;
	}

	public void setMinangle(BigDecimal minangle) {
		this.minangle = minangle;
	}

	public BigDecimal getMintorque() {
		return mintorque;
	}

	public void setMintorque(BigDecimal mintorque) {
		this.mintorque = mintorque;
	}

	public BigDecimal getOkcounter() {
		return okcounter;
	}

	public void setOkcounter(BigDecimal okcounter) {
		this.okcounter = okcounter;
	}

	public BigDecimal getOkcounterlimit() {
		return okcounterlimit;
	}

	public void setOkcounterlimit(BigDecimal okcounterlimit) {
		this.okcounterlimit = okcounterlimit;
	}

	public BigDecimal getTargetangle() {
		return targetangle;
	}

	public void setTargetangle(BigDecimal targetangle) {
		this.targetangle = targetangle;
	}

	public BigDecimal getTargettorque() {
		return targettorque;
	}

	public void setTargettorque(BigDecimal targettorque) {
		this.targettorque = targettorque;
	}

	public BigDecimal getTighteingid() {
		return tighteingid;
	}

	public void setTighteingid(BigDecimal tighteingid) {
		this.tighteingid = tighteingid;
	}

	public BigDecimal getTighteningprogrambigint() {
		return tighteningprogrambigint;
	}

	public void setTighteningprogrambigint(BigDecimal tighteningprogrambigint) {
		this.tighteningprogrambigint = tighteningprogrambigint;
	}

	public String getTighteningstatus() {
		return tighteningstatus;
	}

	public void setTighteningstatus(String tighteningstatus) {
		this.tighteningstatus = tighteningstatus;
	}

	public Timestamp getTimelastprogramchange() {
		return timelastprogramchange;
	}

	public void setTimelastprogramchange(Timestamp timelastprogramchange) {
		this.timelastprogramchange = timelastprogramchange;
	}

	public Timestamp getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}

	public BigDecimal getTorque() {
		return torque;
	}

	public void setTorque(BigDecimal torque) {
		this.torque = torque;
	}

	public String getTorquestatus() {
		return torquestatus;
	}

	public void setTorquestatus(String torquestatus) {
		this.torquestatus = torquestatus;
	}

	public String getTotalQuality() {
		return totalQuality;
	}

	public void setTotalQuality(String totalQuality) {
		this.totalQuality = totalQuality;
	}
	
	
}
