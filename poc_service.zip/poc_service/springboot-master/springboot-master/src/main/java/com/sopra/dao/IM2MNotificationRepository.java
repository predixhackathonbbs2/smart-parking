package com.sopra.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sopra.entities.M2mNotification;

@Repository
public interface IM2MNotificationRepository extends JpaRepository<M2mNotification, Integer>
{
	
	
	@Override
	public List<M2mNotification> findAll();	
	
}
