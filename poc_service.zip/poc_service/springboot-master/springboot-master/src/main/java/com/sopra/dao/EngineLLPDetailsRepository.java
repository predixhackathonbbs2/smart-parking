package com.sopra.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.sopra.entities.EngineLLPDetails;

@RepositoryRestResource
public interface EngineLLPDetailsRepository extends JpaRepository<EngineLLPDetails, Long> {

}
