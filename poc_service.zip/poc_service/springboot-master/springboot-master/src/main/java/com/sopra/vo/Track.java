package com.sopra.vo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.predix.machine.test.Nutrunner;

@XmlRootElement
@XmlType(name = "Track",namespace="http://www.ibm.com/AC/commonbaseevent1_0_1")
public class Track {

	
	private String title;
	
	private String singer;
	
	
	private Music music;

	public Music getMusic() {
		return music;
	}
	@XmlElement
	public void setMusic(Music music) {
		this.music = music;
	}

	public String getTitle() {
		return title;
	}

	@XmlElement
	public void setTitle(String title) {
		this.title = title;
	}

	public String getSinger() {
		return singer;
	}

	@XmlElement
	public void setSinger(String singer) {
		this.singer = singer;
	}

	@Override
	public String toString() {
		return "Track [title=" + title + ", singer=" + singer + "]";
	}
	
	public Nutrunner getNutrunner() {
		return nutrunner;
	}
	@XmlElement
	public void setNutrunner(Nutrunner nutrunner) {
		this.nutrunner = nutrunner;
	}

	private Nutrunner nutrunner;

	

}