package com.sopra.vo;

import java.sql.Timestamp;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class MachineNotificationVO {
	
	
	private static final long serialVersionUID = 1L;
	
	private long id;

	private String acknowledged;

	private Timestamp created;

	private String notificationType;
	
	private String severity;

	private String status;
	
	private MachineDeviceVO machineDeviceVo;
	
	private MachineMessageVO messageVO;
	
	public MachineDeviceVO getMachineDeviceVo() {
		return machineDeviceVo;
	}

	public void setMachineDeviceVo(MachineDeviceVO machineDeviceVo) {
		this.machineDeviceVo = machineDeviceVo;
	}

	public MachineMessageVO getMessageVO() {
		return messageVO;
	}

	public void setMessageVO(MachineMessageVO messageVO) {
		this.messageVO = messageVO;
	}



	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getAcknowledged() {
		return acknowledged;
	}

	public void setAcknowledged(String acknowledged) {
		this.acknowledged = acknowledged;
	}

	public Timestamp getCreated() {
		return created;
	}

	public void setCreated(Timestamp created) {
		this.created = created;
	}

	public String getNotificationType() {
		return notificationType;
	}

	public void setNotificationType(String notificationType) {
		this.notificationType = notificationType;
	}

	public String getSeverity() {
		return severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
}
