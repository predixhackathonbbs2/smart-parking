package com.sopra.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "engine")
public class Engine implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8492990330375545323L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "id", unique = true, nullable = false, insertable = false, updatable = false)
	private Long id;
	
	@Column(name = "esn")
	private String esn;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="model_id")
	private EngineModel engineModel;
	
	public Engine() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEsn() {
		return esn;
	}

	public void setEsn(String esn) {
		this.esn = esn;
	}

	public EngineModel getEngineModel() {
		return engineModel;
	}

	public void setEngineModel(EngineModel engineModel) {
		this.engineModel = engineModel;
	}


	
}
