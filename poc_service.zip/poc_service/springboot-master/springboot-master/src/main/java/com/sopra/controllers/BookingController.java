package com.sopra.controllers;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang.RandomStringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.Sort;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jpa.enums.ModelNames;
import com.jpa.enums.WorkScope;
import com.predix.machine.poc.CommonBaseEventType;
import com.predix.machine.test.CommonBaseEvents;
import com.predixpoc.specification.DemandSearchSpecification;
import com.predixpoc.specification.DemandSearchSpecificationFilterExcel;
import com.predixpoc.specification.DemandSearchSupplierSpecification;
import com.predixpoc.specification.EmployeeSpecification;
import com.predixpoc.util.ExcelUtil;
import com.predixpoc.util.RandomUtils;
import com.sopra.dao.EngineLLPDetailsRepository;
import com.sopra.dao.EngineModelRepository;
import com.sopra.dao.EngineRepository;
import com.sopra.dao.IDemandEntityRepository;
import com.sopra.dao.IDemandSearchEntityRepository;
import com.sopra.dao.IDemandUpdateRepository;
import com.sopra.dao.IEmployeeRepository;
import com.sopra.dao.IM2MDataRepository;
import com.sopra.dao.IM2MDeviceRepository;
import com.sopra.dao.IM2MNotificationRepository;
import com.sopra.dao.IM2MResultRepository;
import com.sopra.dao.ITtUserEntityRepository;
import com.sopra.dao.IrevDSVBackLogRepository;
import com.sopra.dao.IscploginRepository;
import com.sopra.dao.LLPDetailsRepository;
import com.sopra.dao.ShopVisitRepository;
import com.sopra.entities.Employee;
import com.sopra.entities.Engine;
import com.sopra.entities.EngineModel;
import com.sopra.entities.GetsDemand;
import com.sopra.entities.IrevDgsBacklog;
import com.sopra.entities.LLPDetails;
import com.sopra.entities.M2mDevice;
import com.sopra.entities.M2mMessage;
import com.sopra.entities.M2mNotification;
import com.sopra.entities.M2mResult;
import com.sopra.entities.ScpUser;
import com.sopra.entities.ScpUserRole;
import com.sopra.entities.ShopVisit;
import com.sopra.entities.TtUser;
import com.sopra.vo.BackLogCalcVO;
import com.sopra.vo.CumBackLogCalcVO;
import com.sopra.vo.DemandDateVO;
import com.sopra.vo.DemandsDetailsVO;
import com.sopra.vo.DemandsVO;
import com.sopra.vo.EmployeeVO;
import com.sopra.vo.MachineDeviceVO;
import com.sopra.vo.MachineMessageVO;
import com.sopra.vo.MachineNotificationVO;
import com.sopra.vo.MachineResultVO;
import com.sopra.vo.PlannedSupplierCalcVO;
import com.sopra.vo.QuantityTypeVO;
import com.sopra.vo.RestResponse;
import com.sopra.vo.SupplierCommitCalcVO;
import com.sopra.vo.Track;

@Controller
@RequestMapping(value = "/app")
public class BookingController {

	@Autowired
	private EngineModelRepository engineModelRepository;

	/*@Autowired
	private BookingRepository bookingRepository;*/

	@Autowired
	private EngineRepository engineRepository;

	@Autowired
	private LLPDetailsRepository llpDetailsRepository;
	
	@Autowired
	private EngineLLPDetailsRepository enginellpDetailsRepository;
	
	@Autowired
	private ShopVisitRepository shopVisitRepository;
	
	@Autowired
	private ITtUserEntityRepository ttUserService;
	
	@Autowired
	private IM2MResultRepository machineResultRepo;
	
	@Autowired
	private IM2MDeviceRepository machineDeviceRepo;
	
	@Autowired
	private IM2MDataRepository machineDataRepo;
	
	@Autowired
	private IM2MNotificationRepository machineNotificationRepo;
	
	@Autowired
	private IrevDSVBackLogRepository iRevRepo;
	
	@Autowired
	private IDemandEntityRepository demandRepo;
	
	@Autowired
	private IEmployeeRepository empRepo;
	
	@Autowired
	private IscploginRepository loginRepo;
	
	@Autowired
	private IDemandSearchEntityRepository demandSearchRepo;
	
	@Autowired
	private IDemandUpdateRepository demandUpdateRepository;

	private static List<String> partNames=new ArrayList<String>();
	static {
		partNames.add("ASSY - COMBUSTION CHAMBER");
		partNames.add("FUEL SYSTEM COMPONENTS");
		partNames.add("ASSY - FAN ROTOR");
		partNames.add("ASSY - HPC ROTOR");
		partNames.add("SUPPORT - BEARING");
		partNames.add("BLADE - FAN");
		partNames.add("LINK - THRUST ENGINE MOUNT");
		partNames.add("SEAL - CDP");
		partNames.add("HOUSING - BEARING NO 1");
		partNames.add("ELECTRICAL - TRANSMITTER");
		partNames.add("PLATE - HPT COOLING");
		partNames.add("SPOOL");
		partNames.add("CASE - LPT");
		partNames.add("ALTERNATOR - GENERATOR STATOR/ROTOR");
		partNames.add("FRAME - EXHAUST");
		partNames.add("CASE - FAN BLADE CONTAINMENT");
		partNames.add("MISC - LOW COST PARTS");
		partNames.add("SENSOR - SENSOR N1 & N2 SPEED");
		partNames.add("ASSY - HPC STATOR");
		partNames.add("DISK - FAN STG 1");
		partNames.add("SHAFT - LPT");
		partNames.add("PUMP - LUBE");
		partNames.add("BLADE - HPT STG 1");
		partNames.add("Blisk - HPC");
		partNames.add("ACTUATOR");
		partNames.add("SEAL - HPC");
		partNames.add("SEAL - TURBINE STG 3 & 4");
		partNames.add("ASSY - ACCESSORY GEARBOX");
		partNames.add("CASE - HPC");
		partNames.add("SEAL - TURBINE STG 5 & 6");
		partNames.add("VALVE");
		partNames.add("ASSY - LPT MODULE");
		partNames.add("BEARING - MAIN #1");
		partNames.add("ASSY - PTO DRIVE");
		partNames.add("MOUNT - ENGINE");
		partNames.add("DISK - HPT STG 1");
		partNames.add("LINER - COMBUSTION");
		partNames.add("DISK - LPT STG 3");
		partNames.add("DISK - LPT STG 4");
		partNames.add("PLUG");
		partNames.add("SEAL - ROTATING AIR");
		partNames.add("SEAL - AIR");
		partNames.add("Blisk - HPC");
		partNames.add("SUPPORT - MOUNT BEAM");
		partNames.add("SEAL - AIR BALANCE PISTON ST");
		partNames.add("ASSY - DOME COMBUSTION");
		partNames.add("NOZZLE - HPT STG 1");
		partNames.add("FRAME - FAN HUB");
		partNames.add("DISK - LPT STG 5");
		partNames.add("COUPLING");
		partNames.add("DISK - HPT STG 2");
		
	}
	@RequestMapping(value = "/bookings.html", method = RequestMethod.GET)
	public String index(Model model) {
		return "bookings";
	}

	@RequestMapping(value = "/listenginemodel", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<EngineModel> bookings(Model model) {
		return engineModelRepository.findAll();
	}

	@RequestMapping(value = "/populate/model", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String models(Model model) {
		System.out.println("In Model APP");

		for (int i = 0; i < 3; i++) {
			System.out.println("BookingController.models()" + i);
			EngineModel model2 = new EngineModel();
			model2.setModelName(ModelNames.values()[new Random()
					.nextInt(ModelNames.values().length)].toString());
			model2.setModelNumber("CRM-" + RandomStringUtils.randomNumeric(3));

			engineModelRepository.save(model2);
		}
		return "success";
	}

	@RequestMapping(value = "/populate/engines", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String series(Model model) {
		List<EngineModel> engineModels = engineModelRepository.findAll();
		
		for (EngineModel engineModel : engineModels) {
			for (int j = 0; j < 4; j++) {
				Engine engine = new Engine();
				engine.setEsn(RandomStringUtils.randomNumeric(6));
				engine.setEngineModel(engineModel);
				engineRepository.save(engine);
			}

		}

		return "success";
	}

	@RequestMapping(value = "/populate/engine/parts", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String parts(Model model) {
		List<Engine> engines = engineRepository.findAll();
		for(Engine engine:engines){
			for (int i = 0; i < partNames.size(); i++) {
				LLPDetails llpDetails = new LLPDetails();
				llpDetails.setPartSerialNumber(RandomStringUtils.randomAlphanumeric(6));
				llpDetails.setIin(RandomStringUtils.randomNumeric(3));
				llpDetails.setPartCycleSinceNew(Long.parseLong(RandomStringUtils.randomNumeric(6)));
				llpDetails.setPartNumber(RandomUtils.randomIntger(4)+RandomStringUtils.randomAlphanumeric(3)+""+i);
				llpDetails.setPartName(partNames.get(i));
				llpDetails.setCatalogPrice(RandomUtils.randomLongBetween(6000l,100000l));
				llpDetails.setEngine(engine);
				llpDetailsRepository.save(llpDetails);
			}
		}
		

		return "success";
	}

	@RequestMapping(value = "/populate/shopvisit", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String esn(Model model) {
		System.out.println("In Shop Visit of  ESNs");
		List<Engine> engines = engineRepository.findAll();
		for (Engine engine : engines) {
			int visitCount = RandomUtils.randomIntgerBetween(5, 10);
			String noOfCyclesSinceNew=RandomStringUtils.randomNumeric(5);
			for (int j = 0; j < visitCount; j++) {
				ShopVisit shopvisit = new ShopVisit();
				shopvisit.setEngine(engine);
				shopvisit.setNumberOfCyclesSinceNew(noOfCyclesSinceNew);
				Long engineCycleSinceNew=Long.parseLong(shopvisit.getNumberOfCyclesSinceNew());
				Long engineCycleSinceLastSV=Long.parseLong(RandomStringUtils.randomNumeric(5));
				Long numberOfCyclesSinceLastSV=0l;
				if(engineCycleSinceLastSV>engineCycleSinceNew){
					numberOfCyclesSinceLastSV=engineCycleSinceLastSV-engineCycleSinceNew;
				}
				else{
					numberOfCyclesSinceLastSV=engineCycleSinceNew-engineCycleSinceLastSV;
				}
				shopvisit.setNumberOfCyclesSinceLastVisit(numberOfCyclesSinceLastSV.toString());
				shopvisit.setVisitDate(RandomUtils.randomDateBetween(2013, 2014));
				shopvisit.setWorkScope(WorkScope.values()[new Random().nextInt(WorkScope.values().length)].toString());
				shopvisit.setAmount(new BigDecimal(RandomStringUtils.randomNumeric(4)));
				shopVisitRepository.save(shopvisit);
			}
		}

		return "success";
	}
	//@CrossOrigin(origins = "http://localhost:9000")
	@RequestMapping(value = "/view/enginemodels", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<EngineModel> engineModels(Model model,HttpServletResponse res) {
		HttpServletResponse response = (HttpServletResponse) res;
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE");
		response.setHeader("Access-Control-Max-Age", "3600");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with");
		return engineModelRepository.findAll();
	}
	
	@RequestMapping(value = "/view/engines", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<Engine> engines(Model model) {
		return engineRepository.findAll();
	}
	@RequestMapping(value = "/view/engineparts", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<LLPDetails> engineParts(Model model) {
		return llpDetailsRepository.findAll();
	}
	
	@RequestMapping(value = "/view/shopvisits", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<ShopVisit> shopVisits(Model model) {
		return shopVisitRepository.findAll();
	}
	
	
	@RequestMapping(value = "/view/TestPost", method = RequestMethod.POST, produces = MediaType.APPLICATION_XML_VALUE)
	@ResponseBody
	public String testPostService() {
		String output = "Testting the Post Service request";
		
		System.out.println("Testting the Post Service");
		return output;
	}
	
	@RequestMapping(value = "/view/login", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String login(@RequestBody TtUser user) {
		String status = "";
		System.out.println("BookingController.login()");

		try {

			TtUser checkUser = ttUserService.findUser(user.getUserName());

			if (null != checkUser) {

				if ((checkUser.getUserName().equalsIgnoreCase(user
						.getUserName()))
						&& (checkUser.getPassword().equalsIgnoreCase(user
								.getPassword()))) {
					return "Success";

				} else {
					return "Failure";
				}

			} else {
				return "Failure";

			}

		}

		catch (Exception ex) {
			System.out.println("HospitalAllarmService.login()");
			return status = status + "Registration unsuccessfully";

		}

		// return status;

	}
	
	@RequestMapping(value = "/view/register", method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public RestResponse registerUser(@RequestBody TtUser user) {
		String status = "";
		System.out.println("BookingController.registerUser()");
		RestResponse response=new RestResponse();
		try {
						
			TtUser checkUser = ttUserService.findUser(user.getUserName());
			
			if(null != checkUser){
				response.setStatus(201);
				response.setObject("Exists");
				return response;
			}else{
				//
				checkUser = new TtUser() ;
				//TtUser user = new TtUser();
				checkUser.setUserName(user.getUserName());
				checkUser.setFullName(user.getFullName());
				checkUser.setEmail(user.getEmail());
				checkUser.setPassword(user.getPassword());
				checkUser.setFlag("Y");
				ttUserService.save(checkUser);
				response.setStatus(200);
				return response;
			}
			
		}
		
		catch (Exception ex) {
			System.out.println("HospitalAllarmService.registerUser()");
			response.setStatus(201);
			return response;
			
			
		}
	//	return status;

	}
	@RequestMapping("/view/getMachineResult")
	public @ResponseBody MachineResultVO getMachineResult() {
		
		MachineResultVO machineResultVO = null;
		try{
		List<M2mResult> m2mResults = machineResultRepo.findAll();
		Integer ok = 0;
		Integer nok = 0;
		//Integer quality = null;
		for(M2mResult result : m2mResults){
			
			machineResultVO = new MachineResultVO();
            if(result.getTighteningstatus().equalsIgnoreCase("OK")){
            	ok++;
            }else{
            	nok++;
            }
            
           
			}
		Double dok = ok.doubleValue();
		Integer resultSize = m2mResults.size();
		Double dresult = resultSize.doubleValue();
		Double  quality  = (double) ((((dok)/(dresult))*10)/10);
        DecimalFormat df=new DecimalFormat("#.00");  
        String qualitys= df.format(quality);
        machineResultVO.setTotalQuality(qualitys);
		
		}
		catch(Exception e){
			
			System.out.println("HospitalAlarmService.getMachineResult() exception is :" + e);
		}
		return machineResultVO;
		
		
	}
	
	@RequestMapping("/view/getToolFeetCount")
	public @ResponseBody Integer getToolFeetCount() {
		Integer toolCont = null;
		try{
			//machineDeviceRepo.findAll();
			
			toolCont = machineDeviceRepo.getToolFleetCount();
			
		}catch(Exception e){
			System.out.println("HospitalAlarmService.getToolFeetCount()");
		}
		return toolCont;
		
	}
	
	
	@RequestMapping("/view/getTighteningProcessingCount")
	public @ResponseBody Integer getTighteningProcessingCount() {
		Integer toolCont = null;
		try{
			//machineDeviceRepo.findAll();
			
			toolCont = machineDataRepo.getTighteningProcessingCount();
			
		}catch(Exception e){
			System.out.println("HospitalAlarmService.getTighteningProcessingCount()");
		}
		return toolCont;
		
	}
	
	
	@RequestMapping("/view/getMachineNotification")
	public @ResponseBody List<MachineNotificationVO> getMachineNotification() {
		
		List<MachineNotificationVO> machineNotificationVOs = new ArrayList<MachineNotificationVO>();
		MachineNotificationVO machineNotificationVO = null;
		MachineDeviceVO machineDeviceVo = null;
		M2mDevice device = null;
		M2mMessage m2mMessage = null;
		MachineMessageVO machineMessageVO = null;
		
		try{
			List<M2mNotification> notification = machineNotificationRepo.findAll();
			
			for(M2mNotification notificationList : notification){
				machineNotificationVO = new MachineNotificationVO();
				machineNotificationVO.setId(notificationList.getId());
				machineNotificationVO.setCreated(notificationList.getCreated());
				machineNotificationVO.setNotificationType(notificationList.getNotificationType());
				machineNotificationVO.setSeverity(notificationList.getSeverity());
				machineNotificationVO.setStatus(notificationList.getStatus());
				machineNotificationVO.setAcknowledged(notificationList.getAcknowledged());
						
				device = notificationList.getM2mDevice();
				machineDeviceVo = new  MachineDeviceVO();
				machineDeviceVo.setConnection(device.getConnection());
				machineDeviceVo.setCreated(device.getCreated());
				machineDeviceVo.setId(device.getId());
				machineDeviceVo.setModel(device.getModel());
				machineDeviceVo.setName(device.getName());
				machineDeviceVo.setPort(device.getPort());
				machineDeviceVo.setSerialno(device.getSerialno());
				machineDeviceVo.setStatus(device.getStatus());
				machineDeviceVo.setType(device.getType());
			//	machineDeviceVo.se
				
				m2mMessage = notificationList.getM2mMessage();
				machineMessageVO = new MachineMessageVO();
				
				machineMessageVO.setId(m2mMessage.getId());
				machineMessageVO.setContent(m2mMessage.getContent());
				machineMessageVO.setImg(m2mMessage.getImg());
				machineMessageVO.setTitle(m2mMessage.getTitle());
								
				machineNotificationVO.setMachineDeviceVo(machineDeviceVo);
				machineNotificationVO.setMessageVO(machineMessageVO);
				
				
				
				machineNotificationVOs.add(machineNotificationVO);
				
			}
			
		}catch(Exception e){
			System.out.println("HospitalAlarmService.getMachineNotification()" + e);
		}
		return machineNotificationVOs;
		
	}
	
	
	@RequestMapping("/view/getMachineDevice")
	public @ResponseBody List<MachineDeviceVO> getMachineDevice() {
		List<MachineDeviceVO> deviceVOs = new ArrayList<MachineDeviceVO>();
		MachineDeviceVO machineDeviceVO = null;

		try {
			List<M2mDevice> devices = machineDeviceRepo.findAll();

			for (M2mDevice device : devices) {
				machineDeviceVO = new MachineDeviceVO();

				machineDeviceVO.setConnection(device.getConnection());
				machineDeviceVO.setCreated(device.getCreated());
				machineDeviceVO.setId(device.getId());
				machineDeviceVO.setModel(device.getModel());
				machineDeviceVO.setName(device.getName());
				machineDeviceVO.setPort(device.getPort());
				machineDeviceVO.setSerialno(device.getSerialno());
				machineDeviceVO.setStatus(device.getStatus());
				machineDeviceVO.setType(device.getType());
				deviceVOs.add(machineDeviceVO);

			}

		} catch (Exception e) {

		}
		return deviceVOs;

	}
	
	@RequestMapping("/getMachineDeviceDetails/{deviceId}")
	public @ResponseBody List<Map<String,Object>> getMachineDevice(@PathVariable("deviceId") Long deviceId) {
		Map<String,Object> objMap  = null;
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		try{
		
			List<Object []> retList = machineDeviceRepo.getDeviceDetailsById(deviceId);
			
			for(int i = 0; i < retList.size(); i++){
				objMap	= new HashMap<String, Object>();
				objMap.put("model", (retList.get(i))[0]);
				objMap.put("deviceName", (retList.get(i))[1]);
				objMap.put("connection", (retList.get(i))[2]);
				objMap.put("status", (retList.get(i))[3]);
				objMap.put("accuracy", (retList.get(i))[4]);
				
				objMap.put("x", (retList.get(i))[5]);
				objMap.put("y", (retList.get(i))[6]);
				objMap.put("zone", (retList.get(i))[7]);
				objMap.put("tighteingid", (retList.get(i))[8]);
				
				objMap.put("tighteningstatus", (retList.get(i))[9]);
				objMap.put("tighteningprogram", (retList.get(i))[10]);
				objMap.put("serialno", (retList.get(i))[11]);
							
				
				list.add(objMap);
				
			}
			
			
			System.out.println("BookingController.getMachineDevice()");
	
			}
		catch(Exception e)
		{
			System.out.println("BookingController.getMachineDevice()" + e);
		}
		
		return list;
		
		
	}
	
	
	/*@RequestMapping("/view/getMachineDeviceDetails/{deviceId}")
	public @ResponseBody List<Map<String,Object>> getMachineDevice(@PathVariable("deviceId") Long deviceId) {
		Map<String,Object> objMap  = null;
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		try{
		
			List<Object []> retList = machineDeviceRepo.getDeviceDetailsById(deviceId);
			
			System.out.println("BookingController.getMachineDevice()");
	
			}
		catch(Exception e)
		{
			System.out.println("BookingController.getMachineDevice()" + e);
		}
		
		return null;
		
		
	}*/
	
	@RequestMapping(value = "/view/getAllDSVBacklogDetailsOnSearch", method = RequestMethod.POST, produces="application/json")
	public @ResponseBody  List<Map<String,Object>>  getAllDSVBacklogDetailsOnSearchA(@PathVariable("zone") String zone,
			@PathVariable("region") String region,
			@PathVariable("revrecqtr") String revrecqtr,
			@PathVariable("accountreps") String accountreps,
			@PathVariable("pss") String pss,
			@PathVariable("govtvaso") String govtvaso,
			@PathVariable("schedules") String schedules) {
		Map<String,Object> objMap  = null;
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		try {
			List<Object []> retList  = iRevRepo.findIRevDSVBacklogVOonSearch(zone,region,revrecqtr,accountreps,pss,govtvaso,schedules);
			for(int i = 0; i < retList.size(); i++){
				objMap	= new HashMap<String, Object>();
				objMap.put("id", (retList.get(i))[0]);
				objMap.put("mod", (retList.get(i))[1]);
				objMap.put("comments", (retList.get(i))[2]);
				objMap.put("construction", (retList.get(i))[3]);
				objMap.put("contractcustname", (retList.get(i))[4]);
				objMap.put("estrevfq", (retList.get(i))[5]);
				objMap.put("fset", (retList.get(i))[6]);
				objMap.put("gon", (retList.get(i))[7]);
				objMap.put("h", (retList.get(i))[8]);
				objMap.put("nevtt", (retList.get(i))[9]);
				objMap.put("orderchart", (retList.get(i))[10]);
				objMap.put("pmiscomment", (retList.get(i))[11]);
				objMap.put("revrecterms", (retList.get(i))[12]);
				objMap.put("rosd", (retList.get(i))[13]);
				objMap.put("salesh", (retList.get(i))[14]);
				objMap.put("sosd", (retList.get(i))[15]);
				list.add(objMap);
			
			}
		
		} catch (Exception e) {
			System.out
					.println("HospitalAlarmService.iRevDSVBacklogVOonSearch()"
							+ e);
		}
		return list;
		
	}
	
	@RequestMapping(value = "/view/getAllDSVBacklogDetailsOnSearchPost", method = RequestMethod.POST, produces="application/json")
	public @ResponseBody  List<Map<String,Object>>  getAllDSVBacklogDetailsOnSearchPost(@RequestBody @Valid final IrevDgsBacklog irevDgsBacklog) {
		Map<String,Object> objMap  = null;
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		try {
			List<Object []> retList  = iRevRepo.findIRevDSVBacklogVOonSearch(irevDgsBacklog.getZone(),irevDgsBacklog.getRegion(),irevDgsBacklog.getRevrecqtr(),irevDgsBacklog.getAccountreps(),irevDgsBacklog.getPss(),irevDgsBacklog.getGovtvaso(),irevDgsBacklog.getSchedules());
			for(int i = 0; i < retList.size(); i++){
				objMap	= new HashMap<String, Object>();
				objMap.put("id", (retList.get(i))[0]);
				objMap.put("mod", (retList.get(i))[1]);
				objMap.put("comments", (retList.get(i))[2]);
				objMap.put("construction", (retList.get(i))[3]);
				objMap.put("contractcustname", (retList.get(i))[4]);
				objMap.put("estrevfq", (retList.get(i))[5]);
				objMap.put("fset", (retList.get(i))[6]);
				objMap.put("gon", (retList.get(i))[7]);
				objMap.put("h", (retList.get(i))[8]);
				objMap.put("nevtt", (retList.get(i))[9]);
				objMap.put("orderchart", (retList.get(i))[10]);
				objMap.put("pmiscomment", (retList.get(i))[11]);
				objMap.put("revrecterms", (retList.get(i))[12]);
				objMap.put("rosd", (retList.get(i))[13]);
				objMap.put("salesh", (retList.get(i))[14]);
				objMap.put("sosd", (retList.get(i))[15]);
				list.add(objMap);
			
			}
		
		} catch (Exception e) {
			System.out
					.println("HospitalAlarmService.iRevDSVBacklogVOonSearch()"
							+ e);
		}
		return list;
		
	}
	
	@RequestMapping("/view/getBuisnessUnitNames")
	public @ResponseBody List<Map<String, Object>> getBuisnessUnitNames() {
		// List<ItemNumberVO> itemNumberVOs = new ArrayList<ItemNumberVO>();
		// ItemNumberVO itemNumberVO = null;
		// List<GetsDemand> itemList = null;

		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		System.out.println("HospitalAlarmService.getBuisnessUnitNames()");
		try {
			List<String[]> retList = demandRepo.getUniqueBuisnessUnitNames();
			System.out.println("retList.getBuisnessUnitNames()" + retList.size());
			for (int i = 0; i < retList.size(); i++) {
				objMap = new HashMap<String, Object>();
				objMap.put("buissnessUnit", (retList.get(i)));
				//objMap.put("itemDescription", (retList.get(i))[1]);
				list.add(objMap);
			}

			/*
			 * itemList = demandRepo.getUniqueItemNumber(); for(GetsDemand
			 * itemLst : itemList){ itemNumberVO = new ItemNumberVO();
			 * itemNumberVO.setItemNumber(itemLst.getItemNumber());
			 * itemNumberVO.setItemDescription(itemLst.getItemDescription());
			 * itemNumberVOs.add(itemNumberVO); }
			 */

		} catch (Exception e) {
			System.out.println("HospitalAlarmService.getSupplierNames()" + e);
		}
		return list;

	}
	
	
	@RequestMapping(value = "/view/getDemandItemNumberOnSearch", method = RequestMethod.POST, produces="application/json")
	public @ResponseBody List<Map<String, Object>> getDemandItem(
			@RequestBody @Valid final GetsDemand demand) {

		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		try {
			List<Object[]> retList = demandRepo
					.getItemNumberonItemSearch(demand.getItemNumber());

			for (int i = 0; i < retList.size(); i++) {
				objMap = new HashMap<String, Object>();
				objMap.put("itemNumber", (retList.get(i)[0]));
				objMap.put("itemDescription", (retList.get(i)[1]));
				list.add(objMap);
			}

		} catch (Exception e) {
			System.out.println("HospitalAlarmService.getEngineDetails()" + e);
		}
		return list;
		

	}

	/*@RequestMapping(value = "/view/getEmployee", method = RequestMethod.GET, produces="application/json")
	public @ResponseBody  List<EmployeeVO>  getEmployee(@PathVariable("firstName") String firstName,@PathVariable("lastName") String lastName,@PathVariable("age") Integer age,@PathVariable("Department") String Department){
		List<EmployeeVO> employeeVOs = new ArrayList<EmployeeVO>();
		EmployeeVO employeeVO = null;
		
		try{
			EmployeeSpecification employeeSpecification = new EmployeeSpecification(filter)
			
		}catch(Exception e){
			
		}
		return null;
		
	}*/
	
	@RequestMapping(value = "/view/getEmployee", method = RequestMethod.POST, produces="application/json")
	public @ResponseBody  List<EmployeeVO>  getEmployee(@RequestBody @Valid final Employee emp){
		List<EmployeeVO> employeeVOs = new ArrayList<EmployeeVO>();
		EmployeeVO employeeVO = null;
		
		try{
			EmployeeSpecification employeeSpecification = new EmployeeSpecification(emp);
			List<Employee> emplIst = empRepo.findAll(employeeSpecification);
			for(Employee list : emplIst){
				employeeVO = new EmployeeVO();
				employeeVO.setAge(list.getAge());
				employeeVO.setDepartment(list.getDepartment());
				employeeVO.setFirstName(list.getFirstName());
				employeeVO.setLastName((list.getLastName()));
				employeeVO.setId(list.getId());
				employeeVOs.add(employeeVO);
			}
			
		}catch(Exception e){
			System.out.println("BookingController.getEmployee()" +e);
		}
		return employeeVOs;
		
	}
	
	@RequestMapping(value = "/view/Scplogin", method = RequestMethod.POST, produces="application/json")
	@ResponseBody
	public RestResponse loginScp(@RequestBody @Valid final ScpUser user) {
		RestResponse response=new RestResponse();
		try {

			ScpUser checkUser = loginRepo.findUser(user.getUsername());
			System.out.println("checkUser" + checkUser);

			if (null != checkUser) {

				if ((checkUser.getUsername().equalsIgnoreCase(user
						.getUsername()))
						&& (checkUser.getPassword().equalsIgnoreCase(user
								.getPassword()))) {
						ScpUserRole role =	checkUser.getScpUserRole();
						response.setStatus(200);
						response.setMessage("Success");
						response.setRoleId(role.getRoleId());
						response.setRoleName(role.getRoleName());
						System.out.println("checkUser" + response);

				} else {
					response.setMessage("Failure");
					response.setStatus(201);

				}
				System.out.println("Response: "+ response);
			} else {
				response.setMessage("NotExist");
				response.setStatus(201);

			}

		}

		catch (Exception ex) {
			System.out.println("HospitalAllarmService.login()");
			response.setStatus(201);
			return response;

		}
		// return status;
		return response;

	}
	
	@RequestMapping("/view/getDemandDetailsWithOutFilter")
	public @ResponseBody List<DemandsVO> getDemandDetailsWithOutFilter() {
		 List<DemandsVO> demandVos = new ArrayList<DemandsVO>();
		 DemandsVO demandVo = null;
		 QuantityTypeVO quantityTypeVO = null;
		 DemandDateVO dateVO = null;
		 List<QuantityTypeVO> quantityVoList = new ArrayList<QuantityTypeVO>();
		 List<DemandDateVO>  demandDateVoList = new ArrayList<DemandDateVO>();
		try {
			List<GetsDemand> demandList = demandRepo.findAll();
			
			for(GetsDemand demands : demandList){
				demandVo = new DemandsVO();
				quantityTypeVO = new QuantityTypeVO();
				dateVO = new DemandDateVO();
				
				demandVo.setDispositionId(demands.getDispositionId());
				demandVo.setItemNumber(demands.getItemNumber());
				demandVo.setItemDescription(demands.getItemDescription());
				demandVo.setSupplierName(demands.getSupplierName());
				demandVo.setInventoryOrganization(demands.getInventoryOrganization());
				//setting quantity type
				quantityTypeVO.setQuantityType(demands.getProductCode());
				
				//setting the date type
				
				dateVO.setApr04Apr10(demands.getApr04Apr10());
				dateVO.setApr11Apr17(demands.getApr11Apr17());
				dateVO.setApr18Apr24(demands.getApr18Apr24());
				dateVO.setApr25May01(demands.getApr25May01());
				dateVO.setAug01Aug28(demands.getAug01Aug28());
				dateVO.setAug29Oct02(demands.getAug29Oct02());
				dateVO.setFeb29Mar06(demands.getFeb29Mar06());
				dateVO.setJan02Jan29(demands.getJan02Jan29());
				dateVO.setJan30Feb26(demands.getJan30Feb26());
				dateVO.setJul04Jul31(demands.getJul04Jul31());
				dateVO.setMar07Mar13(demands.getMar07Mar13());
				dateVO.setMar14Mar20(demands.getMar14Mar20());
				dateVO.setMar21Mar27(demands.getMar21Mar27());
				dateVO.setMar28Apr03(demands.getMar28Apr03());
				dateVO.setMay02May08(demands.getMay02May08());
				dateVO.setMay09May15(demands.getMay09May15());
				dateVO.setMay16May22(demands.getMay16May22());
				dateVO.setMay23May29(demands.getMay23May29());
				dateVO.setMay30Jul03(demands.getMay30Jul03());
				dateVO.setNov28Jan01(demands.getNov28Jan01());
				dateVO.setOct03Oct30(demands.getOct03Oct30());
				dateVO.setOct31Nov27(demands.getOct31Nov27());
				
				demandDateVoList.add(dateVO);
				quantityTypeVO.setDemandDateVos(demandDateVoList);
				quantityVoList.add(quantityTypeVO);
				demandVo.setQuantityVos(quantityVoList);
				demandVos.add(demandVo);
				
			}
			
			
			}


		 catch (Exception e) {
			System.out.println("HospitalAlarmService.getDemandDetailsWithOutFilter()" + e);
		}
		return demandVos;

	}
	
	
	@RequestMapping("/view/getDemandAllDetailsWithOutFilterNew")
	public @ResponseBody List<DemandsDetailsVO> getDemandAllDetailsWithOutFilterNew() {
		 List<DemandsDetailsVO> demandVos = new ArrayList<DemandsDetailsVO>();
		 DemandsDetailsVO demandVo = null;
		// QuantityTypeVO quantityTypeVO = null;
		// DemandDateVO dateVO = null;
		// List<QuantityTypeVO> quantityVoList = new ArrayList<QuantityTypeVO>();
		 //List<DemandDateVO>  demandDateVoList = new ArrayList<DemandDateVO>();
		try {
			List<GetsDemand> demandList = demandRepo.findAll();
			
			for(GetsDemand demands : demandList){
				demandVo = new DemandsDetailsVO();
				//quantityTypeVO = new QuantityTypeVO();
				//dateVO = new DemandDateVO();
				
				demandVo.setDispositionId(demands.getDispositionId());
				demandVo.setItemNumber(demands.getItemNumber());
				demandVo.setItemDescription(demands.getItemDescription());
				demandVo.setSupplierName(demands.getSupplierName());
				demandVo.setInventoryOrganization(demands.getInventoryOrganization());
				demandVo.setQuantityType(demands.getProductCode());
				//setting quantity type
			//	quantityTypeVO.setQuantityType(demands.getProductCode());
				
				//setting the date type
				
				demandVo.setApr04Apr10(demands.getApr04Apr10());
				demandVo.setApr11Apr17(demands.getApr11Apr17());
				demandVo.setApr18Apr24(demands.getApr18Apr24());
				demandVo.setApr25May01(demands.getApr25May01());
				demandVo.setAug01Aug28(demands.getAug01Aug28());
				demandVo.setAug29Oct02(demands.getAug29Oct02());
				demandVo.setFeb29Mar06(demands.getFeb29Mar06());
				demandVo.setJan02Jan29(demands.getJan02Jan29());
				demandVo.setJan30Feb26(demands.getJan30Feb26());
				demandVo.setJul04Jul31(demands.getJul04Jul31());
				demandVo.setMar07Mar13(demands.getMar07Mar13());
				demandVo.setMar14Mar20(demands.getMar14Mar20());
				demandVo.setMar21Mar27(demands.getMar21Mar27());
				demandVo.setMar28Apr03(demands.getMar28Apr03());
				demandVo.setMay02May08(demands.getMay02May08());
				demandVo.setMay09May15(demands.getMay09May15());
				demandVo.setMay16May22(demands.getMay16May22());
				demandVo.setMay23May29(demands.getMay23May29());
				demandVo.setMay30Jul03(demands.getMay30Jul03());
				demandVo.setNov28Jan01(demands.getNov28Jan01());
				demandVo.setOct03Oct30(demands.getOct03Oct30());
				demandVo.setOct31Nov27(demands.getOct31Nov27());
				
				//demandDateVoList.add(dateVO);
				//quantityTypeVO.setDemandDateVos(demandDateVoList);
				//quantityVoList.add(quantityTypeVO);
				//demandVo.setQuantityVos(quantityVoList);
				demandVos.add(demandVo);
				
			}
			
			
			}


		 catch (Exception e) {
			System.out.println("HospitalAlarmService.getDemandDetailsWithOutFilter()" + e);
		}
		return demandVos;

	}
///////////////////////////////********** Filter***********************//////////////////////
	
	@RequestMapping(value = "/view/getDemandAllDetailsWithFilter", method = RequestMethod.POST, produces="application/json")
	public @ResponseBody List<DemandsVO> getDemandAllDetailsWithFilter(@RequestBody @Valid final GetsDemand demand) {
		List<DemandsVO> demandVos = new ArrayList<DemandsVO>();
		 DemandsVO demandVo = null;
		 QuantityTypeVO quantityTypeVO = null;
		 DemandDateVO dateVO = null;
		 List<QuantityTypeVO> quantityVoList = new ArrayList<QuantityTypeVO>();
		 List<DemandDateVO>  demandDateVoList = null;
		try {
						
			DemandSearchSpecification demandSearchSpecification = new DemandSearchSpecification(demand);
			List<GetsDemand> demandList = demandSearchRepo.findAll(demandSearchSpecification);
			for(GetsDemand demands : demandList){
				demandVo = new DemandsVO();
				quantityTypeVO = new QuantityTypeVO();
				dateVO = new DemandDateVO();
				
				demandVo.setDispositionId(demands.getDispositionId());
				demandVo.setItemNumber(demands.getItemNumber());
				demandVo.setItemDescription(demands.getItemDescription());
				demandVo.setSupplierName(demands.getSupplierName());
				demandVo.setInventoryOrganization(demands.getInventoryOrganization());
				//setting quantity type
				quantityTypeVO.setQuantityType(demands.getProductCode());
				System.out
						.println("demands.getDemandId()" + demands.getDemandId());
				demandVo.setDemandId(demands.getDemandId());
				
				//setting the date type
				
				dateVO.setApr04Apr10(demands.getApr04Apr10());
				dateVO.setApr11Apr17(demands.getApr11Apr17());
				dateVO.setApr18Apr24(demands.getApr18Apr24());
				dateVO.setApr25May01(demands.getApr25May01());
				dateVO.setAug01Aug28(demands.getAug01Aug28());
				dateVO.setAug29Oct02(demands.getAug29Oct02());
				dateVO.setFeb29Mar06(demands.getFeb29Mar06());
				dateVO.setJan02Jan29(demands.getJan02Jan29());
				dateVO.setJan30Feb26(demands.getJan30Feb26());
				dateVO.setJul04Jul31(demands.getJul04Jul31());
				dateVO.setMar07Mar13(demands.getMar07Mar13());
				dateVO.setMar14Mar20(demands.getMar14Mar20());
				dateVO.setMar21Mar27(demands.getMar21Mar27());
				dateVO.setMar28Apr03(demands.getMar28Apr03());
				dateVO.setMay02May08(demands.getMay02May08());
				dateVO.setMay09May15(demands.getMay09May15());
				dateVO.setMay16May22(demands.getMay16May22());
				dateVO.setMay23May29(demands.getMay23May29());
				dateVO.setMay30Jul03(demands.getMay30Jul03());
				dateVO.setNov28Jan01(demands.getNov28Jan01());
				dateVO.setOct03Oct30(demands.getOct03Oct30());
				dateVO.setOct31Nov27(demands.getOct31Nov27());
				demandDateVoList = new ArrayList<DemandDateVO>();
				demandDateVoList.add(dateVO);
				quantityTypeVO.setDemandDateVos(demandDateVoList);
				quantityVoList.add(quantityTypeVO);
				demandVo.setQuantityVos(quantityVoList);
				demandVos.add(demandVo);
				
			}
			
			
			}


		 catch (Exception e) {
			System.out.println("HospitalAlarmService.getDemandDetailsWithOutFilter()" + e);
		}
		return demandVos;

	}
	
	
	
	@RequestMapping("/view/getDemandDetailsWithOutFilters")
	public @ResponseBody List<DemandsVO> getDemandDetailsWithOutFilters() {
		 List<DemandsVO> demandVos = new ArrayList<DemandsVO>();
		 DemandsVO demandVo = null;
		 QuantityTypeVO quantityTypeVO = null;
		 DemandDateVO dateVO = null;
		 List<QuantityTypeVO> quantityVoList = new ArrayList<QuantityTypeVO>();
		 List<DemandDateVO>  demandDateVoList = null;
		try {
			List<GetsDemand> demandList = demandRepo.findAll();
			
			for(GetsDemand demands : demandList){
				demandVo = new DemandsVO();
				quantityTypeVO = new QuantityTypeVO();
				dateVO = new DemandDateVO();
				
				demandVo.setDispositionId(demands.getDispositionId());
				demandVo.setItemNumber(demands.getItemNumber());
				demandVo.setItemDescription(demands.getItemDescription());
				demandVo.setSupplierName(demands.getSupplierName());
				demandVo.setInventoryOrganization(demands.getInventoryOrganization());
				demandVo.setDemandId(demands.getDemandId());
				//setting quantity type
				quantityTypeVO.setQuantityType(demands.getProductCode());
				
				//setting the date type
				
				dateVO.setApr04Apr10(demands.getApr04Apr10());
				dateVO.setApr11Apr17(demands.getApr11Apr17());
				dateVO.setApr18Apr24(demands.getApr18Apr24());
				dateVO.setApr25May01(demands.getApr25May01());
				dateVO.setAug01Aug28(demands.getAug01Aug28());
				dateVO.setAug29Oct02(demands.getAug29Oct02());
				dateVO.setFeb29Mar06(demands.getFeb29Mar06());
				dateVO.setJan02Jan29(demands.getJan02Jan29());
				dateVO.setJan30Feb26(demands.getJan30Feb26());
				dateVO.setJul04Jul31(demands.getJul04Jul31());
				dateVO.setMar07Mar13(demands.getMar07Mar13());
				dateVO.setMar14Mar20(demands.getMar14Mar20());
				dateVO.setMar21Mar27(demands.getMar21Mar27());
				dateVO.setMar28Apr03((demands.getMar28Apr03()));
				dateVO.setMay02May08(demands.getMay02May08());
				dateVO.setMay09May15(demands.getMay09May15());
				dateVO.setMay16May22(demands.getMay16May22());
				dateVO.setMay23May29(demands.getMay23May29());
				dateVO.setMay30Jul03(demands.getMay30Jul03());
				dateVO.setNov28Jan01(demands.getNov28Jan01());
				dateVO.setOct03Oct30(demands.getOct03Oct30());
				dateVO.setOct31Nov27(demands.getOct31Nov27());
				demandDateVoList = new ArrayList<DemandDateVO>();
				demandDateVoList.add(dateVO);
				quantityTypeVO.setDemandDateVos(demandDateVoList);
				quantityVoList.add(quantityTypeVO);
				demandVo.setQuantityVos(quantityVoList);
				demandVos.add(demandVo);
				
			}
			
			
			}


		 catch (Exception e) {
			System.out.println("HospitalAlarmService.getDemandDetailsWithOutFilter()" + e);
		}
		return demandVos;

	}
	
	/*
	@SuppressWarnings("unchecked")
	@RequestMapping("/view/getDemandDetailsWithOutFiltersExcel")
	public @ResponseBody void downloadDemanDetailsinExcelWithoutFilter() {
		 List<DemandsVO> demandVos = new ArrayList<DemandsVO>();
		 DemandsVO demandVo = null;
		 QuantityTypeVO quantityTypeVO = null;
		 DemandDateVO dateVO = null;
		 List<QuantityTypeVO> quantityVoList = new ArrayList<QuantityTypeVO>();
		 List<DemandDateVO>  demandDateVoList = null;
		try {
			List<GetsDemand> demandList = demandRepo.findAll();
			
			for(GetsDemand demands : demandList){
				demandVo = new DemandsVO();
				quantityTypeVO = new QuantityTypeVO();
				dateVO = new DemandDateVO();
				
				demandVo.setDispositionId(demands.getDispositionId());
				demandVo.setItemNumber(demands.getItemNumber());
				demandVo.setItemDescription(demands.getItemDescription());
				demandVo.setSupplierName(demands.getSupplierName());
				demandVo.setInventoryOrganization(demands.getInventoryOrganization());
				demandVo.setDemandId(demands.getDemandId());
				//setting quantity type
				quantityTypeVO.setQuantityType(demands.getProductCode());
				
				//setting the date type
				
				dateVO.setApr04Apr10(demands.getApr04Apr10());
				dateVO.setApr11Apr17(demands.getApr11Apr17());
				dateVO.setApr18Apr24(demands.getApr18Apr24());
				dateVO.setApr25May01(demands.getApr25May01());
				dateVO.setAug01Aug28(demands.getAug01Aug28());
				dateVO.setAug29Oct02(demands.getAug29Oct02());
				dateVO.setFeb29Mar06(demands.getFeb29Mar06());
				dateVO.setJan02Jan29(demands.getJan02Jan29());
				dateVO.setJan30Feb26(demands.getJan30Feb26());
				dateVO.setJul04Jul31(demands.getJul04Jul31());
				dateVO.setMar07Mar13(demands.getMar07Mar13());
				dateVO.setMar14Mar20(demands.getMar14Mar20());
				dateVO.setMar21Mar27(demands.getMar21Mar27());
				dateVO.setMar28Mar03(demands.getMar28Mar03());
				dateVO.setMay02May08(demands.getMay02May08());
				dateVO.setMay09May15(demands.getMay09May15());
				dateVO.setMay16May22(demands.getMay16May22());
				dateVO.setMay23May29(demands.getMay23May29());
				dateVO.setMay30Jul03(demands.getMay30Jul03());
				dateVO.setNov28Jan01(demands.getNov28Jan01());
				dateVO.setOct03Oct30(demands.getOct03Oct30());
				dateVO.setOct31Nov27(demands.getOct31Nov27());
				demandDateVoList = new ArrayList<DemandDateVO>();
				demandDateVoList.add(dateVO);
				quantityTypeVO.setDemandDateVos(demandDateVoList);
				quantityVoList.add(quantityTypeVO);
				demandVo.setQuantityVos(quantityVoList);
				demandVos.add(demandVo);
				
			}
			 ExcelUtil.writeDataToExcel(demandVos);
			
			
			}


		 catch (Exception e) {
			System.out.println("HospitalAlarmService.downloadDemanDetailsinExcelWithoutFilter()" + e);
		}
		

	}*/
	
	@RequestMapping("/view/getDemandAllDetailsWithOutFilter")
	public @ResponseBody List<DemandsDetailsVO> getDemandAllDetailsWithOutFilter() {
		 List<DemandsDetailsVO> demandVos = new ArrayList<DemandsDetailsVO>();
		 DemandsDetailsVO demandVo = null;
		 BackLogCalcVO backLogCalcVO = new BackLogCalcVO();
		 CumBackLogCalcVO cumBackLogCalcVO =null;
		 SupplierCommitCalcVO supplierCommitCalcVO = new SupplierCommitCalcVO(); //equv cum backlog vo
		 PlannedSupplierCalcVO plannedSupplierCalcVO = new PlannedSupplierCalcVO();//equv baclogvo
		// QuantityTypeVO quantityTypeVO = null;
		// DemandDateVO dateVO = null;
		// List<QuantityTypeVO> quantityVoList = new ArrayList<QuantityTypeVO>();
		 //List<DemandDateVO>  demandDateVoList = new ArrayList<DemandDateVO>();
		 
		 BigDecimal backLogPastDue = null;
		try {
			List<GetsDemand> demandList = demandRepo.findAll(new Sort(Sort.Direction.ASC, "dispositionId"));
			
			for(GetsDemand demands : demandList){
				demandVo = new DemandsDetailsVO();
				//backLogCalcVO = new BackLogCalcVO();
				cumBackLogCalcVO = new CumBackLogCalcVO();
			//	supplierCommitCalcVO = new SupplierCommitCalcVO();
				//plannedSupplierCalcVO = new PlannedSupplierCalcVO();
				//quantityTypeVO = new QuantityTypeVO();
				//dateVO = new DemandDateVO();
				
				if(demands.getSentFlag().equalsIgnoreCase("false")){
					demandVo.setItemNumber("");
					demandVo.setItemDescription("");
					demandVo.setSupplierName("");
					demandVo.setInventoryOrganization("");
				}else{
					
					demandVo.setItemNumber(demands.getItemNumber());
					demandVo.setItemDescription(demands.getItemDescription());
					demandVo.setSupplierName(demands.getSupplierName());
					demandVo.setInventoryOrganization(demands.getInventoryOrganization());
				}
				
				
				demandVo.setDispositionId(demands.getDispositionId());
				//demandVo.setItemNumber(demands.getItemNumber());
				//demandVo.setItemDescription(demands.getItemDescription());
				//demandVo.setSupplierName(demands.getSupplierName());
				//demandVo.setInventoryOrganization(demands.getInventoryOrganization());
				//setting quantity type
			//	quantityTypeVO.setQuantityType(demands.getProductCode());
				
				//setting the date type
				demandVo.setQuantityType(demands.getProductCode());
				
				if(demands.getProductCode().equalsIgnoreCase("Planned for Supplier")){
					
					plannedSupplierCalcVO.setBackpastDue(demands.getPastDue());
					plannedSupplierCalcVO.setBackapr04Apr10(demands.getApr04Apr10());
					plannedSupplierCalcVO.setBackapr11Apr17(demands.getApr11Apr17());
					plannedSupplierCalcVO.setBackapr18Apr24(demands.getApr18Apr24());
					plannedSupplierCalcVO.setBackapr25May01(demands.getApr25May01());
					plannedSupplierCalcVO.setBackaug01Aug28(demands.getAug01Aug28());
					plannedSupplierCalcVO.setBackaug29Oct02(demands.getAug29Oct02());
					plannedSupplierCalcVO.setBackfeb29Mar06(demands.getFeb29Mar06());
					plannedSupplierCalcVO.setBackjan02Jan29(demands.getJan02Jan29());
					plannedSupplierCalcVO.setBackjan30Feb26(demands.getJan30Feb26());
					plannedSupplierCalcVO.setBackjul04Jul31(demands.getJul04Jul31());
					plannedSupplierCalcVO.setBackmar07Mar13(demands.getMar07Mar13());
					plannedSupplierCalcVO.setBackmar14Mar20(demands.getMar14Mar20());
					plannedSupplierCalcVO.setBackmar21Mar27(demands.getMar21Mar27());
					plannedSupplierCalcVO.setBackmar28Apr03((demands.getMar28Apr03()));
					plannedSupplierCalcVO.setBackmay02May08(demands.getMay02May08());
					plannedSupplierCalcVO.setBackmay09May15(demands.getMay09May15());
					plannedSupplierCalcVO.setBackmay16May22(demands.getMay16May22());
					plannedSupplierCalcVO.setBackmay23May29(demands.getMay23May29());
					plannedSupplierCalcVO.setBackmay30Jul03(demands.getMay30Jul03());
					plannedSupplierCalcVO.setBacknov28Jan01(demands.getNov28Jan01());
					plannedSupplierCalcVO.setBackoct03Oct30(demands.getOct03Oct30());
					plannedSupplierCalcVO.setBackoct31Nov27(demands.getOct31Nov27());
					
					
					//setting it to main VO
					demandVo.setApr04Apr10(plannedSupplierCalcVO.getBackapr04Apr10());
					demandVo.setApr11Apr17(plannedSupplierCalcVO.getBackapr11Apr17());
					demandVo.setApr18Apr24(plannedSupplierCalcVO.getBackapr18Apr24());
					demandVo.setApr25May01(plannedSupplierCalcVO.getBackapr25May01());
					demandVo.setAug01Aug28(plannedSupplierCalcVO.getBackaug01Aug28());
					demandVo.setAug29Oct02(plannedSupplierCalcVO.getBackaug29Oct02());
					demandVo.setFeb29Mar06(plannedSupplierCalcVO.getBackfeb29Mar06());
					demandVo.setJan02Jan29(plannedSupplierCalcVO.getBackjan02Jan29());
					demandVo.setJan30Feb26(plannedSupplierCalcVO.getBackjan30Feb26());
					demandVo.setJul04Jul31(plannedSupplierCalcVO.getBackjul04Jul31());
					demandVo.setMar07Mar13(plannedSupplierCalcVO.getBackmar07Mar13());
					demandVo.setMar14Mar20(plannedSupplierCalcVO.getBackmar14Mar20());
					demandVo.setMar21Mar27(plannedSupplierCalcVO.getBackmar21Mar27());
					demandVo.setMar28Apr03((plannedSupplierCalcVO.getBackmar28Apr03()));
					demandVo.setMay02May08(plannedSupplierCalcVO.getBackmay02May08());
					demandVo.setMay09May15(plannedSupplierCalcVO.getBackmay09May15());
					demandVo.setMay16May22(plannedSupplierCalcVO.getBackmay16May22());
					demandVo.setMay23May29(plannedSupplierCalcVO.getBackmay23May29());
					demandVo.setMay30Jul03(plannedSupplierCalcVO.getBackmay30Jul03());
					demandVo.setNov28Jan01(plannedSupplierCalcVO.getBacknov28Jan01());
					demandVo.setOct03Oct30(plannedSupplierCalcVO.getBackoct03Oct30());
					demandVo.setOct31Nov27(plannedSupplierCalcVO.getBackoct31Nov27());
					demandVo.setPastDue(plannedSupplierCalcVO.getBackpastDue());
				}
				if(demands.getProductCode().equalsIgnoreCase("Supplier Commit to Planned")){
					
					supplierCommitCalcVO.setcumbackapr11Apr17(demands.getApr11Apr17());
					supplierCommitCalcVO.setcumbackapr18Apr24(demands.getApr18Apr24());
					supplierCommitCalcVO.setcumbackapr25May01(demands.getApr25May01());
					supplierCommitCalcVO.setcumbackaug01Aug28(demands.getAug01Aug28());
					supplierCommitCalcVO.setcumbackaug29Oct02(demands.getAug29Oct02());
					supplierCommitCalcVO.setcumbackfeb29Mar06(demands.getFeb29Mar06());
					supplierCommitCalcVO.setcumbackjan02Jan29(demands.getJan02Jan29());
					supplierCommitCalcVO.setcumbackjan30Feb26(demands.getJan30Feb26());
					supplierCommitCalcVO.setcumbackjul04Jul31(demands.getJul04Jul31());
					supplierCommitCalcVO.setcumbackmar07Mar13(demands.getMar07Mar13());
					supplierCommitCalcVO.setcumbackmar14Mar20(demands.getMar14Mar20());
					supplierCommitCalcVO.setcumbackmar21Mar27(demands.getMar21Mar27());
					supplierCommitCalcVO.setcumbackmar28Apr03((demands.getMar28Apr03()));
					supplierCommitCalcVO.setcumbackmay02May08(demands.getMay02May08());
					supplierCommitCalcVO.setcumbackmay09May15(demands.getMay09May15());
					supplierCommitCalcVO.setcumbackmay16May22(demands.getMay16May22());
					supplierCommitCalcVO.setcumbackmay23May29(demands.getMay23May29());
					supplierCommitCalcVO.setcumbackmay30Jul03(demands.getMay30Jul03());
					supplierCommitCalcVO.setcumbacknov28Jan01(demands.getNov28Jan01());
					supplierCommitCalcVO.setcumbackoct03Oct30(demands.getOct03Oct30());
					supplierCommitCalcVO.setcumbackoct31Nov27(demands.getOct31Nov27());
					supplierCommitCalcVO.setcumbackapr04Apr10(demands.getApr04Apr10());
					supplierCommitCalcVO.setcumbackpastDue(demands.getPastDue());
					
					//setting it to main VO
					
					demandVo.setApr04Apr10(supplierCommitCalcVO.getcumbackapr04Apr10());
					demandVo.setApr11Apr17(supplierCommitCalcVO.getcumbackapr11Apr17());
					demandVo.setApr18Apr24(supplierCommitCalcVO.getcumbackapr18Apr24());
					demandVo.setApr25May01(supplierCommitCalcVO.getcumbackapr25May01());
					demandVo.setAug01Aug28(supplierCommitCalcVO.getcumbackaug01Aug28());
					demandVo.setAug29Oct02(supplierCommitCalcVO.getcumbackaug29Oct02());
					demandVo.setFeb29Mar06(supplierCommitCalcVO.getcumbackfeb29Mar06());
					demandVo.setJan02Jan29(supplierCommitCalcVO.getcumbackjan02Jan29());
					demandVo.setJan30Feb26(supplierCommitCalcVO.getcumbackjan30Feb26());
					demandVo.setJul04Jul31(supplierCommitCalcVO.getcumbackjul04Jul31());
					demandVo.setMar07Mar13(supplierCommitCalcVO.getcumbackmar07Mar13());
					demandVo.setMar14Mar20(supplierCommitCalcVO.getcumbackmar14Mar20());
					demandVo.setMar21Mar27(supplierCommitCalcVO.getcumbackmar21Mar27());
					demandVo.setMar28Apr03((supplierCommitCalcVO.getcumbackmar28Apr03()));
					demandVo.setMay02May08(supplierCommitCalcVO.getcumbackmay02May08());
					demandVo.setMay09May15(supplierCommitCalcVO.getcumbackmay09May15());
					demandVo.setMay16May22(supplierCommitCalcVO.getcumbackmay16May22());
					demandVo.setMay23May29(supplierCommitCalcVO.getcumbackmay23May29());
					demandVo.setMay30Jul03(supplierCommitCalcVO.getcumbackmay30Jul03());
					demandVo.setNov28Jan01(supplierCommitCalcVO.getcumbacknov28Jan01());
					demandVo.setOct03Oct30(supplierCommitCalcVO.getcumbackoct03Oct30());
					demandVo.setOct31Nov27(supplierCommitCalcVO.getcumbackoct31Nov27());
					demandVo.setPastDue(supplierCommitCalcVO.getcumbackpastDue());
					
					
				}
				else if(demands.getProductCode().equalsIgnoreCase("Backlog")){
					backLogCalcVO.setBackpastDue(demands.getPastDue());
					
					//Planned for Supplier - Supplier Commit to Planned
					
					backLogCalcVO.setBackapr04Apr10(plannedSupplierCalcVO.getBackapr04Apr10().subtract(supplierCommitCalcVO.getcumbackapr04Apr10()));
					backLogCalcVO.setBackapr11Apr17(plannedSupplierCalcVO.getBackapr11Apr17().subtract(supplierCommitCalcVO.getcumbackapr11Apr17()));
					backLogCalcVO.setBackapr18Apr24(plannedSupplierCalcVO.getBackapr18Apr24().subtract(supplierCommitCalcVO.getcumbackapr18Apr24()));
					backLogCalcVO.setBackapr25May01(plannedSupplierCalcVO.getBackapr25May01().subtract(supplierCommitCalcVO.getcumbackapr25May01()));
					backLogCalcVO.setBackaug01Aug28(plannedSupplierCalcVO.getBackaug01Aug28().subtract(supplierCommitCalcVO.getcumbackaug01Aug28()));
					backLogCalcVO.setBackaug29Oct02(plannedSupplierCalcVO.getBackaug29Oct02().subtract(supplierCommitCalcVO.getcumbackaug29Oct02()));
					backLogCalcVO.setBackfeb29Mar06(plannedSupplierCalcVO.getBackfeb29Mar06().subtract(supplierCommitCalcVO.getcumbackfeb29Mar06()));
					backLogCalcVO.setBackjan02Jan29(plannedSupplierCalcVO.getBackjan02Jan29().subtract(supplierCommitCalcVO.getcumbackjan02Jan29()));
					backLogCalcVO.setBackjan30Feb26(plannedSupplierCalcVO.getBackjan30Feb26().subtract(supplierCommitCalcVO.getcumbackjan30Feb26()));
					backLogCalcVO.setBackjul04Jul31(plannedSupplierCalcVO.getBackjul04Jul31().subtract(supplierCommitCalcVO.getcumbackjul04Jul31()));
					backLogCalcVO.setBackmar07Mar13(plannedSupplierCalcVO.getBackmar07Mar13().subtract(supplierCommitCalcVO.getcumbackmar07Mar13()));
					backLogCalcVO.setBackmar14Mar20(plannedSupplierCalcVO.getBackmar14Mar20().subtract(supplierCommitCalcVO.getcumbackmar14Mar20()));
					backLogCalcVO.setBackmar21Mar27(plannedSupplierCalcVO.getBackmar21Mar27().subtract(supplierCommitCalcVO.getcumbackmar21Mar27()));
					backLogCalcVO.setBackmar28Apr03((plannedSupplierCalcVO.getBackmar28Apr03().subtract(supplierCommitCalcVO.getcumbackmar28Apr03())));
					backLogCalcVO.setBackmay02May08(plannedSupplierCalcVO.getBackmay02May08().subtract(supplierCommitCalcVO.getcumbackmay02May08()));
					backLogCalcVO.setBackmay09May15(plannedSupplierCalcVO.getBackmay09May15().subtract(supplierCommitCalcVO.getcumbackmay09May15()));
					backLogCalcVO.setBackmay16May22(plannedSupplierCalcVO.getBackmay16May22().subtract(supplierCommitCalcVO.getcumbackmay16May22()));
					backLogCalcVO.setBackmay23May29(plannedSupplierCalcVO.getBackmay23May29().subtract(supplierCommitCalcVO.getcumbackmay23May29()));
					backLogCalcVO.setBackmay30Jul03(plannedSupplierCalcVO.getBackmay30Jul03().subtract(supplierCommitCalcVO.getcumbackmay30Jul03()));
					backLogCalcVO.setBacknov28Jan01(plannedSupplierCalcVO.getBacknov28Jan01().subtract(supplierCommitCalcVO.getcumbacknov28Jan01()));
					backLogCalcVO.setBackoct03Oct30(plannedSupplierCalcVO.getBackoct03Oct30().subtract(supplierCommitCalcVO.getcumbackoct03Oct30()));
					backLogCalcVO.setBackoct31Nov27(plannedSupplierCalcVO.getBackoct31Nov27().subtract(supplierCommitCalcVO.getcumbackoct31Nov27()));
					
					//setting the details to MAIN vo
					
					demandVo.setApr04Apr10(backLogCalcVO.getBackapr04Apr10());
					demandVo.setApr11Apr17(backLogCalcVO.getBackapr11Apr17());
					demandVo.setApr18Apr24(backLogCalcVO.getBackapr18Apr24());
					demandVo.setApr25May01(backLogCalcVO.getBackapr25May01());
					demandVo.setAug01Aug28(backLogCalcVO.getBackaug01Aug28());
					demandVo.setAug29Oct02(backLogCalcVO.getBackaug29Oct02());
					demandVo.setFeb29Mar06(backLogCalcVO.getBackfeb29Mar06());
					demandVo.setJan02Jan29(backLogCalcVO.getBackjan02Jan29());
					demandVo.setJan30Feb26(backLogCalcVO.getBackjan30Feb26());
					demandVo.setJul04Jul31(backLogCalcVO.getBackjul04Jul31());
					demandVo.setMar07Mar13(backLogCalcVO.getBackmar07Mar13());
					demandVo.setMar14Mar20(backLogCalcVO.getBackmar14Mar20());
					demandVo.setMar21Mar27(backLogCalcVO.getBackmar21Mar27());
					demandVo.setMar28Apr03((backLogCalcVO.getBackmar28Apr03()));
					demandVo.setMay02May08(backLogCalcVO.getBackmay02May08());
					demandVo.setMay09May15(backLogCalcVO.getBackmay09May15());
					demandVo.setMay16May22(backLogCalcVO.getBackmay16May22());
					demandVo.setMay23May29(backLogCalcVO.getBackmay23May29());
					demandVo.setMay30Jul03(backLogCalcVO.getBackmay30Jul03());
					demandVo.setNov28Jan01(backLogCalcVO.getBacknov28Jan01());
					demandVo.setOct03Oct30(backLogCalcVO.getBackoct03Oct30());
					demandVo.setOct31Nov27(backLogCalcVO.getBackoct31Nov27());
					demandVo.setPastDue(backLogCalcVO.getBackpastDue());
					
				}else if(demands.getProductCode().equalsIgnoreCase("Cum.Backlog")){
					//demandVo.setPastDue(demands.getPastDue());
					
					cumBackLogCalcVO.setcumbackapr11Apr17(demands.getApr11Apr17());
					cumBackLogCalcVO.setcumbackapr18Apr24(demands.getApr18Apr24());
					cumBackLogCalcVO.setcumbackapr25May01(demands.getApr25May01());
					cumBackLogCalcVO.setcumbackaug01Aug28(demands.getAug01Aug28());
					cumBackLogCalcVO.setcumbackaug29Oct02(demands.getAug29Oct02());
					cumBackLogCalcVO.setcumbackfeb29Mar06(demands.getFeb29Mar06());
					cumBackLogCalcVO.setcumbackjan02Jan29(demands.getJan02Jan29());
					cumBackLogCalcVO.setcumbackjan30Feb26(demands.getJan30Feb26());
					cumBackLogCalcVO.setcumbackjul04Jul31(demands.getJul04Jul31());
					cumBackLogCalcVO.setcumbackmar07Mar13(demands.getMar07Mar13());
					cumBackLogCalcVO.setcumbackmar14Mar20(demands.getMar14Mar20());
					cumBackLogCalcVO.setcumbackmar21Mar27(demands.getMar21Mar27());
					cumBackLogCalcVO.setcumbackmar28Apr03((demands.getMar28Apr03()));
					cumBackLogCalcVO.setcumbackmay02May08(demands.getMay02May08());
					cumBackLogCalcVO.setcumbackmay09May15(demands.getMay09May15());
					cumBackLogCalcVO.setcumbackmay16May22(demands.getMay16May22());
					cumBackLogCalcVO.setcumbackmay23May29(demands.getMay23May29());
					cumBackLogCalcVO.setcumbackmay30Jul03(demands.getMay30Jul03());
					cumBackLogCalcVO.setcumbacknov28Jan01(demands.getNov28Jan01());
					cumBackLogCalcVO.setcumbackoct03Oct30(demands.getOct03Oct30());
					cumBackLogCalcVO.setcumbackoct31Nov27(demands.getOct31Nov27());
					cumBackLogCalcVO.setcumbackapr04Apr10(demands.getApr04Apr10());
					cumBackLogCalcVO.setcumbackpastDue(demands.getPastDue());
					
					
					//cumBackLogCalcVO.setcumbackpastDue((backLogCalcVO.getBackpastDue()));
					
					//setting in order
					
					cumBackLogCalcVO.setcumbackfeb29Mar06(cumBackLogCalcVO.getcumbackpastDue().add(backLogCalcVO.getBackfeb29Mar06()));
					
					cumBackLogCalcVO.setcumbackmar07Mar13(cumBackLogCalcVO.getcumbackfeb29Mar06().add(backLogCalcVO.getBackmar07Mar13()));
					
					cumBackLogCalcVO.setcumbackmar14Mar20(cumBackLogCalcVO.getcumbackmar07Mar13().add(backLogCalcVO.getBackmar14Mar20()));
					
					cumBackLogCalcVO.setcumbackmar21Mar27(cumBackLogCalcVO.getcumbackmar14Mar20().add(backLogCalcVO.getBackmar21Mar27()));
					
					cumBackLogCalcVO.setcumbackmar28Apr03((cumBackLogCalcVO.getcumbackmar21Mar27().add(backLogCalcVO.getBackmar28Apr03())));
										
					cumBackLogCalcVO.setcumbackapr04Apr10((cumBackLogCalcVO.getcumbackmar28Apr03().add(backLogCalcVO.getBackapr04Apr10())));
					
					cumBackLogCalcVO.setcumbackapr11Apr17((cumBackLogCalcVO.getcumbackapr04Apr10().add(backLogCalcVO.getBackapr11Apr17())));
					
					cumBackLogCalcVO.setcumbackapr18Apr24((cumBackLogCalcVO.getcumbackapr11Apr17().add(backLogCalcVO.getBackapr18Apr24())));
					
					cumBackLogCalcVO.setcumbackapr25May01(cumBackLogCalcVO.getcumbackapr18Apr24().add(backLogCalcVO.getBackapr25May01()));
					
					cumBackLogCalcVO.setcumbackmay02May08(cumBackLogCalcVO.getcumbackapr25May01().add(backLogCalcVO.getBackmay02May08()));
					
					cumBackLogCalcVO.setcumbackmay09May15(cumBackLogCalcVO.getcumbackmay02May08().add(backLogCalcVO.getBackmay09May15()));
					
					cumBackLogCalcVO.setcumbackmay16May22(cumBackLogCalcVO.getcumbackmay09May15().add(backLogCalcVO.getBackmay16May22()));
					
					cumBackLogCalcVO.setcumbackmay23May29(cumBackLogCalcVO.getcumbackmay16May22().add(backLogCalcVO.getBackmay23May29()));
					
					cumBackLogCalcVO.setcumbackmay30Jul03(cumBackLogCalcVO.getcumbackmay23May29().add(backLogCalcVO.getBackmay30Jul03()));
					
					cumBackLogCalcVO.setcumbackjul04Jul31(cumBackLogCalcVO.getcumbackmay30Jul03().add(backLogCalcVO.getBackjul04Jul31()));
					
					cumBackLogCalcVO.setcumbackaug01Aug28(cumBackLogCalcVO.getcumbackjul04Jul31().add(backLogCalcVO.getBackaug01Aug28()));
					
					cumBackLogCalcVO.setcumbackaug29Oct02(cumBackLogCalcVO.getcumbackaug01Aug28().add(backLogCalcVO.getBackaug29Oct02()));
					
					cumBackLogCalcVO.setcumbackoct03Oct30(cumBackLogCalcVO.getcumbackaug29Oct02().add(backLogCalcVO.getBackoct03Oct30()));
					
					cumBackLogCalcVO.setcumbackoct31Nov27(cumBackLogCalcVO.getcumbackoct03Oct30().add(backLogCalcVO.getBackoct31Nov27()));
					
					cumBackLogCalcVO.setcumbacknov28Jan01(cumBackLogCalcVO.getcumbackoct31Nov27().add(backLogCalcVO.getBacknov28Jan01()));
					
					cumBackLogCalcVO.setcumbackjan02Jan29(cumBackLogCalcVO.getcumbacknov28Jan01().add(backLogCalcVO.getBackjan02Jan29()));
					
					cumBackLogCalcVO.setcumbackjan30Feb26(cumBackLogCalcVO.getcumbackjan02Jan29().add(backLogCalcVO.getBackjan30Feb26()));
					
										
					
					//setting the details to MAIN vo
					
					demandVo.setApr04Apr10(cumBackLogCalcVO.getcumbackapr04Apr10());
					demandVo.setApr11Apr17(cumBackLogCalcVO.getcumbackapr11Apr17());
					demandVo.setApr18Apr24(cumBackLogCalcVO.getcumbackapr18Apr24());
					demandVo.setApr25May01(cumBackLogCalcVO.getcumbackapr25May01());
					demandVo.setAug01Aug28(cumBackLogCalcVO.getcumbackaug01Aug28());
					demandVo.setAug29Oct02(cumBackLogCalcVO.getcumbackaug29Oct02());
					demandVo.setFeb29Mar06(cumBackLogCalcVO.getcumbackfeb29Mar06());
					demandVo.setJan02Jan29(cumBackLogCalcVO.getcumbackjan02Jan29());
					demandVo.setJan30Feb26(cumBackLogCalcVO.getcumbackjan30Feb26());
					demandVo.setJul04Jul31(cumBackLogCalcVO.getcumbackjul04Jul31());
					demandVo.setMar07Mar13(cumBackLogCalcVO.getcumbackmar07Mar13());
					demandVo.setMar14Mar20(cumBackLogCalcVO.getcumbackmar14Mar20());
					demandVo.setMar21Mar27(cumBackLogCalcVO.getcumbackmar21Mar27());
					demandVo.setMar28Apr03((cumBackLogCalcVO.getcumbackmar28Apr03()));
					demandVo.setMay02May08(cumBackLogCalcVO.getcumbackmay02May08());
					demandVo.setMay09May15(cumBackLogCalcVO.getcumbackmay09May15());
					demandVo.setMay16May22(cumBackLogCalcVO.getcumbackmay16May22());
					demandVo.setMay23May29(cumBackLogCalcVO.getcumbackmay23May29());
					demandVo.setMay30Jul03(cumBackLogCalcVO.getcumbackmay30Jul03());
					demandVo.setNov28Jan01(cumBackLogCalcVO.getcumbacknov28Jan01());
					demandVo.setOct03Oct30(cumBackLogCalcVO.getcumbackoct03Oct30());
					demandVo.setOct31Nov27(cumBackLogCalcVO.getcumbackoct31Nov27());
					demandVo.setPastDue(cumBackLogCalcVO.getcumbackpastDue());
					
					
				}else{
					demandVo.setApr11Apr17(demands.getApr11Apr17());
					demandVo.setApr18Apr24(demands.getApr18Apr24());
					demandVo.setApr25May01(demands.getApr25May01());
					demandVo.setAug01Aug28(demands.getAug01Aug28());
					demandVo.setAug29Oct02(demands.getAug29Oct02());
					demandVo.setFeb29Mar06(demands.getFeb29Mar06());
					demandVo.setJan02Jan29(demands.getJan02Jan29());
					demandVo.setJan30Feb26(demands.getJan30Feb26());
					demandVo.setJul04Jul31(demands.getJul04Jul31());
					demandVo.setMar07Mar13(demands.getMar07Mar13());
					demandVo.setMar14Mar20(demands.getMar14Mar20());
					demandVo.setMar21Mar27(demands.getMar21Mar27());
					demandVo.setMar28Apr03((demands.getMar28Apr03()));
					demandVo.setMay02May08(demands.getMay02May08());
					demandVo.setMay09May15(demands.getMay09May15());
					demandVo.setMay16May22(demands.getMay16May22());
					demandVo.setMay23May29(demands.getMay23May29());
					demandVo.setMay30Jul03(demands.getMay30Jul03());
					demandVo.setNov28Jan01(demands.getNov28Jan01());
					demandVo.setOct03Oct30(demands.getOct03Oct30());
					demandVo.setOct31Nov27(demands.getOct31Nov27());
					demandVo.setApr04Apr10(demands.getApr04Apr10());
				}
				
				
				
				/*demandVo.setApr04Apr10(demands.getApr04Apr10());
				demandVo.setApr11Apr17(demands.getApr11Apr17());
				demandVo.setApr18Apr24(demands.getApr18Apr24());
				demandVo.setApr25May01(demands.getApr25May01());
				demandVo.setAug01Aug28(demands.getAug01Aug28());
				demandVo.setAug29Oct02(demands.getAug29Oct02());
				demandVo.setFeb29Mar06(demands.getFeb29Mar06());
				demandVo.setJan02Jan29(demands.getJan02Jan29());
				demandVo.setJan30Feb26(demands.getJan30Feb26());
				demandVo.setJul04Jul31(demands.getJul04Jul31());
				demandVo.setMar07Mar13(demands.getMar07Mar13());
				demandVo.setMar14Mar20(demands.getMar14Mar20());
				demandVo.setMar21Mar27(demands.getMar21Mar27());
				demandVo.setMar28Apr03((demands.getMar28Apr03()));
				demandVo.setMay02May08(demands.getMay02May08());
				demandVo.setMay09May15(demands.getMay09May15());
				demandVo.setMay16May22(demands.getMay16May22());
				demandVo.setMay23May29(demands.getMay23May29());
				demandVo.setMay30Jul03(demands.getMay30Jul03());
				demandVo.setNov28Jan01(demands.getNov28Jan01());
				demandVo.setOct03Oct30(demands.getOct03Oct30());
				demandVo.setOct31Nov27(demands.getOct31Nov27());*/
				
				demandVo.setDemandId(demands.getDemandId());
				demandVo.setSentFlag(demands.getSentFlag());
				demandVo.setEditFlag(demands.getEditFlag());
				
				//demandDateVoList.add(dateVO);
				//quantityTypeVO.setDemandDateVos(demandDateVoList);
				//quantityVoList.add(quantityTypeVO);
				//demandVo.setQuantityVos(quantityVoList);
				demandVos.add(demandVo);
				
			}
			
			
			}


		 catch (Exception e) {
			System.out.println("HospitalAlarmService.getDemandDetailsWithOutFilter()" + e);
		}
		return demandVos;

	}
	
	
	@RequestMapping(value = "/view/getDemandAllDetailsWithFilterNew", method = RequestMethod.POST, produces="application/json")
	public @ResponseBody List<DemandsDetailsVO> getDemandAllDetailsWithFilterNew(@RequestBody @Valid final GetsDemand demand) {
		
		
		 List<DemandsDetailsVO> demandVos = new ArrayList<DemandsDetailsVO>();
		 DemandsDetailsVO demandVo = null;
		// QuantityTypeVO quantityTypeVO = null;
		// DemandDateVO dateVO = null;
		// List<QuantityTypeVO> quantityVoList = new ArrayList<QuantityTypeVO>();
		 //List<DemandDateVO>  demandDateVoList = new ArrayList<DemandDateVO>();
		try {
			DemandSearchSpecification demandSearchSpecification = new DemandSearchSpecification(demand);
			List<GetsDemand> demandList = demandSearchRepo.findAll(demandSearchSpecification);
			
			for(GetsDemand demands : demandList){
				demandVo = new DemandsDetailsVO();
				//quantityTypeVO = new QuantityTypeVO();
				//dateVO = new DemandDateVO();
				
				demandVo.setDispositionId(demands.getDispositionId());
				demandVo.setItemNumber(demands.getItemNumber());
				demandVo.setItemDescription(demands.getItemDescription());
				demandVo.setSupplierName(demands.getSupplierName());
				demandVo.setInventoryOrganization(demands.getInventoryOrganization());
				//setting quantity type
			//	quantityTypeVO.setQuantityType(demands.getProductCode());
				
				//setting the date type
				demandVo.setQuantityType(demands.getProductCode());
				demandVo.setApr04Apr10(demands.getApr04Apr10());
				demandVo.setApr11Apr17(demands.getApr11Apr17());
				demandVo.setApr18Apr24(demands.getApr18Apr24());
				demandVo.setApr25May01(demands.getApr25May01());
				demandVo.setAug01Aug28(demands.getAug01Aug28());
				demandVo.setAug29Oct02(demands.getAug29Oct02());
				demandVo.setFeb29Mar06(demands.getFeb29Mar06());
				demandVo.setJan02Jan29(demands.getJan02Jan29());
				demandVo.setJan30Feb26(demands.getJan30Feb26());
				demandVo.setJul04Jul31(demands.getJul04Jul31());
				demandVo.setMar07Mar13(demands.getMar07Mar13());
				demandVo.setMar14Mar20(demands.getMar14Mar20());
				demandVo.setMar21Mar27(demands.getMar21Mar27());
				demandVo.setMar28Apr03(demands.getMar28Apr03());
				demandVo.setMay02May08(demands.getMay02May08());
				demandVo.setMay09May15(demands.getMay09May15());
				demandVo.setMay16May22(demands.getMay16May22());
				demandVo.setMay23May29(demands.getMay23May29());
				demandVo.setMay30Jul03(demands.getMay30Jul03());
				demandVo.setNov28Jan01(demands.getNov28Jan01());
				demandVo.setOct03Oct30(demands.getOct03Oct30());
				demandVo.setOct31Nov27(demands.getOct31Nov27());
				
				demandVo.setDemandId(demands.getDemandId());
				demandVo.setSentFlag(demands.getSentFlag());
				demandVo.setEditFlag(demands.getEditFlag());
				
				//demandDateVoList.add(dateVO);
				//quantityTypeVO.setDemandDateVos(demandDateVoList);
				//quantityVoList.add(quantityTypeVO);
				//demandVo.setQuantityVos(quantityVoList);
				demandVos.add(demandVo);
				
			}
			
			
			}


		 catch (Exception e) {
			System.out.println("HospitalAlarmService.getDemandDetailsWithOutFilter()" + e);
		}
		return demandVos;

	}
	
	
	@RequestMapping(value = "/view/getDemandDetailsWithOutFiltersExcel",  produces="application/vnd.ms-excel")
	//@RequestMapping("/view/getDemandDetailsWithOutFiltersExcel", method = RequestMethod.POST, produces="application/json")
	public @ResponseBody void downloadDemanDetailsinExcelWithoutFilter(HttpServletResponse response) {
		 List<DemandsDetailsVO> demandVos = new ArrayList<DemandsDetailsVO>();
		 DemandsDetailsVO demandVo = null;
		 BackLogCalcVO backLogCalcVO = new BackLogCalcVO();
		 CumBackLogCalcVO cumBackLogCalcVO =null;
		 SupplierCommitCalcVO supplierCommitCalcVO = new SupplierCommitCalcVO(); //equv cum backlog vo
		 PlannedSupplierCalcVO plannedSupplierCalcVO = new PlannedSupplierCalcVO();//equv baclogvo
		// QuantityTypeVO quantityTypeVO = null;
		// DemandDateVO dateVO = null;
		// List<QuantityTypeVO> quantityVoList = new ArrayList<QuantityTypeVO>();
		 //List<DemandDateVO>  demandDateVoList = new ArrayList<DemandDateVO>();
		 ClassPathResource pdfFile = new ClassPathResource("pdf-sample.pdf");
		 ResponseEntity<InputStreamResource> entity = null;
		try {
			List<GetsDemand> demandList = demandRepo.findAll();
			
			for(GetsDemand demands : demandList){
				demandVo = new DemandsDetailsVO();
				cumBackLogCalcVO = new CumBackLogCalcVO();
				//quantityTypeVO = new QuantityTypeVO();
				//dateVO = new DemandDateVO();
				
				demandVo.setDispositionId(demands.getDispositionId());
				demandVo.setItemNumber(demands.getItemNumber());
				demandVo.setItemDescription(demands.getItemDescription());
				demandVo.setSupplierName(demands.getSupplierName());
				demandVo.setInventoryOrganization(demands.getInventoryOrganization());
				//setting quantity type
			//	quantityTypeVO.setQuantityType(demands.getProductCode());
				
				//setting the date type
				/*demandVo.setQuantityType(demands.getProductCode());
				demandVo.setApr04Apr10(demands.getApr04Apr10());
				demandVo.setApr11Apr17(demands.getApr11Apr17());
				demandVo.setApr18Apr24(demands.getApr18Apr24());
				demandVo.setApr25May01(demands.getApr25May01());
				demandVo.setAug01Aug28(demands.getAug01Aug28());
				demandVo.setAug29Oct02(demands.getAug29Oct02());
				demandVo.setFeb29Mar06(demands.getFeb29Mar06());
				demandVo.setJan02Jan29(demands.getJan02Jan29());
				demandVo.setJan30Feb26(demands.getJan30Feb26());
				demandVo.setJul04Jul31(demands.getJul04Jul31());
				demandVo.setMar07Mar13(demands.getMar07Mar13());
				demandVo.setMar14Mar20(demands.getMar14Mar20());
				demandVo.setMar21Mar27(demands.getMar21Mar27());
				demandVo.setMar28Apr03(demands.getMar28Apr03());
				demandVo.setMay02May08(demands.getMay02May08());
				demandVo.setMay09May15(demands.getMay09May15());
				demandVo.setMay16May22(demands.getMay16May22());
				demandVo.setMay23May29(demands.getMay23May29());
				demandVo.setMay30Jul03(demands.getMay30Jul03());
				demandVo.setNov28Jan01(demands.getNov28Jan01());
				demandVo.setOct03Oct30(demands.getOct03Oct30());
				demandVo.setOct31Nov27(demands.getOct31Nov27());*/
				
				if(demands.getProductCode().equalsIgnoreCase("Planned for Supplier")){
					
					plannedSupplierCalcVO.setBackpastDue(demands.getPastDue());
					plannedSupplierCalcVO.setBackapr04Apr10(demands.getApr04Apr10());
					plannedSupplierCalcVO.setBackapr11Apr17(demands.getApr11Apr17());
					plannedSupplierCalcVO.setBackapr18Apr24(demands.getApr18Apr24());
					plannedSupplierCalcVO.setBackapr25May01(demands.getApr25May01());
					plannedSupplierCalcVO.setBackaug01Aug28(demands.getAug01Aug28());
					plannedSupplierCalcVO.setBackaug29Oct02(demands.getAug29Oct02());
					plannedSupplierCalcVO.setBackfeb29Mar06(demands.getFeb29Mar06());
					plannedSupplierCalcVO.setBackjan02Jan29(demands.getJan02Jan29());
					plannedSupplierCalcVO.setBackjan30Feb26(demands.getJan30Feb26());
					plannedSupplierCalcVO.setBackjul04Jul31(demands.getJul04Jul31());
					plannedSupplierCalcVO.setBackmar07Mar13(demands.getMar07Mar13());
					plannedSupplierCalcVO.setBackmar14Mar20(demands.getMar14Mar20());
					plannedSupplierCalcVO.setBackmar21Mar27(demands.getMar21Mar27());
					plannedSupplierCalcVO.setBackmar28Apr03((demands.getMar28Apr03()));
					plannedSupplierCalcVO.setBackmay02May08(demands.getMay02May08());
					plannedSupplierCalcVO.setBackmay09May15(demands.getMay09May15());
					plannedSupplierCalcVO.setBackmay16May22(demands.getMay16May22());
					plannedSupplierCalcVO.setBackmay23May29(demands.getMay23May29());
					plannedSupplierCalcVO.setBackmay30Jul03(demands.getMay30Jul03());
					plannedSupplierCalcVO.setBacknov28Jan01(demands.getNov28Jan01());
					plannedSupplierCalcVO.setBackoct03Oct30(demands.getOct03Oct30());
					plannedSupplierCalcVO.setBackoct31Nov27(demands.getOct31Nov27());
					
					
					//setting it to main VO
					demandVo.setApr04Apr10(plannedSupplierCalcVO.getBackapr04Apr10());
					demandVo.setApr11Apr17(plannedSupplierCalcVO.getBackapr11Apr17());
					demandVo.setApr18Apr24(plannedSupplierCalcVO.getBackapr18Apr24());
					demandVo.setApr25May01(plannedSupplierCalcVO.getBackapr25May01());
					demandVo.setAug01Aug28(plannedSupplierCalcVO.getBackaug01Aug28());
					demandVo.setAug29Oct02(plannedSupplierCalcVO.getBackaug29Oct02());
					demandVo.setFeb29Mar06(plannedSupplierCalcVO.getBackfeb29Mar06());
					demandVo.setJan02Jan29(plannedSupplierCalcVO.getBackjan02Jan29());
					demandVo.setJan30Feb26(plannedSupplierCalcVO.getBackjan30Feb26());
					demandVo.setJul04Jul31(plannedSupplierCalcVO.getBackjul04Jul31());
					demandVo.setMar07Mar13(plannedSupplierCalcVO.getBackmar07Mar13());
					demandVo.setMar14Mar20(plannedSupplierCalcVO.getBackmar14Mar20());
					demandVo.setMar21Mar27(plannedSupplierCalcVO.getBackmar21Mar27());
					demandVo.setMar28Apr03((plannedSupplierCalcVO.getBackmar28Apr03()));
					demandVo.setMay02May08(plannedSupplierCalcVO.getBackmay02May08());
					demandVo.setMay09May15(plannedSupplierCalcVO.getBackmay09May15());
					demandVo.setMay16May22(plannedSupplierCalcVO.getBackmay16May22());
					demandVo.setMay23May29(plannedSupplierCalcVO.getBackmay23May29());
					demandVo.setMay30Jul03(plannedSupplierCalcVO.getBackmay30Jul03());
					demandVo.setNov28Jan01(plannedSupplierCalcVO.getBacknov28Jan01());
					demandVo.setOct03Oct30(plannedSupplierCalcVO.getBackoct03Oct30());
					demandVo.setOct31Nov27(plannedSupplierCalcVO.getBackoct31Nov27());
					demandVo.setPastDue(plannedSupplierCalcVO.getBackpastDue());
				}
				if(demands.getProductCode().equalsIgnoreCase("Supplier Commit to Planned")){
					
					supplierCommitCalcVO.setcumbackapr11Apr17(demands.getApr11Apr17());
					supplierCommitCalcVO.setcumbackapr18Apr24(demands.getApr18Apr24());
					supplierCommitCalcVO.setcumbackapr25May01(demands.getApr25May01());
					supplierCommitCalcVO.setcumbackaug01Aug28(demands.getAug01Aug28());
					supplierCommitCalcVO.setcumbackaug29Oct02(demands.getAug29Oct02());
					supplierCommitCalcVO.setcumbackfeb29Mar06(demands.getFeb29Mar06());
					supplierCommitCalcVO.setcumbackjan02Jan29(demands.getJan02Jan29());
					supplierCommitCalcVO.setcumbackjan30Feb26(demands.getJan30Feb26());
					supplierCommitCalcVO.setcumbackjul04Jul31(demands.getJul04Jul31());
					supplierCommitCalcVO.setcumbackmar07Mar13(demands.getMar07Mar13());
					supplierCommitCalcVO.setcumbackmar14Mar20(demands.getMar14Mar20());
					supplierCommitCalcVO.setcumbackmar21Mar27(demands.getMar21Mar27());
					supplierCommitCalcVO.setcumbackmar28Apr03((demands.getMar28Apr03()));
					supplierCommitCalcVO.setcumbackmay02May08(demands.getMay02May08());
					supplierCommitCalcVO.setcumbackmay09May15(demands.getMay09May15());
					supplierCommitCalcVO.setcumbackmay16May22(demands.getMay16May22());
					supplierCommitCalcVO.setcumbackmay23May29(demands.getMay23May29());
					supplierCommitCalcVO.setcumbackmay30Jul03(demands.getMay30Jul03());
					supplierCommitCalcVO.setcumbacknov28Jan01(demands.getNov28Jan01());
					supplierCommitCalcVO.setcumbackoct03Oct30(demands.getOct03Oct30());
					supplierCommitCalcVO.setcumbackoct31Nov27(demands.getOct31Nov27());
					supplierCommitCalcVO.setcumbackapr04Apr10(demands.getApr04Apr10());
					supplierCommitCalcVO.setcumbackpastDue(demands.getPastDue());
					
					//setting it to main VO
					
					demandVo.setApr04Apr10(supplierCommitCalcVO.getcumbackapr04Apr10());
					demandVo.setApr11Apr17(supplierCommitCalcVO.getcumbackapr11Apr17());
					demandVo.setApr18Apr24(supplierCommitCalcVO.getcumbackapr18Apr24());
					demandVo.setApr25May01(supplierCommitCalcVO.getcumbackapr25May01());
					demandVo.setAug01Aug28(supplierCommitCalcVO.getcumbackaug01Aug28());
					demandVo.setAug29Oct02(supplierCommitCalcVO.getcumbackaug29Oct02());
					demandVo.setFeb29Mar06(supplierCommitCalcVO.getcumbackfeb29Mar06());
					demandVo.setJan02Jan29(supplierCommitCalcVO.getcumbackjan02Jan29());
					demandVo.setJan30Feb26(supplierCommitCalcVO.getcumbackjan30Feb26());
					demandVo.setJul04Jul31(supplierCommitCalcVO.getcumbackjul04Jul31());
					demandVo.setMar07Mar13(supplierCommitCalcVO.getcumbackmar07Mar13());
					demandVo.setMar14Mar20(supplierCommitCalcVO.getcumbackmar14Mar20());
					demandVo.setMar21Mar27(supplierCommitCalcVO.getcumbackmar21Mar27());
					demandVo.setMar28Apr03((supplierCommitCalcVO.getcumbackmar28Apr03()));
					demandVo.setMay02May08(supplierCommitCalcVO.getcumbackmay02May08());
					demandVo.setMay09May15(supplierCommitCalcVO.getcumbackmay09May15());
					demandVo.setMay16May22(supplierCommitCalcVO.getcumbackmay16May22());
					demandVo.setMay23May29(supplierCommitCalcVO.getcumbackmay23May29());
					demandVo.setMay30Jul03(supplierCommitCalcVO.getcumbackmay30Jul03());
					demandVo.setNov28Jan01(supplierCommitCalcVO.getcumbacknov28Jan01());
					demandVo.setOct03Oct30(supplierCommitCalcVO.getcumbackoct03Oct30());
					demandVo.setOct31Nov27(supplierCommitCalcVO.getcumbackoct31Nov27());
					demandVo.setPastDue(supplierCommitCalcVO.getcumbackpastDue());
					
					
				}
				else if(demands.getProductCode().equalsIgnoreCase("Backlog")){
					backLogCalcVO.setBackpastDue(demands.getPastDue());
					
					//Planned for Supplier - Supplier Commit to Planned
					
					backLogCalcVO.setBackapr04Apr10(plannedSupplierCalcVO.getBackapr04Apr10().subtract(supplierCommitCalcVO.getcumbackapr04Apr10()));
					backLogCalcVO.setBackapr11Apr17(plannedSupplierCalcVO.getBackapr11Apr17().subtract(supplierCommitCalcVO.getcumbackapr11Apr17()));
					backLogCalcVO.setBackapr18Apr24(plannedSupplierCalcVO.getBackapr18Apr24().subtract(supplierCommitCalcVO.getcumbackapr18Apr24()));
					backLogCalcVO.setBackapr25May01(plannedSupplierCalcVO.getBackapr25May01().subtract(supplierCommitCalcVO.getcumbackapr25May01()));
					backLogCalcVO.setBackaug01Aug28(plannedSupplierCalcVO.getBackaug01Aug28().subtract(supplierCommitCalcVO.getcumbackaug01Aug28()));
					backLogCalcVO.setBackaug29Oct02(plannedSupplierCalcVO.getBackaug29Oct02().subtract(supplierCommitCalcVO.getcumbackaug29Oct02()));
					backLogCalcVO.setBackfeb29Mar06(plannedSupplierCalcVO.getBackfeb29Mar06().subtract(supplierCommitCalcVO.getcumbackfeb29Mar06()));
					backLogCalcVO.setBackjan02Jan29(plannedSupplierCalcVO.getBackjan02Jan29().subtract(supplierCommitCalcVO.getcumbackjan02Jan29()));
					backLogCalcVO.setBackjan30Feb26(plannedSupplierCalcVO.getBackjan30Feb26().subtract(supplierCommitCalcVO.getcumbackjan30Feb26()));
					backLogCalcVO.setBackjul04Jul31(plannedSupplierCalcVO.getBackjul04Jul31().subtract(supplierCommitCalcVO.getcumbackjul04Jul31()));
					backLogCalcVO.setBackmar07Mar13(plannedSupplierCalcVO.getBackmar07Mar13().subtract(supplierCommitCalcVO.getcumbackmar07Mar13()));
					backLogCalcVO.setBackmar14Mar20(plannedSupplierCalcVO.getBackmar14Mar20().subtract(supplierCommitCalcVO.getcumbackmar14Mar20()));
					backLogCalcVO.setBackmar21Mar27(plannedSupplierCalcVO.getBackmar21Mar27().subtract(supplierCommitCalcVO.getcumbackmar21Mar27()));
					backLogCalcVO.setBackmar28Apr03((plannedSupplierCalcVO.getBackmar28Apr03().subtract(supplierCommitCalcVO.getcumbackmar28Apr03())));
					backLogCalcVO.setBackmay02May08(plannedSupplierCalcVO.getBackmay02May08().subtract(supplierCommitCalcVO.getcumbackmay02May08()));
					backLogCalcVO.setBackmay09May15(plannedSupplierCalcVO.getBackmay09May15().subtract(supplierCommitCalcVO.getcumbackmay09May15()));
					backLogCalcVO.setBackmay16May22(plannedSupplierCalcVO.getBackmay16May22().subtract(supplierCommitCalcVO.getcumbackmay16May22()));
					backLogCalcVO.setBackmay23May29(plannedSupplierCalcVO.getBackmay23May29().subtract(supplierCommitCalcVO.getcumbackmay23May29()));
					backLogCalcVO.setBackmay30Jul03(plannedSupplierCalcVO.getBackmay30Jul03().subtract(supplierCommitCalcVO.getcumbackmay30Jul03()));
					backLogCalcVO.setBacknov28Jan01(plannedSupplierCalcVO.getBacknov28Jan01().subtract(supplierCommitCalcVO.getcumbacknov28Jan01()));
					backLogCalcVO.setBackoct03Oct30(plannedSupplierCalcVO.getBackoct03Oct30().subtract(supplierCommitCalcVO.getcumbackoct03Oct30()));
					backLogCalcVO.setBackoct31Nov27(plannedSupplierCalcVO.getBackoct31Nov27().subtract(supplierCommitCalcVO.getcumbackoct31Nov27()));
					
					//setting the details to MAIN vo
					
					demandVo.setApr04Apr10(backLogCalcVO.getBackapr04Apr10());
					demandVo.setApr11Apr17(backLogCalcVO.getBackapr11Apr17());
					demandVo.setApr18Apr24(backLogCalcVO.getBackapr18Apr24());
					demandVo.setApr25May01(backLogCalcVO.getBackapr25May01());
					demandVo.setAug01Aug28(backLogCalcVO.getBackaug01Aug28());
					demandVo.setAug29Oct02(backLogCalcVO.getBackaug29Oct02());
					demandVo.setFeb29Mar06(backLogCalcVO.getBackfeb29Mar06());
					demandVo.setJan02Jan29(backLogCalcVO.getBackjan02Jan29());
					demandVo.setJan30Feb26(backLogCalcVO.getBackjan30Feb26());
					demandVo.setJul04Jul31(backLogCalcVO.getBackjul04Jul31());
					demandVo.setMar07Mar13(backLogCalcVO.getBackmar07Mar13());
					demandVo.setMar14Mar20(backLogCalcVO.getBackmar14Mar20());
					demandVo.setMar21Mar27(backLogCalcVO.getBackmar21Mar27());
					demandVo.setMar28Apr03((backLogCalcVO.getBackmar28Apr03()));
					demandVo.setMay02May08(backLogCalcVO.getBackmay02May08());
					demandVo.setMay09May15(backLogCalcVO.getBackmay09May15());
					demandVo.setMay16May22(backLogCalcVO.getBackmay16May22());
					demandVo.setMay23May29(backLogCalcVO.getBackmay23May29());
					demandVo.setMay30Jul03(backLogCalcVO.getBackmay30Jul03());
					demandVo.setNov28Jan01(backLogCalcVO.getBacknov28Jan01());
					demandVo.setOct03Oct30(backLogCalcVO.getBackoct03Oct30());
					demandVo.setOct31Nov27(backLogCalcVO.getBackoct31Nov27());
					demandVo.setPastDue(backLogCalcVO.getBackpastDue());
					
				}else if(demands.getProductCode().equalsIgnoreCase("Cum.Backlog")){
					//demandVo.setPastDue(demands.getPastDue());
					
					cumBackLogCalcVO.setcumbackapr11Apr17(demands.getApr11Apr17());
					cumBackLogCalcVO.setcumbackapr18Apr24(demands.getApr18Apr24());
					cumBackLogCalcVO.setcumbackapr25May01(demands.getApr25May01());
					cumBackLogCalcVO.setcumbackaug01Aug28(demands.getAug01Aug28());
					cumBackLogCalcVO.setcumbackaug29Oct02(demands.getAug29Oct02());
					cumBackLogCalcVO.setcumbackfeb29Mar06(demands.getFeb29Mar06());
					cumBackLogCalcVO.setcumbackjan02Jan29(demands.getJan02Jan29());
					cumBackLogCalcVO.setcumbackjan30Feb26(demands.getJan30Feb26());
					cumBackLogCalcVO.setcumbackjul04Jul31(demands.getJul04Jul31());
					cumBackLogCalcVO.setcumbackmar07Mar13(demands.getMar07Mar13());
					cumBackLogCalcVO.setcumbackmar14Mar20(demands.getMar14Mar20());
					cumBackLogCalcVO.setcumbackmar21Mar27(demands.getMar21Mar27());
					cumBackLogCalcVO.setcumbackmar28Apr03((demands.getMar28Apr03()));
					cumBackLogCalcVO.setcumbackmay02May08(demands.getMay02May08());
					cumBackLogCalcVO.setcumbackmay09May15(demands.getMay09May15());
					cumBackLogCalcVO.setcumbackmay16May22(demands.getMay16May22());
					cumBackLogCalcVO.setcumbackmay23May29(demands.getMay23May29());
					cumBackLogCalcVO.setcumbackmay30Jul03(demands.getMay30Jul03());
					cumBackLogCalcVO.setcumbacknov28Jan01(demands.getNov28Jan01());
					cumBackLogCalcVO.setcumbackoct03Oct30(demands.getOct03Oct30());
					cumBackLogCalcVO.setcumbackoct31Nov27(demands.getOct31Nov27());
					cumBackLogCalcVO.setcumbackapr04Apr10(demands.getApr04Apr10());
					cumBackLogCalcVO.setcumbackpastDue(demands.getPastDue());
					
					
					//cumBackLogCalcVO.setcumbackpastDue((backLogCalcVO.getBackpastDue()));
					
					cumBackLogCalcVO.setcumbackfeb29Mar06(cumBackLogCalcVO.getcumbackpastDue().add(backLogCalcVO.getBackfeb29Mar06()));
					
					cumBackLogCalcVO.setcumbackmar07Mar13(cumBackLogCalcVO.getcumbackfeb29Mar06().add(backLogCalcVO.getBackmar07Mar13()));
					
					cumBackLogCalcVO.setcumbackmar14Mar20(cumBackLogCalcVO.getcumbackmar07Mar13().add(backLogCalcVO.getBackmar14Mar20()));
					
					cumBackLogCalcVO.setcumbackmar21Mar27(cumBackLogCalcVO.getcumbackmar14Mar20().add(backLogCalcVO.getBackmar21Mar27()));
					
					cumBackLogCalcVO.setcumbackmar28Apr03((cumBackLogCalcVO.getcumbackmar21Mar27().add(backLogCalcVO.getBackmar28Apr03())));
										
					cumBackLogCalcVO.setcumbackapr04Apr10((cumBackLogCalcVO.getcumbackmar28Apr03().add(backLogCalcVO.getBackapr04Apr10())));

					cumBackLogCalcVO.setcumbackapr11Apr17((cumBackLogCalcVO.getcumbackapr04Apr10().add(backLogCalcVO.getBackapr11Apr17())));
					
					cumBackLogCalcVO.setcumbackapr18Apr24((cumBackLogCalcVO.getcumbackapr11Apr17().add(backLogCalcVO.getBackapr18Apr24())));
					
					cumBackLogCalcVO.setcumbackapr25May01(cumBackLogCalcVO.getcumbackapr18Apr24().add(backLogCalcVO.getBackapr25May01()));
					
					cumBackLogCalcVO.setcumbackmay02May08(cumBackLogCalcVO.getcumbackapr25May01().add(backLogCalcVO.getBackmay02May08()));
					
					cumBackLogCalcVO.setcumbackmay09May15(cumBackLogCalcVO.getcumbackmay02May08().add(backLogCalcVO.getBackmay09May15()));
					
					cumBackLogCalcVO.setcumbackmay16May22(cumBackLogCalcVO.getcumbackmay09May15().add(backLogCalcVO.getBackmay16May22()));
					
					cumBackLogCalcVO.setcumbackmay23May29(cumBackLogCalcVO.getcumbackmay16May22().add(backLogCalcVO.getBackmay23May29()));
					
					cumBackLogCalcVO.setcumbackmay30Jul03(cumBackLogCalcVO.getcumbackmay23May29().add(backLogCalcVO.getBackmay30Jul03()));
					
					cumBackLogCalcVO.setcumbackjul04Jul31(cumBackLogCalcVO.getcumbackmay30Jul03().add(backLogCalcVO.getBackjul04Jul31()));
					
					cumBackLogCalcVO.setcumbackaug01Aug28(cumBackLogCalcVO.getcumbackjul04Jul31().add(backLogCalcVO.getBackaug01Aug28()));
					
					cumBackLogCalcVO.setcumbackaug29Oct02(cumBackLogCalcVO.getcumbackaug01Aug28().add(backLogCalcVO.getBackaug29Oct02()));
					
					cumBackLogCalcVO.setcumbackoct03Oct30(cumBackLogCalcVO.getcumbackaug29Oct02().add(backLogCalcVO.getBackoct03Oct30()));
					
					cumBackLogCalcVO.setcumbackoct31Nov27(cumBackLogCalcVO.getcumbackoct03Oct30().add(backLogCalcVO.getBackoct31Nov27()));
					
					cumBackLogCalcVO.setcumbacknov28Jan01(cumBackLogCalcVO.getcumbackoct31Nov27().add(backLogCalcVO.getBacknov28Jan01()));
					
					cumBackLogCalcVO.setcumbackjan02Jan29(cumBackLogCalcVO.getcumbacknov28Jan01().add(backLogCalcVO.getBackjan02Jan29()));
					
					cumBackLogCalcVO.setcumbackjan30Feb26(cumBackLogCalcVO.getcumbackjan02Jan29().add(backLogCalcVO.getBackjan30Feb26()));
					
					//setting the details to MAIN vo
					
					demandVo.setApr04Apr10(cumBackLogCalcVO.getcumbackapr04Apr10());
					demandVo.setApr11Apr17(cumBackLogCalcVO.getcumbackapr11Apr17());
					demandVo.setApr18Apr24(cumBackLogCalcVO.getcumbackapr18Apr24());
					demandVo.setApr25May01(cumBackLogCalcVO.getcumbackapr25May01());
					demandVo.setAug01Aug28(cumBackLogCalcVO.getcumbackaug01Aug28());
					demandVo.setAug29Oct02(cumBackLogCalcVO.getcumbackaug29Oct02());
					demandVo.setFeb29Mar06(cumBackLogCalcVO.getcumbackfeb29Mar06());
					demandVo.setJan02Jan29(cumBackLogCalcVO.getcumbackjan02Jan29());
					demandVo.setJan30Feb26(cumBackLogCalcVO.getcumbackjan30Feb26());
					demandVo.setJul04Jul31(cumBackLogCalcVO.getcumbackjul04Jul31());
					demandVo.setMar07Mar13(cumBackLogCalcVO.getcumbackmar07Mar13());
					demandVo.setMar14Mar20(cumBackLogCalcVO.getcumbackmar14Mar20());
					demandVo.setMar21Mar27(cumBackLogCalcVO.getcumbackmar21Mar27());
					demandVo.setMar28Apr03((cumBackLogCalcVO.getcumbackmar28Apr03()));
					demandVo.setMay02May08(cumBackLogCalcVO.getcumbackmay02May08());
					demandVo.setMay09May15(cumBackLogCalcVO.getcumbackmay09May15());
					demandVo.setMay16May22(cumBackLogCalcVO.getcumbackmay16May22());
					demandVo.setMay23May29(cumBackLogCalcVO.getcumbackmay23May29());
					demandVo.setMay30Jul03(cumBackLogCalcVO.getcumbackmay30Jul03());
					demandVo.setNov28Jan01(cumBackLogCalcVO.getcumbacknov28Jan01());
					demandVo.setOct03Oct30(cumBackLogCalcVO.getcumbackoct03Oct30());
					demandVo.setOct31Nov27(cumBackLogCalcVO.getcumbackoct31Nov27());
					demandVo.setPastDue(cumBackLogCalcVO.getcumbackpastDue());
					
					
				}else{
					demandVo.setApr11Apr17(demands.getApr11Apr17());
					demandVo.setApr18Apr24(demands.getApr18Apr24());
					demandVo.setApr25May01(demands.getApr25May01());
					demandVo.setAug01Aug28(demands.getAug01Aug28());
					demandVo.setAug29Oct02(demands.getAug29Oct02());
					demandVo.setFeb29Mar06(demands.getFeb29Mar06());
					demandVo.setJan02Jan29(demands.getJan02Jan29());
					demandVo.setJan30Feb26(demands.getJan30Feb26());
					demandVo.setJul04Jul31(demands.getJul04Jul31());
					demandVo.setMar07Mar13(demands.getMar07Mar13());
					demandVo.setMar14Mar20(demands.getMar14Mar20());
					demandVo.setMar21Mar27(demands.getMar21Mar27());
					demandVo.setMar28Apr03((demands.getMar28Apr03()));
					demandVo.setMay02May08(demands.getMay02May08());
					demandVo.setMay09May15(demands.getMay09May15());
					demandVo.setMay16May22(demands.getMay16May22());
					demandVo.setMay23May29(demands.getMay23May29());
					demandVo.setMay30Jul03(demands.getMay30Jul03());
					demandVo.setNov28Jan01(demands.getNov28Jan01());
					demandVo.setOct03Oct30(demands.getOct03Oct30());
					demandVo.setOct31Nov27(demands.getOct31Nov27());
					demandVo.setApr04Apr10(demands.getApr04Apr10());
				}
				
				demandVo.setDemandId(demands.getDemandId());
				demandVo.setSentFlag(demands.getSentFlag());
				demandVo.setEditFlag(demands.getEditFlag());
				demandVo.setPastDue(demands.getPastDue());
				//demandDateVoList.add(dateVO);
				//quantityTypeVO.setDemandDateVos(demandDateVoList);
				//quantityVoList.add(quantityTypeVO);
				//demandVo.setQuantityVos(quantityVoList);
				demandVos.add(demandVo);
			}
			//ExcelUtil excelUtil = new ExcelUtil();
			ExcelUtil.writeDataToExcel(demandVos,response);
			/*entity = ResponseEntity
		            .ok()
		            .contentLength(pdfFile.contentLength())
		            .contentType(
		                    MediaType.parseMediaType("application/octet-stream"))
		            .body(new InputStreamResource(pdfFile.getInputStream()));*/
			
			
			}


		 catch (Exception e) {
			System.out.println("HospitalAlarmService.downloadDemanDetailsinExcelWithoutFilter()" + e);
		}
		//return entity;
		

	}
	
	
	@RequestMapping(value = "/view/updateDemandDetails", method = RequestMethod.POST, produces="application/json")
	public @ResponseBody void updateDemandDetails(@RequestBody @Valid final GetsDemand demand) {
		 GetsDemand checkDemand = null;
		try {
			checkDemand = demandUpdateRepository.findOne(demand.getDispositionId());
			
			if(null != checkDemand){
				checkDemand.setApr04Apr10(demand.getApr04Apr10());
				checkDemand.setApr11Apr17(demand.getApr11Apr17());
				checkDemand.setApr18Apr24(demand.getApr18Apr24());
				checkDemand.setApr25May01(demand.getApr25May01());
				checkDemand.setAug01Aug28(demand.getAug01Aug28());
				checkDemand.setAug29Oct02(demand.getAug29Oct02());
				checkDemand.setFeb29Mar06(demand.getFeb29Mar06());
				checkDemand.setJan02Jan29(demand.getJan02Jan29());
				checkDemand.setJan30Feb26(demand.getJan30Feb26());
				checkDemand.setJul04Jul31(demand.getJul04Jul31());
				checkDemand.setMar07Mar13(demand.getMar07Mar13());
				checkDemand.setMar14Mar20(demand.getMar14Mar20());
				checkDemand.setMar21Mar27(demand.getMar21Mar27());
				checkDemand.setMar28Apr03(demand.getMar28Apr03());
				checkDemand.setMay02May08(demand.getMay02May08());
				checkDemand.setMay09May15(demand.getMay09May15());
				checkDemand.setMay16May22(demand.getMay16May22());
				checkDemand.setMay23May29(demand.getMay23May29());
				checkDemand.setMay30Jul03(demand.getMay30Jul03());
				checkDemand.setNov28Jan01(demand.getNov28Jan01());
				checkDemand.setOct03Oct30(demand.getOct03Oct30());
				checkDemand.setOct31Nov27(demand.getOct31Nov27());
				
				demandUpdateRepository.save(checkDemand);
				
			}
				
			}
			
			
		 catch (Exception e) {
			System.out.println("HospitalAlarmService.getDemandDetailsWithOutFilter()" + e);
		}
	
	}
	
	
	@RequestMapping("/view/getDemandAllDetailsWithOutFilterRole/{userName}")
	public @ResponseBody List<DemandsDetailsVO> getDemandAllDetailsWithOutFilter(@PathVariable("userName") String userName) {
		 List<DemandsDetailsVO> demandVos = new ArrayList<DemandsDetailsVO>();
		 DemandsDetailsVO demandVo = null;
		 List<GetsDemand> demandList  = null;
		 String rollName = null;
		
		try {
			if(null!= userName){
				
				demandList = demandRepo.findByUserName(userName, new Sort(Sort.Direction.ASC, "dispositionId"));
			  
				if(demandList.size()>0){
					rollName = demandList.get(0).getRollName();
					if(rollName.equalsIgnoreCase("Buyer")){
						demandList.clear();
						demandList = demandRepo.findAll(new Sort(Sort.Direction.ASC, "dispositionId"));
						
					}
					
				}
				
			for(GetsDemand demands : demandList){
				demandVo = new DemandsDetailsVO();
				
				if(demands.getSentFlag().equalsIgnoreCase("false")){
					demandVo.setItemNumber("");
					demandVo.setItemDescription("");
					demandVo.setSupplierName("");
					demandVo.setInventoryOrganization("");
				}else{
					
					demandVo.setItemNumber(demands.getItemNumber());
					demandVo.setItemDescription(demands.getItemDescription());
					demandVo.setSupplierName(demands.getSupplierName());
					demandVo.setInventoryOrganization(demands.getInventoryOrganization());
				}
				
				demandVo.setDispositionId(demands.getDispositionId());
								
				//setting the date type
				demandVo.setQuantityType(demands.getProductCode());
				demandVo.setApr04Apr10(demands.getApr04Apr10());
				demandVo.setApr11Apr17(demands.getApr11Apr17());
				demandVo.setApr18Apr24(demands.getApr18Apr24());
				demandVo.setApr25May01(demands.getApr25May01());
				demandVo.setAug01Aug28(demands.getAug01Aug28());
				demandVo.setAug29Oct02(demands.getAug29Oct02());
				demandVo.setFeb29Mar06(demands.getFeb29Mar06());
				demandVo.setJan02Jan29(demands.getJan02Jan29());
				demandVo.setJan30Feb26(demands.getJan30Feb26());
				demandVo.setJul04Jul31(demands.getJul04Jul31());
				demandVo.setMar07Mar13(demands.getMar07Mar13());
				demandVo.setMar14Mar20(demands.getMar14Mar20());
				demandVo.setMar21Mar27(demands.getMar21Mar27());
				demandVo.setMar28Apr03(demands.getMar28Apr03());
				demandVo.setMay02May08(demands.getMay02May08());
				demandVo.setMay09May15(demands.getMay09May15());
				demandVo.setMay16May22(demands.getMay16May22());
				demandVo.setMay23May29(demands.getMay23May29());
				demandVo.setMay30Jul03(demands.getMay30Jul03());
				demandVo.setNov28Jan01(demands.getNov28Jan01());
				demandVo.setOct03Oct30(demands.getOct03Oct30());
				demandVo.setOct31Nov27(demands.getOct31Nov27());
				
				demandVo.setDemandId(demands.getDemandId());
				demandVo.setSentFlag(demands.getSentFlag());
				demandVo.setEditFlag(demands.getEditFlag());
				demandVo.setPastDue(demands.getPastDue());
				
				//demandDateVoList.add(dateVO);
				//quantityTypeVO.setDemandDateVos(demandDateVoList);
				//quantityVoList.add(quantityTypeVO);
				//demandVo.setQuantityVos(quantityVoList);
				demandVos.add(demandVo);
				
			}
		}	
			
			}


		 catch (Exception e) {
			System.out.println("HospitalAlarmService.getDemandDetailsWithOutFilter()" + e);
		}
		return demandVos;

	}
	
	@RequestMapping(value = "/view/getDemandAllDetailsWithFilterRole", method = RequestMethod.POST, produces="application/json")
	public @ResponseBody List<DemandsDetailsVO> getDemandAllDetailsWithFilterRole(@RequestBody @Valid final GetsDemand demand) {
		
		 List<GetsDemand> demandList  = null;
		 List<DemandsDetailsVO> demandVos = new ArrayList<DemandsDetailsVO>();
		 DemandsDetailsVO demandVo = null;
		 String rollName = null;
		
		try {
		
			if(null!= demand.getUserName()){
				
				demandList = demandRepo.findByUserName(demand.getUserName(), new Sort(Sort.Direction.ASC, "dispositionId"));
			  
				if(demandList.size()>0){
					rollName = demandList.get(0).getRollName();
					if(rollName.equalsIgnoreCase("Buyer")){
						demandList.clear();
						//demandList = demandRepo.findAll(new Sort(Sort.Direction.ASC, "dispositionId"));
						DemandSearchSpecification demandSearchSpecification = new DemandSearchSpecification(demand);
						demandList = demandSearchRepo.findAll(demandSearchSpecification);
						
					}else{
						DemandSearchSupplierSpecification demandSearchSpecification = new DemandSearchSupplierSpecification(demand);
						demandList = demandSearchRepo.findAll(demandSearchSpecification);
					}
					
				}
			
					
			for(GetsDemand demands : demandList){
				demandVo = new DemandsDetailsVO();
				
				if(demands.getSentFlag().equalsIgnoreCase("false")){
					demandVo.setItemNumber("");
					demandVo.setItemDescription("");
					demandVo.setSupplierName("");
					demandVo.setInventoryOrganization("");
				}else{
					
					demandVo.setItemNumber(demands.getItemNumber());
					demandVo.setItemDescription(demands.getItemDescription());
					demandVo.setSupplierName(demands.getSupplierName());
					demandVo.setInventoryOrganization(demands.getInventoryOrganization());
				}
				
				demandVo.setDispositionId(demands.getDispositionId());
				
				//setting the date type
				demandVo.setQuantityType(demands.getProductCode());
				demandVo.setApr04Apr10(demands.getApr04Apr10());
				demandVo.setApr11Apr17(demands.getApr11Apr17());
				demandVo.setApr18Apr24(demands.getApr18Apr24());
				demandVo.setApr25May01(demands.getApr25May01());
				demandVo.setAug01Aug28(demands.getAug01Aug28());
				demandVo.setAug29Oct02(demands.getAug29Oct02());
				demandVo.setFeb29Mar06(demands.getFeb29Mar06());
				demandVo.setJan02Jan29(demands.getJan02Jan29());
				demandVo.setJan30Feb26(demands.getJan30Feb26());
				demandVo.setJul04Jul31(demands.getJul04Jul31());
				demandVo.setMar07Mar13(demands.getMar07Mar13());
				demandVo.setMar14Mar20(demands.getMar14Mar20());
				demandVo.setMar21Mar27(demands.getMar21Mar27());
				demandVo.setMar28Apr03(demands.getMar28Apr03());
				demandVo.setMay02May08(demands.getMay02May08());
				demandVo.setMay09May15(demands.getMay09May15());
				demandVo.setMay16May22(demands.getMay16May22());
				demandVo.setMay23May29(demands.getMay23May29());
				demandVo.setMay30Jul03(demands.getMay30Jul03());
				demandVo.setNov28Jan01(demands.getNov28Jan01());
				demandVo.setOct03Oct30(demands.getOct03Oct30());
				demandVo.setOct31Nov27(demands.getOct31Nov27());
				
				demandVo.setDemandId(demands.getDemandId());
				demandVo.setSentFlag(demands.getSentFlag());
				demandVo.setEditFlag(demands.getEditFlag());
				
				//demandDateVoList.add(dateVO);
				//quantityTypeVO.setDemandDateVos(demandDateVoList);
				//quantityVoList.add(quantityTypeVO);
				//demandVo.setQuantityVos(quantityVoList);
				demandVos.add(demandVo);
				
			}
				}	
					}


		 catch (Exception e) {
			System.out.println("HospitalAlarmService.getDemandAllDetailsWithFilterRole()" + e);
		}
		return demandVos;

	}
	
	@RequestMapping(value = "/view/downloadExcelSearchWithFilter/{itemNumber}/{buyerName}/{supplierName}/{supplierCode}/{buissnessUnit}", method = RequestMethod.GET)
	public @ResponseBody List<DemandsDetailsVO> downloadExcelSearchWithFilter(
			@PathVariable("itemNumber") String itemNumber,
			@PathVariable("buyerName") String buyerName,
			@PathVariable("supplierName") String supplierName,
			@PathVariable("supplierCode") String supplierCode,
			@PathVariable("buissnessUnit") String buissnessUnit,
			HttpServletResponse response) {
		
		
		 List<DemandsDetailsVO> demandVos = new ArrayList<DemandsDetailsVO>();
		 DemandsDetailsVO demandVo = null;
		// QuantityTypeVO quantityTypeVO = null;
		// DemandDateVO dateVO = null;
		// List<QuantityTypeVO> quantityVoList = new ArrayList<QuantityTypeVO>();
		 //List<DemandDateVO>  demandDateVoList = new ArrayList<DemandDateVO>();
		try {
			DemandSearchSpecificationFilterExcel demandSearchSpecification = new DemandSearchSpecificationFilterExcel(itemNumber,buyerName,supplierName,supplierCode,buissnessUnit);
			List<GetsDemand> demandList = demandSearchRepo.findAll(demandSearchSpecification, new Sort(Sort.Direction.ASC, "dispositionId"));
			
			for(GetsDemand demands : demandList){
				demandVo = new DemandsDetailsVO();
				//quantityTypeVO = new QuantityTypeVO();
				//dateVO = new DemandDateVO();
				
				demandVo.setDispositionId(demands.getDispositionId());
				demandVo.setItemNumber(demands.getItemNumber());
				demandVo.setItemDescription(demands.getItemDescription());
				demandVo.setSupplierName(demands.getSupplierName());
				demandVo.setInventoryOrganization(demands.getInventoryOrganization());
				//setting quantity type
			//	quantityTypeVO.setQuantityType(demands.getProductCode());
				
				//setting the date type
				demandVo.setQuantityType(demands.getProductCode());
				demandVo.setApr04Apr10(demands.getApr04Apr10());
				demandVo.setApr11Apr17(demands.getApr11Apr17());
				demandVo.setApr18Apr24(demands.getApr18Apr24());
				demandVo.setApr25May01(demands.getApr25May01());
				demandVo.setAug01Aug28(demands.getAug01Aug28());
				demandVo.setAug29Oct02(demands.getAug29Oct02());
				demandVo.setFeb29Mar06(demands.getFeb29Mar06());
				demandVo.setJan02Jan29(demands.getJan02Jan29());
				demandVo.setJan30Feb26(demands.getJan30Feb26());
				demandVo.setJul04Jul31(demands.getJul04Jul31());
				demandVo.setMar07Mar13(demands.getMar07Mar13());
				demandVo.setMar14Mar20(demands.getMar14Mar20());
				demandVo.setMar21Mar27(demands.getMar21Mar27());
				demandVo.setMar28Apr03(demands.getMar28Apr03());
				demandVo.setMay02May08(demands.getMay02May08());
				demandVo.setMay09May15(demands.getMay09May15());
				demandVo.setMay16May22(demands.getMay16May22());
				demandVo.setMay23May29(demands.getMay23May29());
				demandVo.setMay30Jul03(demands.getMay30Jul03());
				demandVo.setNov28Jan01(demands.getNov28Jan01());
				demandVo.setOct03Oct30(demands.getOct03Oct30());
				demandVo.setOct31Nov27(demands.getOct31Nov27());
				
				demandVo.setDemandId(demands.getDemandId());
				demandVo.setSentFlag(demands.getSentFlag());
				demandVo.setEditFlag(demands.getEditFlag());
				demandVo.setPastDue(demands.getPastDue());
				
				//demandDateVoList.add(dateVO);
				//quantityTypeVO.setDemandDateVos(demandDateVoList);
				//quantityVoList.add(quantityTypeVO);
				//demandVo.setQuantityVos(quantityVoList);
				demandVos.add(demandVo);
				
			}
			ExcelUtil.writeDataToExcel(demandVos,response);
			
			
			}


		 catch (Exception e) {
			System.out.println("HospitalAlarmService.getDemandDetailsWithOutFilter()" + e);
		}
		return demandVos;

	}
	 
	
	 @RequestMapping(value = "/view/postOnlyXml", method = RequestMethod.POST, consumes="application/xml",produces="application/xml")
	 public @ResponseBody CommonBaseEvents postOnlyXML(@RequestBody CommonBaseEvents track) {
	      
		 System.out.println("BookingController.postOnlyXML()");
		 String result = "Track saved : " + track;
		 System.out.println("BookingController.postOnlyXML()" + result);
		//String gener =  track.getSinger();
		
		
	//	System.out.println("BookingController.postOnlyXML()" +  gener );
		 
		 //Response.status(201).entity(track).build();
		  
		 return track;
	    }
	 
	 @RequestMapping(value = "/view/postOnlyXmls", method = RequestMethod.POST, consumes="application/xml",produces="application/xml")
	 public @ResponseBody CommonBaseEventType postOnlyXMLs(@RequestBody CommonBaseEventType track) {
		
		 BigDecimal reslut = track.getNs2InformationModelInstance().getNs2FunctionBlockInstances().getNs2FunctionBlockInstance().getNs2Properties().getNutrunner().getStatus().getLastMaintenanceTS();
		// BigDecimal result=  track.getStatus().getCurrentTorque();
		 
		 System.out.println("CommonBaseEvent.postOnlyXML()" + reslut);
		 //String result = "Track saved : " + track;
		// System.out.println("BookingController.postOnlyXML()" + result);
		 //Response.status(201).entity(track).build();
		  
		 return track;
	    }
	 
	 @RequestMapping(value = "/view/postXml", method = RequestMethod.POST, consumes="application/xml",produces="application/xml")
	 public @ResponseBody Track postXML(@RequestBody Track track) {
	      
		 System.out.println("BookingController.postOnlyXML()");
		 String result = "Track saved : " + track;
		 System.out.println("BookingController.postOnlyXML()" + result);
		//String gener =  track.getSinger();
		
		
	//	System.out.println("BookingController.postOnlyXML()" +  gener );
		 
		 //Response.status(201).entity(track).build();
		  
		 return track;
	    }
	 
	 @RequestMapping(value = "/view/postXMLs", method = RequestMethod.POST, consumes="text/plain")
	 public @ResponseBody String postXMLs(@RequestBody String result) {
		
		String results = result;
		System.out.println("BookingController.postXMLs()" + result);
		return results;
		
	    }
	 
	 @RequestMapping("/view/getMachineDataByDeviceId/{deviceId}")
		public @ResponseBody List<Map<Object,Object>> getMachineDataByDeviceId(@PathVariable("deviceId") Long deviceId) {
			/*List<MachineDataVO> machineDatavo = new ArrayList<MachineDataVO>();
			MachineDataVO dataVO = null;*/

			List<Object> retListData = new ArrayList<Object>();
			Map<Object,Object> objMap  = null;
			List<Map<Object,Object>> list = new ArrayList<Map<Object,Object>>();
			try{
				System.out
						.println("HospitalAlarmService.getMachineDataByDeviceId()***********");
				List<Object []> retList = machineDataRepo.getMachineDataByDeviceId(deviceId);
				
				System.out.println("listData!!!!!!!!!!" + retList);
				for(int i = 0; i < retList.size(); i++){
					objMap	= new HashMap<Object, Object>();
					objMap.put("processId", (retList.get(i))[1]);
					String str  = (String) retList.get(i)[0];
					str = str.replaceAll("\\n", "");
					str = str.replaceAll("\\s+","");
					str = str.replaceAll("\\t", "");
					str = str.replaceAll("\\\\", "");
					
					
					JSONParser parser = new JSONParser();
					  
				    JSONObject a = (JSONObject) parser.parse(str);
				   // for(int i = 0; i < a.size(); i++){
				   /* Set<String>	keys = a.keySet(); 
				    for(String ks :keys){
				    	System.out.println("Keys : " + ks);
				     //	String jsonObj = (String)a.get(ks);
				    //	System.out.println("ParseJM2MData.readJson()" + jsonObj);
				    	
				    	if(a.get(ks) instanceof Long){
				    		Long value = (Long)a.get(ks);
				    		System.out.println("ParseJM2MData.readJson()" + value);
				    		
				    	}else if (a.get(ks) instanceof String){
				    		
				    	}else if (a.get(ks) instanceof JSONArray){
				    		
				    	}
				    	
				    }*/
				    	
				    	Long id = (Long) a.get("_id");
				    	Long nutrunnerId = (Long) a.get("nutrunnerId");
				    	Long assetId = (Long) a.get("assetId");
				    	String timestamp = (String)a.get("timestamp");
				    	String result = (String)a.get("result");
				    	String prgdate = (String)a.get("prgdate");
				    	Long nr = (Long) a.get("nr");
				    	String date = (String)a.get("date");
				    	Long prgnr = (Long) a.get("prgnr");
				    	String prgname = (String)a.get("prgname");
				    	String idcode = (String)a.get("idcode");
				    	String toolserial = (String)a.get("toolserial");
				    	Long cycle = (Long) a.get("cycle");
				    	Double MCEfactor = (Double) a.get("MCEfactor");
				    	String celLid = (String) a.get("cellid");
				    	Long nominaltorque = (Long) a.get("nominaltorque");
				    	String torqueunit = (String)a.get("torqueunit");
				    	String channel = (String)a.get("channel");
				    	Double totaltime = (Double) a.get("total time");
				    	JSONArray tighteningsteps = (JSONArray) a.get("tighteningsteps");
				    	//System.out.println("ParseJM2MData.readJson()" + tighteningsteps);
				    	for(int j=0;j<tighteningsteps.size();j++){
				    		//System.out.println("ParseJM2MData.readJson()" + tighteningsteps.get(j));
				    		JSONObject eachRow = (JSONObject) tighteningsteps.get(j);
				    		String resultTight = (String) eachRow.get("result");
				    		String lastcmd = (String) eachRow.get("lastcmd");
				    		Long speed = (Long) eachRow.get("speed");
				    		Double torque = (Double) eachRow.get("torque");
				    		Long anglethresholdnom = (Long) eachRow.get("anglethresholdnom");
				    		Double angle = (Double) eachRow.get("angle");
				    		Long row = (Long) eachRow.get("row");
				    		Double duration = (Double) eachRow.get("duration");
				    		Long category = (Long) eachRow.get("category");
				    		JSONObject jsonObj = (JSONObject) eachRow.get("graph");
				    		JSONArray torquevalues  = (JSONArray) jsonObj.get("torquevalues");
				    		JSONArray timevalues  = (JSONArray) jsonObj.get("timevalues");
				    		JSONArray anglevalues  = (JSONArray) jsonObj.get("anglevalues");
				    		
				    		objMap.put("torquevalues", torquevalues.toString());
				    		objMap.put("timevalues", timevalues.toString());
				    		objMap.put("anglevalues", anglevalues.toString());
				    		
				    		JSONArray tighteningFunc  = (JSONArray) eachRow.get("tighteningfunctions");
				    		
				    		for(int k=0;k<tighteningFunc.size();k++){
				    			JSONObject eachRowtighteningFunc = (JSONObject) tighteningFunc.get(k);
				    			String name = (String) eachRowtighteningFunc.get("name"); 
				    			Double act = (Double) eachRowtighteningFunc.get("act");
				    			Long nom = (Long) eachRowtighteningFunc.get("nom");
				    			
				    			System.out.println("ParseJM2MData.jsonObj()" + name + ":" + act + ":" + nom);
				    		}
				    		
				    				
				    		
				    		
				    		
				    		
				    		System.out.println("ParseJM2MData.readJson()" + eachRow.get("result"));
				    		
				    	}
					
					
					
					retListData.add(str);
					System.out
							.println("String is data: " + retListData);
					/*
					ObjectMapper objectMapper=new ObjectMapper();
					String jsonData=objectMapper.writeValueAsString(str);
					
					System.out
					.println("jsonData data: " + jsonData);*/
					
					
					
					
					list.add(objMap);
					
				}
				
							
			}catch(Exception e){
				System.out.println("HospitalAlarmService.getMachineDataByDeviceId()" + e);
			}
			return list;
			
		}
	 @RequestMapping(value = "/view/postJsonValue", method = RequestMethod.POST, produces="application/json")
		public @ResponseBody String postJsonValue(@RequestBody String jsonValue) {
			System.out
					.println("MachineConnectService.getDemandAllDetailsWithFilter()" + jsonValue);
			
			JSONParser parser = new JSONParser();
			SimpleDateFormat formatter =  new  SimpleDateFormat("yyyy-MM-dd:HH:mm:ss");
			SimpleDateFormat formatter1 =  new  SimpleDateFormat("yyyy-MM-dd:HH:mm:ss");
			
			SimpleDateFormat formatter2 =  new  SimpleDateFormat("yyyy-MM-dd:HH:mm:ss");
		    try {
				JSONObject a = (JSONObject) parser.parse(jsonValue);
				String angleStatus = (String)a.get("angleStatus");
				Long tighteningId = (Long)a.get("tighteningId");
				String idCode = (String)a.get("idCode");
				Long maxAngle = (Long)a.get("maxAngle");
				Long maxTorque = (Long)a.get("maxTorque");
				Long minTorque = (Long)a.get("minTorque");
				Long torque = (Long)a.get("minTorque");
				
				Long minAngle = (Long)a.get("minAngle");
				Long cellId = (Long)a.get("cellId");
				Long targetTorque = (Long)a.get("targetTorque");
				
				String timeLastProgramChange = (String)a.get("timeLastProgramChange");
				Long okCounterLimit = (Long)a.get("okCounterLimit");
				String tighteningStatus = (String)a.get("tighteningStatus");
				Long targetAngle = (Long)a.get("targetAngle");
				String controllerName = (String)a.get("controllerName");
				
				Long okCounter = (Long)a.get("okCounter");
				Long angle = (Long)a.get("angle");
				Long tighteningProgramNumber = (Long)a.get("tighteningProgramNumber");
				String ok_Nokstatus = (String)a.get("ok_Nokstatus");
				Long channelId = (Long)a.get("channelId");
				Long jobNumber = (Long)a.get("jobNumber");
				
				String timestamp = (String)a.get("timestamp");
				String torqueStatus = (String)a.get("torqueStatus");
				Date date =	formatter.parse(timeLastProgramChange);
				String d=	formatter.format(date);
				Date dateTime = formatter.parse(timestamp);
				String aa =	formatter1.format(dateTime);
				
				String results1 = replaceCharAt(d,10,'c');
				results1 = results1.replaceAll("c", " ");
				String results2 = replaceCharAt(aa,10,'c');
				results2 = results2.replaceAll("c", " ");
		/*	Date d1 =	formatter2.parse(d);
			String d2  = formatter2.format(d1);
			
			Date a1= formatter2.parse(aa);
			String a2= formatter2.format(a1);*/
				
				M2mResult result = new M2mResult();
				result.setAnglestatus(angleStatus);
				result.setAngle(BigDecimal.valueOf(angle));
				result.setChannelid(BigDecimal.valueOf(channelId));
				result.setCellid(BigDecimal.valueOf(cellId));
				result.setControllername(controllerName);
				result.setIdcode(idCode);
				result.setJobbigint(BigDecimal.valueOf(jobNumber));
				result.setMaxangle(BigDecimal.valueOf(maxAngle));
				result.setMaxtorque(BigDecimal.valueOf(maxTorque));
				result.setMinangle(BigDecimal.valueOf(minAngle));
				result.setMintorque(BigDecimal.valueOf(minTorque));
				result.setOkcounter(BigDecimal.valueOf(okCounter));
				result.setOkcounterlimit(BigDecimal.valueOf(okCounterLimit));
				result.setTargetangle(BigDecimal.valueOf(targetAngle));
				
				result.setTargettorque(BigDecimal.valueOf(targetTorque));
				result.setTighteingid(BigDecimal.valueOf(tighteningId));
				
				
				result.setTighteningprogrambigint(BigDecimal.valueOf(tighteningProgramNumber));
				result.setTighteningstatus(tighteningStatus);
				result.setTimelastprogramchange(Timestamp.valueOf(results1));
				result.setTimestamp(Timestamp.valueOf(results2));
				result.setTorque(BigDecimal.valueOf(torque));
				result.setTorquestatus(torqueStatus);
				
				M2mDevice device = new M2mDevice();
				device.setId(12);
				result.setM2mDevice(device);
			
				machineResultRepo.save(result);
			/*List<M2mResult>	 devices = machineResultRepo.findByM2mDevice(device);
			if(null!=devices && devices.size()>0){
				machineResultRepo.save(result);
			}*/
				
				
			} catch (ParseException | java.text.ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
			return jsonValue;
			
		}

	public String replaceCharAt(String s, int pos, char c) {
    return s.substring(0, pos) + c + s.substring(pos + 1);
  }
	
}
	
	
	
	
