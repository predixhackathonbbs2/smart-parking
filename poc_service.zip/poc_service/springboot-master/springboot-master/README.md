springboot
==========

Spring Boot Application with web, rest, jpa, thymeleaf
