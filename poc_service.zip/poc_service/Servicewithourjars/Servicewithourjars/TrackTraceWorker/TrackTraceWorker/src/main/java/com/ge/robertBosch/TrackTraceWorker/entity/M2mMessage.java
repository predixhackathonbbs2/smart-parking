package com.ge.robertBosch.TrackTraceWorker.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the M2M_MESSAGES database table.
 * 
 */
@Entity
@Table(name="M2M_MESSAGES")
@NamedQuery(name="M2mMessage.findAll", query="SELECT m FROM M2mMessage m")
public class M2mMessage implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="M2M_MESSAGES_ID_GENERATOR", sequenceName="TT_SEQ_MESSG")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="M2M_MESSAGES_ID_GENERATOR")
	private long id;

	@Column(name="CLASS")
	private String class_;

	private String content;

	private String img;

	private String title;

	//bi-directional many-to-one association to M2mNotification
	@OneToMany(mappedBy="m2mMessage")
	private List<M2mNotification> m2mNotifications;

	public M2mMessage() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getClass_() {
		return this.class_;
	}

	public void setClass_(String class_) {
		this.class_ = class_;
	}

	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getImg() {
		return this.img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<M2mNotification> getM2mNotifications() {
		return this.m2mNotifications;
	}

	public void setM2mNotifications(List<M2mNotification> m2mNotifications) {
		this.m2mNotifications = m2mNotifications;
	}

	public M2mNotification addM2mNotification(M2mNotification m2mNotification) {
		getM2mNotifications().add(m2mNotification);
		m2mNotification.setM2mMessage(this);

		return m2mNotification;
	}

	public M2mNotification removeM2mNotification(M2mNotification m2mNotification) {
		getM2mNotifications().remove(m2mNotification);
		m2mNotification.setM2mMessage(null);

		return m2mNotification;
	}

}
