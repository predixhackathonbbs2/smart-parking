package com.ge.robertBosch.TrackTraceWorker;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ge.robertBosch.TrackTraceWorker.dto.AlarmEvent;
import com.ge.robertBosch.TrackTraceWorker.dto.WorkerVO;
import com.ge.robertBosch.TrackTraceWorker.entity.AlarmEventEntity;
import com.ge.robertBosch.TrackTraceWorker.entity.M2mWorker;
import com.ge.robertBosch.TrackTraceWorker.repository.IAlarmEventEntityRepository;
import com.ge.robertBosch.TrackTraceWorker.repository.IM2MWorkerRepository;
import com.ge.util.RestResponse;

@RestController
public class HospitalAlarmService {

	@Autowired
	private IAlarmEventEntityRepository alarmService;

	@Autowired
	private IM2MWorkerRepository workerRepo;

	@RequestMapping("/TrackTraceWorker")
	public @ResponseBody List<AlarmEvent> helloWorld() {
		List<AlarmEvent> events = new ArrayList<AlarmEvent>();
		List<AlarmEventEntity> entities = this.alarmService.findAll();
		for (AlarmEventEntity entity : entities) {
			events.add(entity.toAlarmEvent());
		}
		return events;
	}

	@RequestMapping("/getWorkerDetails")
	public @ResponseBody List<WorkerVO> getWorkerDetails() {
		List<WorkerVO> workerVOs = new ArrayList<WorkerVO>();
		WorkerVO workerVO = null;
		try {
			List<M2mWorker> workerList = workerRepo.findAll();
			for (M2mWorker workerLst : workerList) {
				workerVO = new WorkerVO();
				workerVO.setId(workerLst.getId());
				workerVO.setEmail(workerLst.getEmail());
				workerVO.setFirstname(workerLst.getFirstname());
				workerVO.setLastname(workerLst.getLastname());
				workerVO.setStatus(workerLst.getStatus());
				workerVO.setCity(workerLst.getCity());
				workerVOs.add(workerVO);
			}

		} catch (Exception e) {
			System.out.println("HospitalAlarmService.getWorkerDetails()" + e);
		}
		return workerVOs;
	}

	@RequestMapping(value = "/createWorker", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public RestResponse createWorker(@RequestBody @Valid final M2mWorker workers) {
		RestResponse response = new RestResponse();
		try {

			M2mWorker worker = new M2mWorker();
			// TtUser user = new TtUser();
			worker.setCity(workers.getCity());
			worker.setEmail(workers.getEmail());
			worker.setFirstname(workers.getFirstname());
			worker.setLastname(workers.getLastname());
			worker.setStatus(workers.getStatus());

			response.setStatus(200);
			response.setMessage("Success");
			// response.setObject(checkUser);
			return response;

		}

		catch (Exception ex) {
			System.out.println("HospitalAllarmService.createWorker()");
			response.setStatus(201);
			response.setMessage("Failure");
			return response;

		}

	}

}
