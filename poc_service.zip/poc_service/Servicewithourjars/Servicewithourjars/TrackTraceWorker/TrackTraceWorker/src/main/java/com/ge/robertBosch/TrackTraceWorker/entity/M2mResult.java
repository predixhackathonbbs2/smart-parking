package com.ge.robertBosch.TrackTraceWorker.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;


/**
 * The persistent class for the M2M_RESULT database table.
 * 
 */
@Entity
@Table(name="M2M_RESULT")
@NamedQuery(name="M2mResult.findAll", query="SELECT m FROM M2mResult m")
public class M2mResult implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="M2M_RESULT_RESULTID_GENERATOR", sequenceName="TT_SEQ_RESULT")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="M2M_RESULT_RESULTID_GENERATOR")
	private long resultid;

	private BigDecimal angle;

	private String anglestatus;

	private BigDecimal cellid;

	private BigDecimal channelid;

	private String controllername;

	private String idcode;

	private BigDecimal jobbigint;

	private BigDecimal maxangle;

	private BigDecimal maxtorque;

	private BigDecimal minangle;

	private BigDecimal mintorque;

	private BigDecimal okcounter;

	private BigDecimal okcounterlimit;

	private BigDecimal targetangle;

	private BigDecimal targettorque;

	private BigDecimal tighteingid;

	private BigDecimal tighteningprogrambigint;

	private String tighteningstatus;

	private Timestamp timelastprogramchange;

	@Column(name="TIMESTAMP")
	private Timestamp timestamp;

	private BigDecimal torque;

	private String torquestatus;

	//bi-directional many-to-one association to M2mDevice
	@ManyToOne
	@JoinColumn(name="DEVICEID",nullable=false)
	private M2mDevice m2mDevice;

	public M2mResult() {
	}

	public long getResultid() {
		return this.resultid;
	}

	public void setResultid(long resultid) {
		this.resultid = resultid;
	}

	public BigDecimal getAngle() {
		return this.angle;
	}

	public void setAngle(BigDecimal angle) {
		this.angle = angle;
	}

	

	public BigDecimal getCellid() {
		return this.cellid;
	}

	public void setCellid(BigDecimal cellid) {
		this.cellid = cellid;
	}

	public BigDecimal getChannelid() {
		return this.channelid;
	}

	public void setChannelid(BigDecimal channelid) {
		this.channelid = channelid;
	}

	public String getControllername() {
		return this.controllername;
	}

	public void setControllername(String controllername) {
		this.controllername = controllername;
	}

	public String getIdcode() {
		return this.idcode;
	}

	public void setIdcode(String idcode) {
		this.idcode = idcode;
	}

	public BigDecimal getJobbigint() {
		return this.jobbigint;
	}

	public void setJobbigint(BigDecimal jobbigint) {
		this.jobbigint = jobbigint;
	}

	public BigDecimal getMaxangle() {
		return this.maxangle;
	}

	public void setMaxangle(BigDecimal maxangle) {
		this.maxangle = maxangle;
	}

	public BigDecimal getMaxtorque() {
		return this.maxtorque;
	}

	public void setMaxtorque(BigDecimal maxtorque) {
		this.maxtorque = maxtorque;
	}

	public BigDecimal getMinangle() {
		return this.minangle;
	}

	public void setMinangle(BigDecimal minangle) {
		this.minangle = minangle;
	}

	public BigDecimal getMintorque() {
		return this.mintorque;
	}

	public void setMintorque(BigDecimal mintorque) {
		this.mintorque = mintorque;
	}

	public BigDecimal getOkcounter() {
		return this.okcounter;
	}

	public void setOkcounter(BigDecimal okcounter) {
		this.okcounter = okcounter;
	}

	public BigDecimal getOkcounterlimit() {
		return this.okcounterlimit;
	}

	public void setOkcounterlimit(BigDecimal okcounterlimit) {
		this.okcounterlimit = okcounterlimit;
	}

	public BigDecimal getTargetangle() {
		return this.targetangle;
	}

	public void setTargetangle(BigDecimal targetangle) {
		this.targetangle = targetangle;
	}

	public BigDecimal getTargettorque() {
		return this.targettorque;
	}

	public void setTargettorque(BigDecimal targettorque) {
		this.targettorque = targettorque;
	}

	public BigDecimal getTighteingid() {
		return this.tighteingid;
	}

	public void setTighteingid(BigDecimal tighteingid) {
		this.tighteingid = tighteingid;
	}

	public BigDecimal getTighteningprogrambigint() {
		return this.tighteningprogrambigint;
	}

	public void setTighteningprogrambigint(BigDecimal tighteningprogrambigint) {
		this.tighteningprogrambigint = tighteningprogrambigint;
	}

	public String getTighteningstatus() {
		return this.tighteningstatus;
	}

	public void setTighteningstatus(String tighteningstatus) {
		this.tighteningstatus = tighteningstatus;
	}

	public Timestamp getTimelastprogramchange() {
		return this.timelastprogramchange;
	}

	public void setTimelastprogramchange(Timestamp timelastprogramchange) {
		this.timelastprogramchange = timelastprogramchange;
	}

	public Timestamp getTimestamp() {
		return this.timestamp;
	}

	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}

	public BigDecimal getTorque() {
		return this.torque;
	}

	public void setTorque(BigDecimal torque) {
		this.torque = torque;
	}

	public String getTorquestatus() {
		return this.torquestatus;
	}

	public void setTorquestatus(String torquestatus) {
		this.torquestatus = torquestatus;
	}

	public M2mDevice getM2mDevice() {
		return this.m2mDevice;
	}

	public void setM2mDevice(M2mDevice m2mDevice) {
		this.m2mDevice = m2mDevice;
	}

	public String getAnglestatus() {
		return anglestatus;
	}

	public void setAnglestatus(String anglestatus) {
		this.anglestatus = anglestatus;
	}

}
