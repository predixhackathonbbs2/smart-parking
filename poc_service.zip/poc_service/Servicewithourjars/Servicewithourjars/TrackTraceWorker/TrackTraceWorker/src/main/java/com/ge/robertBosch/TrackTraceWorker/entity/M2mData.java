package com.ge.robertBosch.TrackTraceWorker.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.*;

import org.hibernate.annotations.Type;


/**
 * The persistent class for the M2M_DATA database table.
 * 
 */
@Entity
@Table(name="M2M_DATA")
@NamedQuery(name="M2mData.findAll", query="SELECT m FROM M2mData m")
public class M2mData implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="M2M_DATA_PROCESSID_GENERATOR", sequenceName="TT_SEQ_DATA")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="M2M_DATA_PROCESSID_GENERATOR")
	@Column(name="PROCESS_ID")
	private long processId;

	//@Lob
	@Column(name="DATA")
	//@Type(type="org.hibernate.type.PrimitiveByteArrayBlobType")
	//@Type(type="org.hibernate.type.BinaryType")
	private String data;

	private BigDecimal tighteingid;

	//bi-directional many-to-one association to M2mDevice
	@ManyToOne
	@JoinColumn(name="DEVICEID")
	private M2mDevice m2mDevice;

	public M2mData() {
	}

	public long getProcessId() {
		return this.processId;
	}

	public void setProcessId(long processId) {
		this.processId = processId;
	}

	public BigDecimal getTighteingid() {
		return this.tighteingid;
	}

	public void setTighteingid(BigDecimal tighteingid) {
		this.tighteingid = tighteingid;
	}

	public M2mDevice getM2mDevice() {
		return this.m2mDevice;
	}

	public void setM2mDevice(M2mDevice m2mDevice) {
		this.m2mDevice = m2mDevice;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	
}
