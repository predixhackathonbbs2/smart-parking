package com.ge.Transport.Scplogin;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ge.Transport.Scplogin.dto.AlarmEvent;
import com.ge.Transport.Scplogin.entity.AlarmEventEntity;
import com.ge.Transport.Scplogin.entity.ScpUser;
import com.ge.Transport.Scplogin.entity.ScpUserRole;
import com.ge.Transport.Scplogin.repository.IAlarmEventEntityRepository;
import com.ge.Transport.Scplogin.repository.IscploginRepository;
import com.ge.scputil.RestResponse;

@RestController
public class HospitalAlarmService {

	@Autowired
	private IAlarmEventEntityRepository alarmService;
	
	@Autowired
	private IscploginRepository loginRepo;

	@RequestMapping("/Scplogin")
	public @ResponseBody List<AlarmEvent> helloWorld() {
		List<AlarmEvent> events = new ArrayList<AlarmEvent>();
		List<AlarmEventEntity> entities = this.alarmService.findAll();
		for (AlarmEventEntity entity:entities) {
			events.add(entity.toAlarmEvent());
		}
		return events;
	}
	
	
	@RequestMapping(value = "/login", method = RequestMethod.POST, produces="application/json")
	@ResponseBody
	public RestResponse login(@RequestBody @Valid final ScpUser user) {
		RestResponse response=new RestResponse();
		try {

			ScpUser checkUser = loginRepo.findUser(user.getUsername());
			System.out.println("checkUser" + checkUser);

			if (null != checkUser) {

				if ((checkUser.getUsername().equalsIgnoreCase(user
						.getUsername()))
						&& (checkUser.getPassword().equalsIgnoreCase(user
								.getPassword()))) {
						ScpUserRole role =	checkUser.getScpUserRole();
						//response.setObject(checkUser);
						response.setStatus(200);
						response.setMessage("Success");
						response.setRoleId(role.getRoleId());
						response.setRoleName(role.getRoleName());
						System.out.println("checkUser" + response);

				} else {
					response.setMessage("Failure");
					response.setStatus(201);

				}
				System.out.println("Response: "+ response);
			} else {
				response.setMessage("NotExist");
				response.setStatus(201);

			}

		}

		catch (Exception ex) {
			System.out.println("HospitalAllarmService.login()");
			response.setStatus(201);
			return response;

		}
		// return status;
		return response;

	}
}
