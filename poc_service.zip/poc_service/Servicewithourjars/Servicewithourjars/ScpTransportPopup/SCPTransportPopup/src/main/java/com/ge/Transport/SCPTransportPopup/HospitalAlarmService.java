package com.ge.Transport.SCPTransportPopup;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ge.Transport.SCPTransportPopup.dto.AlarmEvent;
import com.ge.Transport.SCPTransportPopup.entity.AlarmEventEntity;
import com.ge.Transport.SCPTransportPopup.entity.GetsDemand;
import com.ge.Transport.SCPTransportPopup.repository.IAlarmEventEntityRepository;
import com.ge.Transport.SCPTransportPopup.repository.IDemandEntityRepository;

@RestController
public class HospitalAlarmService {

	@Autowired
	private IAlarmEventEntityRepository alarmService;
	

	@Autowired
	private IDemandEntityRepository demandRepo;

	@RequestMapping("/SCPTransportPopup")
	public @ResponseBody List<AlarmEvent> helloWorld() {
		List<AlarmEvent> events = new ArrayList<AlarmEvent>();
		List<AlarmEventEntity> entities = this.alarmService.findAll();
		for (AlarmEventEntity entity:entities) {
			events.add(entity.toAlarmEvent());
		}
		return events;
	}
	
	
	
	/*@RequestMapping("/getDemandItem")
	public @ResponseBody List<Map<String, Object>> getDemandItem() {
		// List<ItemNumberVO> itemNumberVOs = new ArrayList<ItemNumberVO>();
		// ItemNumberVO itemNumberVO = null;
		// List<GetsDemand> itemList = null;

		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		try {
			List<Object[]> retList = demandRepo.getUniqueItemNumber();

			for (int i = 0; i < retList.size(); i++) {
				objMap = new HashMap<String, Object>();
				objMap.put("itemNumber", (retList.get(i))[0]);
				objMap.put("itemDescription", (retList.get(i))[1]);
				list.add(objMap);
			}

			
			 * itemList = demandRepo.getUniqueItemNumber(); for(GetsDemand
			 * itemLst : itemList){ itemNumberVO = new ItemNumberVO();
			 * itemNumberVO.setItemNumber(itemLst.getItemNumber());
			 * itemNumberVO.setItemDescription(itemLst.getItemDescription());
			 * itemNumberVOs.add(itemNumberVO); }
			 

		} catch (Exception e) {
			System.out.println("HospitalAlarmService.getEngineDetails()" + e);
		}
		return list;

	}*/
	
	//@RequestMapping("/getDemandItem",method = RequestMethod.POST, produces="application/json")
	
	@RequestMapping(value = "/getDemandItemNumberOnSearch", method = RequestMethod.POST, produces="application/json")
	public @ResponseBody List<Map<String, Object>> getDemandItem(
			@RequestBody @Valid final GetsDemand demand) {

		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		try {
			List<Object[]> retList = demandRepo
					.getItemNumberonItemSearch(demand.getItemNumber());

			for (int i = 0; i < retList.size(); i++) {
				objMap = new HashMap<String, Object>();
				objMap.put("itemNumber", (retList.get(i)[0]));
				objMap.put("itemDescription", (retList.get(i)[1]));
				list.add(objMap);
			}

		} catch (Exception e) {
			System.out.println("HospitalAlarmService.getEngineDetails()" + e);
		}
		return list;

	}
	
	/*@RequestMapping("/getSupplierNames")
	public @ResponseBody List<Map<String, Object>> getSupplierNames() {
		// List<ItemNumberVO> itemNumberVOs = new ArrayList<ItemNumberVO>();
		// ItemNumberVO itemNumberVO = null;
		// List<GetsDemand> itemList = null;
		System.out.println("HospitalAlarmService.getSupplierNames()");
		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		try {
			List<Object[]> retList = demandRepo.getUniqueSupplierNames();
			System.out.println("retList.retList()" + retList.size());
			for (int i = 0; i < retList.size(); i++) {
				objMap = new HashMap<String, Object>();
				objMap.put("supplierName", (retList.get(i))[0]);
				//objMap.put("itemDescription", (retList.get(i))[1]);
				list.add(objMap);
			}

			
			 * itemList = demandRepo.getUniqueItemNumber(); for(GetsDemand
			 * itemLst : itemList){ itemNumberVO = new ItemNumberVO();
			 * itemNumberVO.setItemNumber(itemLst.getItemNumber());
			 * itemNumberVO.setItemDescription(itemLst.getItemDescription());
			 * itemNumberVOs.add(itemNumberVO); }
			 

		} catch (Exception e) {
			System.out.println("HospitalAlarmService.getSupplierNames()" + e);
		}
		return list;

	}*/
	
	@RequestMapping(value = "/getSupplierNameOnSearch", method = RequestMethod.POST, produces="application/json")
	public @ResponseBody List<Map<String, Object>> getSupplierNamesOnName(
			@RequestBody @Valid final GetsDemand demand) {

		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		try {
			System.out.println("HospitalAlarmService.getSupplierNamesOnName()");
			List<Object[]> retList = demandRepo.getSupplierNamesOnName(demand.getSupplierName());
					
			System.out.println("retList.getSupplierNamesOnName()" + retList.size());
			for (int i = 0; i < retList.size(); i++) {
				objMap = new HashMap<String, Object>();
				objMap.put("supplierName", (retList.get(i)));
				//objMap.put("id", (retList.get(i))[1]);
				list.add(objMap);
			}

		} catch (Exception e) {
			System.out.println("HospitalAlarmService.getSupplierNamesOnName()" + e);
		}
		return list;

	}
	
	/*@RequestMapping("/getBuyerNames")
	public @ResponseBody List<Map<String, Object>> getBuyerNames() {
		// List<ItemNumberVO> itemNumberVOs = new ArrayList<ItemNumberVO>();
		// ItemNumberVO itemNumberVO = null;
		// List<GetsDemand> itemList = null;

		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		System.out.println("HospitalAlarmService.getBuyerNames()");
		try {
			List<Object[]> retList = demandRepo.getUniqueBuyerNames();
			System.out.println("retList.getBuyerNames()" + retList.size());
			for (int i = 0; i < retList.size(); i++) {
				objMap = new HashMap<String, Object>();
				objMap.put("buyerName", (retList.get(i))[0]);
				//objMap.put("itemDescription", (retList.get(i))[1]);
				list.add(objMap);
			}

			
			 * itemList = demandRepo.getUniqueItemNumber(); for(GetsDemand
			 * itemLst : itemList){ itemNumberVO = new ItemNumberVO();
			 * itemNumberVO.setItemNumber(itemLst.getItemNumber());
			 * itemNumberVO.setItemDescription(itemLst.getItemDescription());
			 * itemNumberVOs.add(itemNumberVO); }
			 

		} catch (Exception e) {
			System.out.println("HospitalAlarmService.getSupplierNames()" + e);
		}
		return list;

	}*/
	
	@RequestMapping(value = "/getBuyerNameOnSearch", method = RequestMethod.POST, produces="application/json")
	public @ResponseBody List<Map<String, Object>> getBuyerNamesOnName(
			@RequestBody @Valid final GetsDemand demand) {

		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		System.out.println("HospitalAlarmService.getBuyerNamesOnName()");
		try {
			List<Object[]> retList = demandRepo.getBuyerNamesOnName(demand.getBuyerName());
			System.out.println("retList.getBuyerNamesOnName()" + retList.size());		

			for (int i = 0; i < retList.size(); i++) {
				objMap = new HashMap<String, Object>();
				objMap.put("buyerName", (retList.get(i)));
				//objMap.put("id", (retList.get(i))[1]);
				list.add(objMap);
			}

		} catch (Exception e) {
			System.out.println("HospitalAlarmService.getSupplierNamesOnName()" + e);
		}
		return list;

	}
	/*
	@RequestMapping("/getBuisnessUnitNames")
	public @ResponseBody List<Map<String, Object>> getBuisnessUnitNames() {
		// List<ItemNumberVO> itemNumberVOs = new ArrayList<ItemNumberVO>();
		// ItemNumberVO itemNumberVO = null;
		// List<GetsDemand> itemList = null;

		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		System.out.println("HospitalAlarmService.getBuisnessUnitNames()");
		try {
			List<Object[]> retList = demandRepo.getUniqueBuisnessUnitNames();
			System.out.println("retList.getBuisnessUnitNames()" + retList.size());
			for (int i = 0; i < retList.size(); i++) {
				objMap = new HashMap<String, Object>();
				objMap.put("buissnessUnit", (retList.get(i))[0]);
				//objMap.put("itemDescription", (retList.get(i))[1]);
				list.add(objMap);
			}

			
			 * itemList = demandRepo.getUniqueItemNumber(); for(GetsDemand
			 * itemLst : itemList){ itemNumberVO = new ItemNumberVO();
			 * itemNumberVO.setItemNumber(itemLst.getItemNumber());
			 * itemNumberVO.setItemDescription(itemLst.getItemDescription());
			 * itemNumberVOs.add(itemNumberVO); }
			 

		} catch (Exception e) {
			System.out.println("HospitalAlarmService.getSupplierNames()" + e);
		}
		return list;

	}*/
	
	@RequestMapping(value = "/getBuisenssUnitOnSearch", method = RequestMethod.POST, produces="application/json")
	public @ResponseBody List<Map<String, Object>> getBuisnessUnitOnName(
			@RequestBody @Valid final GetsDemand demand) {

		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		System.out.println("HospitalAlarmService.getBuisnessUnitOnName()");
		try {
			List<Object[]> retList = demandRepo.getBuisnessNamesOnName(demand.getBuissnessUnit());
				System.out
						.println("retList.getBuisnessUnitOnName()" + retList.size());	

			for (int i = 0; i < retList.size(); i++) {
				objMap = new HashMap<String, Object>();
				objMap.put("buissnessUnit", (retList.get(i)));
				//objMap.put("id", (retList.get(i))[1]);
				list.add(objMap);
			}

		} catch (Exception e) {
			System.out.println("HospitalAlarmService.getSupplierNamesOnName()" + e);
		}
		return list;

	}
}
