package com.ge.Transport.SearchWithFilterLatestSCP.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ge.Transport.SearchWithFilterLatestSCP.entity.GetsDemand;

/**
 * This class models the spring-data repository for alarmevent entity. Apart form the standard operations supported by
 * CRUD Repository, this class also supports customized named queries ,pagination, sorting and type safe queries using query-dsl.
 * l
 * @author 212350258
 */
@Repository
public interface IDemandSearchEntityRepository extends JpaRepository<GetsDemand, Long>,JpaSpecificationExecutor<GetsDemand>,PagingAndSortingRepository<GetsDemand, Long>
{
	
	
	
}