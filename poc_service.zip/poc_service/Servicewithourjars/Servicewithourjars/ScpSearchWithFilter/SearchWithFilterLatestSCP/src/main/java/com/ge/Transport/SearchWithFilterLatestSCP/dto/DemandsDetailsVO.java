package com.ge.Transport.SearchWithFilterLatestSCP.dto;

import java.math.BigDecimal;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class DemandsDetailsVO {
	
	private long dispositionId;

	private String buyerEmail;

	private String buyerName;
	
	private String supplierName;

	private String inventoryOrganization;

	private String itemDescription;

	private String itemNumber;

	private Date newScheduleDate;

	private BigDecimal orderQuantity;

	private String primaryUnitOfMeasure;

	private String primaryUomCode;

	private String supplierCode;
	
//	private List<QuantityTypeVO> quantityVos;
	
	private BigDecimal apr04Apr10;

	private BigDecimal apr11Apr17;

	private BigDecimal apr18Apr24;

	private BigDecimal apr25May01;

	private BigDecimal aug01Aug28;

	private BigDecimal aug29Oct02;

	private BigDecimal oct31Nov27;

	private BigDecimal feb29Mar06;

	private BigDecimal jan02Jan29;

	private BigDecimal jan30Feb26;

	private BigDecimal jul04Jul31;

	private BigDecimal mar07Mar13;

	private BigDecimal mar14Mar20;

	private BigDecimal mar21Mar27;

	private BigDecimal mar28MApr03;

	private BigDecimal may02May08;

	private BigDecimal may09May15;

	private BigDecimal may16May22;

	private BigDecimal may23May29;

	private BigDecimal may30Jul03;
	
	private BigDecimal nov28Jan01;

	private BigDecimal oct03Oct30;
	
	private String quantityType;
	
	private BigDecimal demandId;
	
	private String editFlag;
	
	private String sentFlag;
	
	private BigDecimal pastDue;
	
	
	

	public BigDecimal getPastDue() {
		return pastDue;
	}

	public void setPastDue(BigDecimal pastDue) {
		this.pastDue = pastDue;
	}

	public long getDispositionId() {
		return dispositionId;
	}

	public void setDispositionId(long dispositionId) {
		this.dispositionId = dispositionId;
	}

	public String getBuyerEmail() {
		return buyerEmail;
	}

	public void setBuyerEmail(String buyerEmail) {
		this.buyerEmail = buyerEmail;
	}

	public String getBuyerName() {
		return buyerName;
	}

	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}

	public String getInventoryOrganization() {
		return inventoryOrganization;
	}

	public void setInventoryOrganization(String inventoryOrganization) {
		this.inventoryOrganization = inventoryOrganization;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public String getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	public Date getNewScheduleDate() {
		return newScheduleDate;
	}

	public void setNewScheduleDate(Date newScheduleDate) {
		this.newScheduleDate = newScheduleDate;
	}

	public BigDecimal getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(BigDecimal orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public String getPrimaryUnitOfMeasure() {
		return primaryUnitOfMeasure;
	}

	public void setPrimaryUnitOfMeasure(String primaryUnitOfMeasure) {
		this.primaryUnitOfMeasure = primaryUnitOfMeasure;
	}

	public String getPrimaryUomCode() {
		return primaryUomCode;
	}

	public void setPrimaryUomCode(String primaryUomCode) {
		this.primaryUomCode = primaryUomCode;
	}

	public String getSupplierCode() {
		return supplierCode;
	}

	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}


	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public BigDecimal getApr04Apr10() {
		return apr04Apr10;
	}

	public void setApr04Apr10(BigDecimal apr04Apr10) {
		this.apr04Apr10 = apr04Apr10;
	}

	public BigDecimal getApr11Apr17() {
		return apr11Apr17;
	}

	public void setApr11Apr17(BigDecimal apr11Apr17) {
		this.apr11Apr17 = apr11Apr17;
	}

	public BigDecimal getApr18Apr24() {
		return apr18Apr24;
	}

	public void setApr18Apr24(BigDecimal apr18Apr24) {
		this.apr18Apr24 = apr18Apr24;
	}

	public BigDecimal getApr25May01() {
		return apr25May01;
	}

	public void setApr25May01(BigDecimal apr25May01) {
		this.apr25May01 = apr25May01;
	}

	public BigDecimal getAug01Aug28() {
		return aug01Aug28;
	}

	public void setAug01Aug28(BigDecimal aug01Aug28) {
		this.aug01Aug28 = aug01Aug28;
	}

	public BigDecimal getAug29Oct02() {
		return aug29Oct02;
	}

	public void setAug29Oct02(BigDecimal aug29Oct02) {
		this.aug29Oct02 = aug29Oct02;
	}

	public BigDecimal getOct31Nov27() {
		return oct31Nov27;
	}

	public void setOct31Nov27(BigDecimal oct31Nov27) {
		this.oct31Nov27 = oct31Nov27;
	}

	public BigDecimal getFeb29Mar06() {
		return feb29Mar06;
	}

	public void setFeb29Mar06(BigDecimal feb29Mar06) {
		this.feb29Mar06 = feb29Mar06;
	}

	public BigDecimal getJan02Jan29() {
		return jan02Jan29;
	}

	public void setJan02Jan29(BigDecimal jan02Jan29) {
		this.jan02Jan29 = jan02Jan29;
	}

	public BigDecimal getJan30Feb26() {
		return jan30Feb26;
	}

	public void setJan30Feb26(BigDecimal jan30Feb26) {
		this.jan30Feb26 = jan30Feb26;
	}

	public BigDecimal getJul04Jul31() {
		return jul04Jul31;
	}

	public void setJul04Jul31(BigDecimal jul04Jul31) {
		this.jul04Jul31 = jul04Jul31;
	}

	public BigDecimal getMar07Mar13() {
		return mar07Mar13;
	}

	public void setMar07Mar13(BigDecimal mar07Mar13) {
		this.mar07Mar13 = mar07Mar13;
	}

	public BigDecimal getMar14Mar20() {
		return mar14Mar20;
	}

	public void setMar14Mar20(BigDecimal mar14Mar20) {
		this.mar14Mar20 = mar14Mar20;
	}

	public BigDecimal getMar21Mar27() {
		return mar21Mar27;
	}

	public void setMar21Mar27(BigDecimal mar21Mar27) {
		this.mar21Mar27 = mar21Mar27;
	}


	public BigDecimal getMar28MApr03() {
		return mar28MApr03;
	}

	public void setMar28MApr03(BigDecimal mar28mApr03) {
		mar28MApr03 = mar28mApr03;
	}

	public BigDecimal getMay02May08() {
		return may02May08;
	}

	public void setMay02May08(BigDecimal may02May08) {
		this.may02May08 = may02May08;
	}

	public BigDecimal getMay09May15() {
		return may09May15;
	}

	public void setMay09May15(BigDecimal may09May15) {
		this.may09May15 = may09May15;
	}

	public BigDecimal getMay16May22() {
		return may16May22;
	}

	public void setMay16May22(BigDecimal may16May22) {
		this.may16May22 = may16May22;
	}

	public BigDecimal getMay23May29() {
		return may23May29;
	}

	public void setMay23May29(BigDecimal may23May29) {
		this.may23May29 = may23May29;
	}

	public BigDecimal getMay30Jul03() {
		return may30Jul03;
	}

	public void setMay30Jul03(BigDecimal may30Jul03) {
		this.may30Jul03 = may30Jul03;
	}

	public BigDecimal getNov28Jan01() {
		return nov28Jan01;
	}

	public void setNov28Jan01(BigDecimal nov28Jan01) {
		this.nov28Jan01 = nov28Jan01;
	}

	public BigDecimal getOct03Oct30() {
		return oct03Oct30;
	}

	public void setOct03Oct30(BigDecimal oct03Oct30) {
		this.oct03Oct30 = oct03Oct30;
	}

	public String getQuantityType() {
		return quantityType;
	}

	public void setQuantityType(String quantityType) {
		this.quantityType = quantityType;
	}

	public BigDecimal getDemandId() {
		return demandId;
	}

	public void setDemandId(BigDecimal demandId) {
		this.demandId = demandId;
	}

	public String getEditFlag() {
		return editFlag;
	}

	public void setEditFlag(String editFlag) {
		this.editFlag = editFlag;
	}

	public String getSentFlag() {
		return sentFlag;
	}

	public void setSentFlag(String sentFlag) {
		this.sentFlag = sentFlag;
	}
	
	
	

}
