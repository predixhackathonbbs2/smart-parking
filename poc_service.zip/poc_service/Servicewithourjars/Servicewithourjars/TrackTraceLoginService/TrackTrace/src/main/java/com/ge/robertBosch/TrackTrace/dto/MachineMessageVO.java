package com.ge.robertBosch.TrackTrace.dto;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class MachineMessageVO {
	

	private long id;

	private String class_;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getClass_() {
		return class_;
	}

	public void setClass_(String class_) {
		this.class_ = class_;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	private String content;

	private String img;

	private String title;

}

