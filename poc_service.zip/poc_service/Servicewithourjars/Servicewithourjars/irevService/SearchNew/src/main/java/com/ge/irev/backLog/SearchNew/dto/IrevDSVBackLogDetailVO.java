package com.ge.irev.backLog.SearchNew.dto;

import java.util.*;

public class IrevDSVBackLogDetailVO {
	
	private String totalNumofRecords;
	
	private List<iRevDSVBacklogVO>  backlogVOs;

	public String getTotalNumofRecords() {
		return totalNumofRecords;
	}

	public void setTotalNumofRecords(String totalNumofRecords) {
		this.totalNumofRecords = totalNumofRecords;
	}

	public List<iRevDSVBacklogVO> getBacklogVOs() {
		return backlogVOs;
	}

	public void setBacklogVOs(List<iRevDSVBacklogVO> backlogVOs) {
		this.backlogVOs = backlogVOs;
	}
	
	

}
