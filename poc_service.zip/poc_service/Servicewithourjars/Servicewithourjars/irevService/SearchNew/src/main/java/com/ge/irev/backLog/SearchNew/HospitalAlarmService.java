package com.ge.irev.backLog.SearchNew;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ge.irev.backLog.SearchNew.dto.AlarmEvent;
import com.ge.irev.backLog.SearchNew.entity.AlarmEventEntity;
import com.ge.irev.backLog.SearchNew.entity.IrevDgsBacklog;
import com.ge.irev.backLog.SearchNew.repository.IAlarmEventEntityRepository;
import com.ge.irev.backLog.SearchNew.repository.IrevDSVBackLogRepository;

@RestController
public class HospitalAlarmService {

	@Autowired
	private IAlarmEventEntityRepository alarmService;
	
	@Autowired
	private IrevDSVBackLogRepository iRevRepo;

	@RequestMapping("/SearchNew")
	public @ResponseBody List<AlarmEvent> helloWorld() {
		List<AlarmEvent> events = new ArrayList<AlarmEvent>();
		List<AlarmEventEntity> entities = this.alarmService.findAll();
		for (AlarmEventEntity entity:entities) {
			events.add(entity.toAlarmEvent());
		}
		return events;
	}
	
	
	@RequestMapping(value = "/getAllDSVBacklogDetailsOnSearchPost", method = RequestMethod.POST, produces="application/json")
	public @ResponseBody  List<Map<String,Object>>  getAllDSVBacklogDetailsOnSearchPost(@RequestBody @Valid final IrevDgsBacklog irevDgsBacklog) {
		Map<String,Object> objMap  = null;
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		try {
			System.out
					.println("getZone()" + irevDgsBacklog.getZone());
			System.out
			.println("getZone()" + irevDgsBacklog.getRegion());
			System.out
			.println("getZone()" + irevDgsBacklog.getRevrecqtr());
			System.out
			.println("getZone()" + irevDgsBacklog.getAccountreps());
			System.out
			.println("getZone()" + irevDgsBacklog.getPss());
			System.out
			.println("getZone()" + irevDgsBacklog.getSchedules());
			
			
			
			List<Object []> retList  = iRevRepo.findIRevDSVBacklogVOonSearch(irevDgsBacklog.getZone(),irevDgsBacklog.getRegion(),irevDgsBacklog.getRevrecqtr(),irevDgsBacklog.getAccountreps(),irevDgsBacklog.getPss(),irevDgsBacklog.getGovtvaso(),irevDgsBacklog.getSchedules());
			for(int i = 0; i < retList.size(); i++){
				objMap	= new HashMap<String, Object>();
				objMap.put("id", (retList.get(i))[0]);
				objMap.put("mod", (retList.get(i))[1]);
				objMap.put("accountreps", (retList.get(i))[2]);
				objMap.put("comments", (retList.get(i))[3]);
				objMap.put("construction", (retList.get(i))[4]);
				
				objMap.put("contractcustname", (retList.get(i))[5]);
				objMap.put("crd", (retList.get(i))[6]);
				
				objMap.put("creditstatus", (retList.get(i))[7]);
				objMap.put("estrevfq", (retList.get(i))[8]);
				
				objMap.put("fset", (retList.get(i))[9]);
				objMap.put("gon", (retList.get(i))[10]);
				
				objMap.put("govtvaso", (retList.get(i))[11]);
				objMap.put("h", (retList.get(i))[12]);
				objMap.put("nevtt", (retList.get(i))[13]);
				objMap.put("orderchart", (retList.get(i))[14]);
				objMap.put("pmiscomment", (retList.get(i))[15]);
				
				objMap.put("pss", (retList.get(i))[16]);
				objMap.put("region", (retList.get(i))[17]);
				objMap.put("revrecqtr", (retList.get(i))[18]);
				objMap.put("revrecterms", (retList.get(i))[19]);
				objMap.put("rosd", (retList.get(i))[20]);
				objMap.put("salesh", (retList.get(i))[21]);
				objMap.put("schedules", (retList.get(i))[22]);
				objMap.put("sosd", (retList.get(i))[23]);
				objMap.put("zone", (retList.get(i))[24]);
			
				list.add(objMap);
			
			}
		
		} catch (Exception e) {
			System.out
					.println("HospitalAlarmService.iRevDSVBacklogVOonSearch()"
							+ e);
		}
		return list;
		
	}
}
