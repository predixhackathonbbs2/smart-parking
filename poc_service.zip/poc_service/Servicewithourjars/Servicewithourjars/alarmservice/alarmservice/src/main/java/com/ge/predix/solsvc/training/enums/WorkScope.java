package com.ge.predix.solsvc.training.enums;

public enum WorkScope {
	
HIGH,
	
	LOW,
	
	MEDIUM

}
