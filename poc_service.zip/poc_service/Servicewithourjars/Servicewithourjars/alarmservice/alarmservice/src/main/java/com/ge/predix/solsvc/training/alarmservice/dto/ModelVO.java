package com.ge.predix.solsvc.training.alarmservice.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ModelVO implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private long id;	
	private String modelName;
	private String modelNumber;
	//private List<EngineVO> engines;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getModelNumber() {
		return modelNumber;
	}
	public void setModelNumber(String modelNumber) {
		this.modelNumber = modelNumber;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	/*public List<EngineVO> getEngines() {
		return engines;
	}
	public void setEngines(List<EngineVO> engines) {
		this.engines = engines;
	}*/
	
	
}
