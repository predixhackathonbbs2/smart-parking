package com.ge.predix.solsvc.training.alarmservice.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.ge.predix.solsvc.training.alarmservice.entity.Engines;


public interface IEngineEntityRepository extends CrudRepository<Engines, Long>{
	
	List<Engines> findByModelsModelNumber(String modelNumber);

}
