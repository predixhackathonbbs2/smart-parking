package com.ge.Transport.ScpUpdateRecord;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ge.Transport.ScpUpdateRecord.dto.AlarmEvent;
import com.ge.Transport.ScpUpdateRecord.entity.AlarmEventEntity;
import com.ge.Transport.ScpUpdateRecord.entity.GetsDemand;
import com.ge.Transport.ScpUpdateRecord.repository.IAlarmEventEntityRepository;
import com.ge.Transport.ScpUpdateRecord.repository.IDemandUpdateRepository;

@RestController
public class HospitalAlarmService {

	@Autowired
	private IAlarmEventEntityRepository alarmService;
	
	@Autowired
	private IDemandUpdateRepository demandUpdateRepository;

	@RequestMapping("/ScpUpdateRecord")
	public @ResponseBody List<AlarmEvent> helloWorld() {
		List<AlarmEvent> events = new ArrayList<AlarmEvent>();
		List<AlarmEventEntity> entities = this.alarmService.findAll();
		for (AlarmEventEntity entity:entities) {
			events.add(entity.toAlarmEvent());
		}
		return events;
	}
	@RequestMapping(value = "/view/updateDemandDetails", method = RequestMethod.POST, produces="application/json")
	public @ResponseBody void updateDemandDetails(@RequestBody GetsDemand demand) {
		 GetsDemand checkDemand = null;
		try {
			checkDemand = demandUpdateRepository.findOne(demand.getDispositionId());
			
			System.out.println("demand.getDispositionId()>>>>>" + demand.getDispositionId() + "::::" + checkDemand);
			
			
			
			if(null != checkDemand){
				
				checkDemand.setDispositionId(checkDemand.getDispositionId());
				checkDemand.setItemNumber(checkDemand.getItemNumber());
				checkDemand.setItemDescription(checkDemand.getItemDescription());
				checkDemand.setSupplierName(checkDemand.getSupplierName());
				checkDemand.setInventoryOrganization(checkDemand.getInventoryOrganization());
				
				
				checkDemand.setApr04Apr10(demand.getApr04Apr10());
				checkDemand.setApr11Apr17(demand.getApr11Apr17());
				checkDemand.setApr18Apr24(demand.getApr18Apr24());
				checkDemand.setApr25May01(demand.getApr25May01());
				checkDemand.setAug01Aug28(demand.getAug01Aug28());
				checkDemand.setAug29Oct02(demand.getAug29Oct02());
				checkDemand.setFeb29Mar06(demand.getFeb29Mar06());
				checkDemand.setJan02Jan29(demand.getJan02Jan29());
				checkDemand.setJan30Feb26(demand.getJan30Feb26());
				checkDemand.setJul04Jul31(demand.getJul04Jul31());
				checkDemand.setMar07Mar13(demand.getMar07Mar13());
				checkDemand.setMar14Mar20(demand.getMar14Mar20());
				checkDemand.setMar21Mar27(demand.getMar21Mar27());
				checkDemand.setMar28Apr03(demand.getMar28Apr03());
				checkDemand.setMay02May08(demand.getMay02May08());
				checkDemand.setMay09May15(demand.getMay09May15());
				checkDemand.setMay16May22(demand.getMay16May22());
				checkDemand.setMay23May29(demand.getMay23May29());
				checkDemand.setMay30Jul03(demand.getMay30Jul03());
				checkDemand.setNov28Jan01(demand.getNov28Jan01());
				checkDemand.setOct03Oct30(demand.getOct03Oct30());
				checkDemand.setOct31Nov27(demand.getOct31Nov27());
				
				demandUpdateRepository.save(checkDemand);
				
			}
				
			}
			
			
		 catch (Exception e) {
			System.out.println("HospitalAlarmService.getDemandDetailsWithOutFilter()" + e);
		}
	
	}
	
}
