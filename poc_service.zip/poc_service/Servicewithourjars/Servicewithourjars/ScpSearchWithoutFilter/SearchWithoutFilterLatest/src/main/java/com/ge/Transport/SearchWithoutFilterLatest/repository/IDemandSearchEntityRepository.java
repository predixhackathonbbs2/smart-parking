package com.ge.Transport.SearchWithoutFilterLatest.repository;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ge.Transport.SearchWithoutFilterLatest.entity.GetsDemand;
import java.lang.String;

/**
 * This class models the spring-data repository for alarmevent entity. Apart form the standard operations supported by
 * CRUD Repository, this class also supports customized named queries ,pagination, sorting and type safe queries using query-dsl.
 * l
 * @author 212350258
 */
@Repository
public interface IDemandSearchEntityRepository extends JpaRepository<GetsDemand, Long>,PagingAndSortingRepository<GetsDemand, Long>
{
	
	/*@Override
	public List<GetsDemand> findAll();*/
	
	@Override
	public List<GetsDemand> findAll(Sort sort);
	
	
	List<GetsDemand> findBySupplierName(String suppliername,Sort sort);
	
	
}