package com.ge.ScpTransport.ScpTransportPortalDemand.dto;

import java.math.BigDecimal;
import java.util.Date;

public class DemandsVO {

	private long dispositionId;

	private String buyerEmail;

	private String buyerName;

	private String inventoryOrganization;

	private String itemDescription;

	private String itemNumber;

	private Date newScheduleDate;

	private BigDecimal orderQuantity;

	private String primaryUnitOfMeasure;

	private String primaryUomCode;

	private String supplierCode;

	public long getDispositionId() {
		return dispositionId;
	}

	public void setDispositionId(long dispositionId) {
		this.dispositionId = dispositionId;
	}

	public String getBuyerEmail() {
		return buyerEmail;
	}

	public void setBuyerEmail(String buyerEmail) {
		this.buyerEmail = buyerEmail;
	}

	public String getBuyerName() {
		return buyerName;
	}

	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}

	public String getInventoryOrganization() {
		return inventoryOrganization;
	}

	public void setInventoryOrganization(String inventoryOrganization) {
		this.inventoryOrganization = inventoryOrganization;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public String getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	public Date getNewScheduleDate() {
		return newScheduleDate;
	}

	public void setNewScheduleDate(Date newScheduleDate) {
		this.newScheduleDate = newScheduleDate;
	}

	public BigDecimal getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(BigDecimal orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public String getPrimaryUnitOfMeasure() {
		return primaryUnitOfMeasure;
	}

	public void setPrimaryUnitOfMeasure(String primaryUnitOfMeasure) {
		this.primaryUnitOfMeasure = primaryUnitOfMeasure;
	}

	public String getPrimaryUomCode() {
		return primaryUomCode;
	}

	public void setPrimaryUomCode(String primaryUomCode) {
		this.primaryUomCode = primaryUomCode;
	}

	public String getSupplierCode() {
		return supplierCode;
	}

	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	private String supplierName;

}
