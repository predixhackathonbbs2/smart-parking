package com.ge.ScpTransport.ScpTransportPortalDemand.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ge.ScpTransport.ScpTransportPortalDemand.entity.GetsDemand;

/**
 * This class models the spring-data repository for alarmevent entity. Apart form the standard operations supported by
 * CRUD Repository, this class also supports customized named queries ,pagination, sorting and type safe queries using query-dsl.
 * l
 * @author 212350258
 */
@Repository
public interface IDemandUpdateRepository extends CrudRepository<GetsDemand, Long>
{

	@Override
	public GetsDemand findOne(Long id);
	
	
	
}