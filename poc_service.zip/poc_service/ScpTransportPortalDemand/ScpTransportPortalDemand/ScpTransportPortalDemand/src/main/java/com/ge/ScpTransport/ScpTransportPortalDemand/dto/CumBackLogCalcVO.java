package com.ge.ScpTransport.ScpTransportPortalDemand.dto;

import java.math.BigDecimal;

public class CumBackLogCalcVO {
	
	
	
//	private List<QuantityTypeVO> quantityVos;
	
	private BigDecimal cumbackapr04Apr10;

	private BigDecimal cumbackapr11Apr17;

	private BigDecimal cumbackapr18Apr24;

	private BigDecimal cumbackapr25May01;

	private BigDecimal cumbackaug01Aug28;

	private BigDecimal cumbackaug29Oct02;

	private BigDecimal cumbackoct31Nov27;

	private BigDecimal cumbackfeb29Mar06;

	private BigDecimal cumbackjan02Jan29;

	private BigDecimal cumbackjan30Feb26;

	private BigDecimal cumbackjul04Jul31;

	private BigDecimal cumbackmar07Mar13;

	private BigDecimal cumbackmar14Mar20;

	private BigDecimal cumbackmar21Mar27;

	private BigDecimal cumbackmar28Apr03;

	private BigDecimal cumbackmay02May08;

	private BigDecimal cumbackmay09May15;

	private BigDecimal cumbackmay16May22;

	private BigDecimal cumbackmay23May29;

	private BigDecimal cumbackmay30Jul03;
	
	private BigDecimal cumbacknov28Jan01;

	private BigDecimal cumbackoct03Oct30;
	
	private String quantityType;
	
	private BigDecimal demandId;
	
	private String editFlag;
	
	private String sentFlag;
	
	private BigDecimal cumbackpastDue;
		

	public BigDecimal getcumbackapr04Apr10() {
		return cumbackapr04Apr10;
	}

	public void setcumbackapr04Apr10(BigDecimal cumbackapr04Apr10) {
		this.cumbackapr04Apr10 = cumbackapr04Apr10;
	}

	public BigDecimal getcumbackapr11Apr17() {
		return cumbackapr11Apr17;
	}

	public void setcumbackapr11Apr17(BigDecimal cumbackapr11Apr17) {
		this.cumbackapr11Apr17 = cumbackapr11Apr17;
	}

	public BigDecimal getcumbackapr18Apr24() {
		return cumbackapr18Apr24;
	}

	public void setcumbackapr18Apr24(BigDecimal cumbackapr18Apr24) {
		this.cumbackapr18Apr24 = cumbackapr18Apr24;
	}

	public BigDecimal getcumbackapr25May01() {
		return cumbackapr25May01;
	}

	public void setcumbackapr25May01(BigDecimal cumbackapr25May01) {
		this.cumbackapr25May01 = cumbackapr25May01;
	}

	public BigDecimal getcumbackaug01Aug28() {
		return cumbackaug01Aug28;
	}

	public void setcumbackaug01Aug28(BigDecimal cumbackaug01Aug28) {
		this.cumbackaug01Aug28 = cumbackaug01Aug28;
	}

	public BigDecimal getcumbackaug29Oct02() {
		return cumbackaug29Oct02;
	}

	public void setcumbackaug29Oct02(BigDecimal cumbackaug29Oct02) {
		this.cumbackaug29Oct02 = cumbackaug29Oct02;
	}

	public BigDecimal getcumbackoct31Nov27() {
		return cumbackoct31Nov27;
	}

	public void setcumbackoct31Nov27(BigDecimal cumbackoct31Nov27) {
		this.cumbackoct31Nov27 = cumbackoct31Nov27;
	}

	public BigDecimal getcumbackfeb29Mar06() {
		return cumbackfeb29Mar06;
	}

	public void setcumbackfeb29Mar06(BigDecimal cumbackfeb29Mar06) {
		this.cumbackfeb29Mar06 = cumbackfeb29Mar06;
	}

	public BigDecimal getcumbackjan02Jan29() {
		return cumbackjan02Jan29;
	}

	public void setcumbackjan02Jan29(BigDecimal cumbackjan02Jan29) {
		this.cumbackjan02Jan29 = cumbackjan02Jan29;
	}

	public BigDecimal getcumbackjan30Feb26() {
		return cumbackjan30Feb26;
	}

	public void setcumbackjan30Feb26(BigDecimal cumbackjan30Feb26) {
		this.cumbackjan30Feb26 = cumbackjan30Feb26;
	}

	public BigDecimal getcumbackjul04Jul31() {
		return cumbackjul04Jul31;
	}

	public void setcumbackjul04Jul31(BigDecimal cumbackjul04Jul31) {
		this.cumbackjul04Jul31 = cumbackjul04Jul31;
	}

	public BigDecimal getcumbackmar07Mar13() {
		return cumbackmar07Mar13;
	}

	public void setcumbackmar07Mar13(BigDecimal cumbackmar07Mar13) {
		this.cumbackmar07Mar13 = cumbackmar07Mar13;
	}

	public BigDecimal getcumbackmar14Mar20() {
		return cumbackmar14Mar20;
	}

	public void setcumbackmar14Mar20(BigDecimal cumbackmar14Mar20) {
		this.cumbackmar14Mar20 = cumbackmar14Mar20;
	}

	public BigDecimal getcumbackmar21Mar27() {
		return cumbackmar21Mar27;
	}

	public void setcumbackmar21Mar27(BigDecimal cumbackmar21Mar27) {
		this.cumbackmar21Mar27 = cumbackmar21Mar27;
	}

	public BigDecimal getcumbackmar28Apr03() {
		return cumbackmar28Apr03;
	}

	public void setcumbackmar28Apr03(BigDecimal cumbackmar28Apr03) {
		this.cumbackmar28Apr03 = cumbackmar28Apr03;
	}

	public BigDecimal getcumbackmay02May08() {
		return cumbackmay02May08;
	}

	public void setcumbackmay02May08(BigDecimal cumbackmay02May08) {
		this.cumbackmay02May08 = cumbackmay02May08;
	}

	public BigDecimal getcumbackmay09May15() {
		return cumbackmay09May15;
	}

	public void setcumbackmay09May15(BigDecimal cumbackmay09May15) {
		this.cumbackmay09May15 = cumbackmay09May15;
	}

	public BigDecimal getcumbackmay16May22() {
		return cumbackmay16May22;
	}

	public void setcumbackmay16May22(BigDecimal cumbackmay16May22) {
		this.cumbackmay16May22 = cumbackmay16May22;
	}

	public BigDecimal getcumbackmay23May29() {
		return cumbackmay23May29;
	}

	public void setcumbackmay23May29(BigDecimal cumbackmay23May29) {
		this.cumbackmay23May29 = cumbackmay23May29;
	}

	public BigDecimal getcumbackmay30Jul03() {
		return cumbackmay30Jul03;
	}

	public void setcumbackmay30Jul03(BigDecimal cumbackmay30Jul03) {
		this.cumbackmay30Jul03 = cumbackmay30Jul03;
	}

	public BigDecimal getcumbacknov28Jan01() {
		return cumbacknov28Jan01;
	}

	public void setcumbacknov28Jan01(BigDecimal cumbacknov28Jan01) {
		this.cumbacknov28Jan01 = cumbacknov28Jan01;
	}

	public BigDecimal getcumbackoct03Oct30() {
		return cumbackoct03Oct30;
	}

	public void setcumbackoct03Oct30(BigDecimal cumbackoct03Oct30) {
		this.cumbackoct03Oct30 = cumbackoct03Oct30;
	}

	public String getQuantityType() {
		return quantityType;
	}

	public void setQuantityType(String quantityType) {
		this.quantityType = quantityType;
	}

	public BigDecimal getDemandId() {
		return demandId;
	}

	public void setDemandId(BigDecimal demandId) {
		this.demandId = demandId;
	}

	public String getEditFlag() {
		return editFlag;
	}

	public void setEditFlag(String editFlag) {
		this.editFlag = editFlag;
	}

	public String getSentFlag() {
		return sentFlag;
	}

	public void setSentFlag(String sentFlag) {
		this.sentFlag = sentFlag;
	}

	public BigDecimal getcumbackpastDue() {
		return cumbackpastDue;
	}

	public void setcumbackpastDue(BigDecimal cumbackpastDue) {
		this.cumbackpastDue = cumbackpastDue;
	}

	
	
	

}

