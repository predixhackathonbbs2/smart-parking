package com.ge.ScpTransport.ScpTransportPortalDemand.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ge.ScpTransport.ScpTransportPortalDemand.entity.ScpUser;

public interface IscploginRepository extends JpaRepository<ScpUser, Long>{
	
	String CHECK_AVIALABLE_USER = "from ScpUser ttUser where ttUser.username=?1";

	@Query(CHECK_AVIALABLE_USER)
	ScpUser findUser(String username);

}
